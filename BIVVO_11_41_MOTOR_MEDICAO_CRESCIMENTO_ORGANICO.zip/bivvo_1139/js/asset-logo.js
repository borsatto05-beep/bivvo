/* Logos públicas dos ativos; a identificação textual permanece quando não há imagem. */
import { h } from './util.js';
export function assetLogo(asset){
 const name=String(asset.ticker||asset.symbol||asset.name||asset.type||'Ativo').trim();
 const ticker=name.toUpperCase().replace(/\.SA$/,'').match(/\b[A-Z][A-Z0-9]{3}\d{1,2}\b/)?.[0];
 const initials=ticker?ticker.slice(0,2):name.split(/\s+/).slice(0,2).map(x=>x[0]||'').join('').toUpperCase();
 const root=h('span.tx-ico.asset-logo',{'aria-hidden':'true'},h('span.asset-monogram',initials||'AT'));
 if(ticker){
  const img=h('img',{src:'https://icons.brapi.dev/icons/'+encodeURIComponent(ticker)+'.svg',alt:'',loading:'lazy',decoding:'async',referrerPolicy:'no-referrer'});
  img.addEventListener('error',()=>img.remove(),{once:true});
  img.addEventListener('load',()=>root.querySelector('.asset-monogram')?.remove(),{once:true});
  root.append(img);
 }
 return root;
}
