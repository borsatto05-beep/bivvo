/* Bivvo — Fase 3: copiloto financeiro. O extrato nunca sai do aparelho.
   Este módulo transforma o estado em resultados agregados das ferramentas existentes. */
import { today, ymOf, addMonthsYM, money0, parseISO } from './util.js';
import * as store from './store.js';
import * as F from './finance.js';
import * as cloud from './cloud.js';
import { getRemainingUsage, setUsage } from './plans.js';

const norm = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
const round = n => Math.round((Number(n) || 0) * 100) / 100;
const naturalDate = iso => { try { return parseISO(iso).toLocaleDateString('pt-BR',{day:'numeric',month:'long'}); } catch { return String(iso||''); } };

export function toolResults(s = store.getState()) {
  const ym = ymOf(today()), prevYm = addMonthsYM(ym, -1);
  const sp = F.spendable(s), month = F.monthSummary(ym, s), prev = F.monthSummary(prevYm, s);
  const f7 = F.dailyForecast(7, s), f30 = F.dailyForecast(30, s), wealth = F.wealth(s), subs = F.subscriptionSummary(s);
  const cards = s.cards.map(c => { const st = F.cardStatus(c, s), safe = F.safeCardLimit(c, s); return { name:c.name, limit:round(c.limit), used:round(st.used), available:round(st.available), openInvoice:round(st.open.total), safeToUse:round(safe.safe), dueDate:safe.dueDate }; });
  return {
    asOf: today(),
    spendable: { balance:round(sp.balance), free:round(sp.free), perDay:round(sp.perDay), until:sp.until, bills:round(sp.billsTotal), invoices:round(sp.invoices), saveLeft:round(sp.saveLeft), tone:sp.tone },
    month: { income:round(month.income), incomePaid:round(month.incomePaid), spend:round(month.spend), saved:round(month.saved), planned:round(month.planned), result:round(month.result), topCategories:month.cats.slice(0,5).map(x=>({category:x.cat,value:round(x.value),share:round(x.share)})) },
    previousMonth: { spend:round(prev.spend), income:round(prev.income), saved:round(prev.saved), result:round(prev.result) },
    forecast: { day7:round(f7.endBalance), day30:round(f30.endBalance), riskDate:f30.risk?.date || null, riskBalance:f30.risk ? round(f30.risk.balance) : null, estimated:f30.estimated },
    cards,
    commitments: { installments3Months:round(F.installmentsCommit(3,s)), subscriptionsMonthly:round(subs.monthly), subscriptionsAnnual:round(subs.annual) },
    wealth: { total:round(wealth.total), investments:round(wealth.investments), goals:round(wealth.goals), reserve:round(wealth.reserve) },
    quality: { transactions:s.transactions.length, cards:s.cards.length, hasBalanceBase:F.hasBalanceBase(s) }
  };
}

export function localAnswer(question, tools = toolResults()) {
  const q = norm(question), x = tools;
  if (!q) return null;
  if (/o que.*faco.*hoje|missao.*hoje|qual.*prioridade.*hoje/.test(q)) { const risk=x.forecast.riskDate; return {kind:'local',title:'Sua missão de hoje',text:risk ? `Hoje, proteja seu caixa e tente ficar dentro de ${money0(Math.max(0,x.spendable.perDay))}. Com os dados atuais, a projeção pode ficar negativa em ${naturalDate(risk)}.` : x.spendable.free < 0 ? `Hoje, evite assumir novos gastos e priorize os compromissos essenciais. Seu dinheiro livre está negativo em ${money0(Math.abs(x.spendable.free))}.` : `Hoje, mantenha seus gastos dentro de ${money0(Math.max(0,x.spendable.perDay))}. Não há quebra de caixa projetada nos próximos 30 dias.`}; }
  if (/quanto.*(posso|livre).*(gastar|usar)|quanto.*gastar|livre.*gastar/.test(q)) return { kind:'local', title:'Quanto você pode gastar', text:x.spendable.free >= 0 ? `Você tem ${money0(x.spendable.free)} livres até ${x.spendable.until}, cerca de ${money0(x.spendable.perDay)} por dia. Esse valor já desconta contas, faturas e a parte que falta da sua meta de guardar.` : `Seu livre está negativo em ${money0(Math.abs(x.spendable.free))}. Pelos dados atuais, contas, faturas e meta de guardar ultrapassam o saldo disponível até ${x.spendable.until}.` };
  if (/como.*(esta|vai).*mes|resumo.*mes|meu mes|gastei.*mes/.test(q)) return { kind:'local', title:'Seu mês agora', text:`Entraram ${money0(x.month.incomePaid)}, você gastou ${money0(x.month.spend)} e guardou ${money0(x.month.saved)}. O resultado do mês, considerando o que já está previsto, é ${money0(x.month.result)}.` };
  if (/previs|30 dias|7 dias|saldo futuro|vai faltar/.test(q)) return { kind:'local', title:'Sua previsão', text:x.forecast.riskDate ? `A projeção encontra risco de saldo negativo em ${naturalDate(x.forecast.riskDate)}, chegando a ${money0(x.forecast.riskBalance)}. Em 7 dias a estimativa é ${money0(x.forecast.day7)} e em 30 dias, ${money0(x.forecast.day30)}.` : `Não aparece saldo negativo nos próximos 30 dias. A estimativa é ${money0(x.forecast.day7)} em 7 dias e ${money0(x.forecast.day30)} em 30 dias.` };
  if (/cartao|fatura|limite/.test(q) && x.cards.length) { const c=x.cards.sort((a,b)=>b.used-a.used)[0]; return { kind:'local', title:'Seu cartão', text:`No ${c.name}, há ${money0(c.used)} comprometidos e ${money0(c.available)} de limite disponível. Pelo seu caixa projetado, o limite financeiramente seguro para novas compras agora é cerca de ${money0(c.safeToUse)}.` }; }
  if (/patrimonio|invest|reserva|guardad/.test(q)) return { kind:'local', title:'Seu patrimônio', text:`Seu total acompanhado no Bivvo é ${money0(x.wealth.total)}: ${money0(x.wealth.investments)} em investimentos e ${money0(x.wealth.goals)} em metas. A reserva marcada soma ${money0(x.wealth.reserve)}.` };
  if (/assinatura|recorr/.test(q)) return { kind:'local', title:'Assinaturas', text:`As recorrências identificadas equivalem a ${money0(x.commitments.subscriptionsMonthly)} por mês, ou aproximadamente ${money0(x.commitments.subscriptionsAnnual)} por ano.` };
  return null;
}

export function rayX(tools = toolResults()) {
  const notes=[];
  if (!tools.quality.hasBalanceBase) notes.push('Informe seu saldo atual para deixar as análises mais confiáveis.');
  if (tools.spendable.free < 0) notes.push(`Seu caixa está pressionado: faltam cerca de ${money0(Math.abs(tools.spendable.free))} até a próxima entrada considerada.`);
  else notes.push(`Você tem ${money0(tools.spendable.free)} livres no período, cerca de ${money0(tools.spendable.perDay)} por dia.`);
  if (tools.forecast.riskDate) notes.push(`Seu dinheiro pode não chegar até ${naturalDate(tools.forecast.riskDate)}. Proteger o essencial e reduzir gastos adiáveis antes dessa data é a prioridade.`);
  else notes.push('A projeção de 30 dias não cruza zero com os dados atuais.');
  if (!tools.forecast.riskDate && tools.spendable.free >= 0 && tools.month.incomePaid > 0) { const rate=tools.month.saved/tools.month.incomePaid; notes.push(rate >= .1 ? `Você guardou ${Math.round(rate*100)}% do que já entrou neste mês.` : `Você guardou ${Math.round(rate*100)}% do que já entrou neste mês. Quando o caixa estiver protegido, você pode revisar sua meta.`); }
  if (tools.month.topCategories[0]) notes.push(`${tools.month.topCategories[0].category} é sua maior categoria no mês, com ${money0(tools.month.topCategories[0].value)}.`);
  if (tools.commitments.installments3Months > 0) notes.push(`Parcelas futuras já comprometem ${money0(tools.commitments.installments3Months)} nos próximos 3 meses.`);
  return notes.slice(0,5);
}

export async function askAI(question, tools = toolResults()) {
  const token = await cloud.accessToken(); if (!token) throw new Error('Entre novamente para usar o Bivvo IA.');
  const r = await fetch('/api/assistant', { method:'POST', headers:{'Content-Type':'application/json', Authorization:'Bearer '+token}, body:JSON.stringify({ question:String(question||'').slice(0,500), tools }) });
  const j = await r.json().catch(()=>({}));
  if (j.usage?.used != null) setUsage('ai', j.usage.used);
  if (!r.ok) { const e=new Error(j.error || 'Não consegui responder agora.'); e.code=j.code; e.usage=j.usage; throw e; }
  return j;
}
export const aiUsage = () => getRemainingUsage('ai');
