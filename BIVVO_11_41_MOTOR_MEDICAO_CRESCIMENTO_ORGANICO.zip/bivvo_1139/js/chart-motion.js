/* Shared chart presentation: reveal on entry, linked highlights and safe text previews. */
const selector='.budget-infographic,.viz-donut svg,.dividend-chart-scroll svg,.viz-bars,.viz-progress,.ritmo-arc';
const seen=new WeakSet(), reduced=matchMedia('(prefers-reduced-motion: reduce)');
let tooltip;
function hide(){if(tooltip)tooltip.hidden=true;}
function preview(node,event){
 const text=node.getAttribute('aria-label')||node.querySelector('title')?.textContent;
 if(!text)return;
 if(!tooltip){tooltip=document.createElement('div');tooltip.className='chart-tooltip';tooltip.hidden=true;document.body.append(tooltip);}
 tooltip.textContent=text;tooltip.hidden=false;
 const rect=node.getBoundingClientRect(),x=event.clientX||rect.left+rect.width/2,y=event.clientY||rect.top;
 tooltip.style.left=Math.max(8,Math.min(innerWidth-tooltip.offsetWidth-8,x-tooltip.offsetWidth/2))+'px';
 tooltip.style.top=Math.max(8,Math.min(innerHeight-tooltip.offsetHeight-8,y-tooltip.offsetHeight-14))+'px';
}
const observer=new IntersectionObserver(entries=>entries.forEach(({target,isIntersecting})=>{
 if(!isIntersecting)return;
 target.classList.add('chart-visible');observer.unobserve(target);
 if(!reduced.matches){
  const shapes=target.matches('svg')?target.querySelectorAll('path,circle.viz-seg,rect:not([fill="transparent"]),line[stroke="#00876c"]'):[];
  shapes.forEach((shape,i)=>shape.animate([{opacity:0},{opacity:1}],{duration:650,delay:Math.min(i*35,350),easing:'ease-out'}));
 }
}),{threshold:.12});
function enhance(root){
 const charts=[...(root.matches?.(selector)?[root]:[]),...(root.querySelectorAll?.(selector)||[])];
 charts.forEach(chart=>{
  if(chart.matches('.ritmo-arc'))chart.setAttribute('tabindex','0');
  if(seen.has(chart))return;seen.add(chart);chart.classList.add('chart-enhanced');observer.observe(chart);
  const clear=()=>{chart.querySelectorAll('.chart-active,.chart-muted').forEach(x=>x.classList.remove('chart-active','chart-muted'));hide();};
  const enter=e=>{
   const node=e.target.closest?.('[role="button"],button,.ritmo-arc');if(!node||!chart.contains(node))return;
   const key=node.dataset.chartKey;
   if(key!==undefined)chart.querySelectorAll('[data-chart-key]').forEach(x=>x.classList.add(x.dataset.chartKey===key?'chart-active':'chart-muted'));
   preview(node,e);
  };
  chart.addEventListener('pointerover',enter);chart.addEventListener('focusin',enter);
  chart.addEventListener('pointerout',clear);chart.addEventListener('focusout',clear);chart.addEventListener('click',hide);
 });
}
new MutationObserver(records=>{for(const record of records)for(const node of record.addedNodes)if(node.nodeType===1)enhance(node);if(tooltip&&!document.querySelector('.chart-enhanced:focus-within,.chart-enhanced:hover'))hide();}).observe(document.documentElement,{childList:true,subtree:true});
enhance(document.documentElement);
addEventListener('scroll',hide,true);addEventListener('resize',hide);addEventListener('keydown',e=>{if(e.key==='Escape')hide();});
