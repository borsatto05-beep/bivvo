/* Bivvo 10.1 — gráficos SVG leves, interativos e acessíveis. */
import { h, s as svg, money0 } from './util.js';
export function donut(items, { center='Total', onPick }={}) {
  const total=items.reduce((a,x)=>a+(+x.value||0),0), r=42, c=2*Math.PI*r; let acc=0;
  const root=h('div.viz-donut');
  const chart=svg('svg',{viewBox:'0 0 120 120',role:'img','aria-label':`${center}: ${money0(total)}`},svg('circle',{cx:60,cy:60,r,class:'viz-track'}));
  items.filter(x=>x.value>0).forEach((x,i)=>{ const frac=x.value/total, len=frac*c; const seg=svg('circle',{cx:60,cy:60,r,class:`viz-seg v${i%6}`,transform:'rotate(-90 60 60)',pathLength:'100','stroke-dasharray':`${frac*100} ${100-frac*100}`,'stroke-dashoffset':`${-acc*100}`,tabindex:'0',role:'button','aria-label':`${x.label}: ${money0(x.value)}, ${Math.round(frac*100)}%`}); const pick=()=>onPick?.({...x,share:frac,total}); seg.addEventListener('click',pick); seg.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();pick();}}); chart.append(seg); acc+=frac; });
  chart.append(svg('text',{x:60,y:56,'text-anchor':'middle',class:'viz-center-label'},center),svg('text',{x:60,y:72,'text-anchor':'middle',class:'viz-center-value'},money0(total)));
  root.append(chart); return root;
}
export function bars(items,{onPick}={}){ const max=Math.max(1,...items.map(x=>+x.value||0)); return h('div.viz-bars',{role:'list'},items.map((x,i)=>h('button.viz-bar',{type:'button',role:'listitem',onclick:()=>onPick?.(x),'aria-label':`${x.label}: ${money0(x.value)}`},h('span.viz-bar-label',x.label),h('span.viz-bar-track',h('i',{class:`v${i%6}`,vars:{'--p':`${Math.max(2,x.value/max*100)}%`}})),h('b',money0(x.value))))); }
export function progressBar(value,max,label='Progresso'){ const pct=max?Math.min(100,Math.max(0,value/max*100)):0; return h('div.viz-progress',h('div',h('span',label),h('b',`${Math.round(pct)}%`)),h('span.viz-progress-track',h('i',{vars:{'--p':pct+'%'}}))); }

/* Pizza com legenda e acesso por teclado. */
export function pie(items, { label='Gastos por categoria', onPick }={}) {
  const entries=items.filter(x=>Number(x.value)>0), total=entries.reduce((sum,x)=>sum+Number(x.value),0);
  if(!total) return h('p.muted', 'Nenhum gasto registrado neste mês.');
  const chart=svg('svg',{viewBox:'0 0 200 200',role:'group','aria-label':label});
  const legend=h('div.budget-pie-legend');
  let angle=-Math.PI/2;
  entries.forEach((item,i)=>{
    const share=Number(item.value)/total, end=angle+share*2*Math.PI;
    const color='hsl('+((275+i*137.508)%360).toFixed(1)+' 62% 48%)';
    const description=item.label+': '+money0(item.value)+' · '+(share*100).toLocaleString('pt-BR',{maximumFractionDigits:1})+'%';
    const pick=()=>onPick?.({...item,share,total});
    const attrs={fill:color,stroke:'var(--card)', 'stroke-width':1.5,tabindex:'0',role:'button','aria-label':description};
    const slice=entries.length===1
      ?svg('circle',{...attrs,cx:100,cy:100,r:94})
      :svg('path',{...attrs,d:'M 100 100 L '+(100+94*Math.cos(angle))+' '+(100+94*Math.sin(angle))+' A 94 94 0 '+(share>.5?1:0)+' 1 '+(100+94*Math.cos(end))+' '+(100+94*Math.sin(end))+' Z'});
    slice.append(svg('title',{},description));
    slice.addEventListener('click',pick);
    slice.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();pick();}});
    chart.append(slice);
    legend.append(h('button',{type:'button',onclick:pick,'aria-label':description},
      h('i',{'aria-hidden':'true',vars:{'--slice-color':color}}),h('span',item.label),
      h('b',money0(item.value)),h('small',(share*100).toLocaleString('pt-BR',{maximumFractionDigits:1})+'%')));
    angle=end;
  });
  return h('div.budget-pie',chart,legend);
}
