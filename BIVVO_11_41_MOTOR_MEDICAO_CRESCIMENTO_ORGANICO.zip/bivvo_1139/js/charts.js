/* Bivvo 10.1 — gráficos SVG leves, interativos e acessíveis. */
import { h, s as svg, money0 } from './util.js';
export function donut(items, { center='Total', onPick }={}) {
  const total=items.reduce((a,x)=>a+(+x.value||0),0), r=42, c=2*Math.PI*r; let acc=0;
  const root=h('div.viz-donut');
  const chart=svg('svg',{viewBox:'0 0 120 120',role:'img','aria-label':`${center}: ${money0(total)}`},svg('circle',{cx:60,cy:60,r,class:'viz-track'}));
  items.filter(x=>x.value>0).forEach((x,i)=>{ const frac=x.value/total, len=frac*c; const seg=svg('circle',{cx:60,cy:60,r,class:`viz-seg v${i%6}`,transform:'rotate(-90 60 60)',pathLength:'100','stroke-dasharray':`${frac*100} ${100-frac*100}`,'stroke-dashoffset':`${-acc*100}`,tabindex:'0',role:'button','aria-label':`${x.label}: ${money0(x.value)}, ${Math.round(frac*100)}%`}); const pick=()=>onPick?.({...x,share:frac,total}); seg.addEventListener('click',pick); seg.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();pick();}}); chart.append(seg); acc+=frac; });
  chart.append(svg('text',{x:60,y:56,'text-anchor':'middle',class:'viz-center-label'},center),svg('text',{x:60,y:72,'text-anchor':'middle',class:'viz-center-value'},money0(total)));
  root.append(chart); return root;
}
export function bars(items,{onPick}={}){ const max=Math.max(1,...items.map(x=>+x.value||0)); return h('div.viz-bars',{role:'list'},items.map((x,i)=>h('button.viz-bar',{type:'button',role:'listitem',onclick:()=>onPick?.(x),'aria-label':`${x.label}: ${money0(x.value)}`},h('span.viz-bar-label',x.label),h('span.viz-bar-track',h('i',{class:`v${i%6}`,vars:{'--p':`${Math.max(2,x.value/max*100)}%`}})),h('b',money0(x.value))))); }
export function progressBar(value,max,label='Progresso'){ const pct=max?Math.min(100,Math.max(0,value/max*100)):0; return h('div.viz-progress',h('div',h('span',label),h('b',`${Math.round(pct)}%`)),h('span.viz-progress-track',h('i',{vars:{'--p':pct+'%'}}))); }

/* Infográfico de orçamento: fatias, chamadas externas e tabela acessível. */
export function pie(items, { label='Distribuição dos gastos por categoria', onPick, caption='Toque nas fatias ou nos blocos para ver os detalhes. Percentuais sobre o total de gastos do mês.', groupLabel='Demais categorias', collapsible=false }={}) {
  const entries=items.filter(x=>Number(x.value)>0).sort((a,b)=>b.value-a.value);
  const total=entries.reduce((sum,x)=>sum+Number(x.value),0);
  if(!total) return h('div.budget-pie-empty',h('b','Seu mapa de gastos começa aqui'),h('p','Nenhum gasto registrado neste mês. Os lançamentos vão preencher o gráfico automaticamente.'));
  const palette=['#7840c4','#00876c','#e5b333','#2879c0','#d94778','#e47a36','#5862ad','#8b969d'];
  const pct=v=>(v*100).toLocaleString('pt-BR',{maximumFractionDigits:1})+'%';
  const grouped=entries.length>8?[...entries.slice(0,7),{label:groupLabel,value:entries.slice(7).reduce((s,x)=>s+Number(x.value),0),members:entries.slice(7)}]:entries;
  const chart=svg('svg',{viewBox:'0 0 900 520',role:'group','aria-label':label,class:'budget-infographic'});
  const calls=[];
  let angle=-Math.PI/2;
  const wrap=(value,max)=>{const result=[];for(const word of value.split(' ')){if(!result.length||result[result.length-1].length+word.length+1>max)result.push(word);else result[result.length-1]+=' '+word;}return result;};
  grouped.forEach((item,i)=>{
    const share=Number(item.value)/total,end=angle+share*2*Math.PI,mid=(angle+end)/2,color=palette[i];
    const pick=()=>onPick?.({...item,share,total});
    const description=item.label+': '+money0(item.value)+' · '+pct(share);
    const attrs={'data-chart-key':String(i),fill:color,stroke:'var(--surface)','stroke-width':2,tabindex:'0',role:'button','aria-label':description};
    const slice=grouped.length===1?svg('circle',{...attrs,cx:450,cy:260,r:198}):svg('path',{...attrs,d:'M 450 260 L '+(450+198*Math.cos(angle))+' '+(260+198*Math.sin(angle))+' A 198 198 0 '+(share>.5?1:0)+' 1 '+(450+198*Math.cos(end))+' '+(260+198*Math.sin(end))+' Z'});
    slice.append(svg('title',{},description));slice.addEventListener('click',pick);
    slice.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();pick();}});
    chart.append(slice);
    if(share>=.12){
      const x=grouped.length===1?450:450+119*Math.cos(mid),y=grouped.length===1?240:260+119*Math.sin(mid);
      const lines=wrap(item.label,15),dark=i===2;
      const text=svg('text',{x,y:y-(lines.length-1)*9,'text-anchor':'middle',class:'budget-slice-label',fill:dark?'#282010':'#fff','pointer-events':'none'});
      lines.forEach((line,j)=>text.append(svg('tspan',{x,dy:j?18:0},line)));
      text.append(svg('tspan',{x,dy:25,class:'budget-slice-percent'},pct(share)));
      chart.append(text);
    }
    calls.push({item,share,color,mid,x:450+188*Math.cos(mid),y:260+188*Math.sin(mid),right:Math.cos(mid)>=0,pick,description});
    angle=end;
  });
  for(const right of [false,true]){
    const side=calls.filter(c=>c.right===right).sort((a,b)=>a.y-b.y);
    side.forEach((c,j)=>{
      const y=side.length===1?260:74+j*(372/(side.length-1));
      const x=right?704:12,edge=right?704:196,elbow=right?680:220;
      chart.append(svg('polyline',{points:c.x+','+c.y+' '+elbow+','+y+' '+edge+','+y,fill:'none',stroke:c.color,'stroke-width':1.5,'stroke-dasharray':'3 3','pointer-events':'none'}),
        svg('circle',{cx:c.x,cy:c.y,r:3.5,fill:c.color,stroke:'var(--surface)','stroke-width':2,'pointer-events':'none'}));
      const block=svg('g',{tabindex:'0',role:'button','aria-label':c.description,class:'budget-callout','data-chart-key':String(grouped.indexOf(c.item))});
      block.append(svg('rect',{x,y:y-31,width:184,height:62,rx:10,fill:'var(--surface)',stroke:c.color,'stroke-width':1.5}));
      const lines=wrap(c.item.label,23);
      const title=svg('text',{x:x+12,y:y-9,class:'budget-callout-name'});
      lines.slice(0,2).forEach((line,k)=>title.append(svg('tspan',{x:x+12,dy:k?14:0},line)));
      block.append(title,svg('text',{x:x+12,y:y+23,class:'budget-callout-value'},pct(c.share)+' · '+money0(c.item.value)));
      block.addEventListener('click',c.pick);block.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();c.pick();}});
      chart.append(block);
    });
  }
  const table=h('div.budget-breakdown',{'aria-label':'Detalhamento de todas as categorias'},
    h('div.budget-breakdown-head',h('span','Categoria'),h('span','Valor'),h('span','% do total')));
  entries.forEach((item,i)=>{
    const color=palette[Math.min(i,7)],share=Number(item.value)/total;
    table.append(h('button',{type:'button',onclick:()=>onPick?.({...item,share,total}),'aria-label':item.label+': '+money0(item.value)+' · '+pct(share)},
      h('span',h('i',{'aria-hidden':'true',vars:{'--slice-color':color}}),item.label),h('b',money0(item.value)),h('small',pct(share))));
  });
  const breakdown=collapsible?h('details.chart-breakdown-toggle',h('summary','Ver detalhamento ('+entries.length+')'),table):table;
  return h('div.budget-pie',h('div.budget-graphic-window',chart),h('p.budget-chart-caption',caption),breakdown);
}
