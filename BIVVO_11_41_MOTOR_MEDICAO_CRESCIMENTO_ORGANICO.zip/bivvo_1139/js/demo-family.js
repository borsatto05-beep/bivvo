/* Espaço familiar fictício. Somente memória do estado de demonstração. */
import * as store from './store.js';
import { uid } from './util.js';
export function demoFamily(){
 const s=store.getState();
 if(!s.profile.demoFamily){
  const me={id:'demo-owner',user_id:'demo-ana',display_name:'Ana',role:'owner'};
  s.profile.demoFamily={active:true,family:{id:'demo-family',name:'Família de demonstração'},membership:me,members:[me,{id:'demo-editor',user_id:'demo-lucas',display_name:'Lucas',role:'editor'}],shared:s.transactions.filter(t=>t.type==='expense'&&t.cat==='Moradia').slice(-6).map(t=>({id:uid(),user_id:me.user_id,source_id:t.id,date:t.date,description:t.desc,category:t.cat,type:t.type,value:t.value}))};
 }
 return s.profile.demoFamily;
}
export function demoFamilyCall(action,body={}){
 let d=demoFamily();
 if(action==='get')return {data:d};
 if(action==='invite')return {code:'DEMO-'+body.role,simulated:true};
 store.commit(s=>{
  if(action==='create'||action==='accept'){d.family.name=body.name||'Família de demonstração';d.active=true;}
  if(action==='role'){const m=d.members.find(x=>x.id===body.memberId);if(m&&m.role!=='owner')m.role=body.role;}
  if(action==='remove'){const m=d.members.find(x=>x.id===body.memberId);d.members=d.members.filter(x=>x.id!==body.memberId);if(m)d.shared=d.shared.filter(x=>x.user_id!==m.user_id);}
  if(action==='share_transaction'){const t=body.transaction;d.shared=d.shared.filter(x=>x.source_id!==t.sourceId);d.shared.push({id:uid(),source_id:t.sourceId,user_id:d.membership.user_id,date:t.date,description:t.desc,category:t.cat,type:t.type,value:t.value});}
  if(action==='unshare_transaction')d.shared=d.shared.filter(x=>x.source_id!==body.sourceId);
  if(action==='leave')d.active=false;
  s.profile.demoFamily=d;
 },{reason:'demo-family'});
 return {data:d,simulated:true};
}
