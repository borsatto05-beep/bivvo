/* Histórico da carteira: fluxos de capital separados de rendimento/valorização. */
import { dividendRows, dividendAssetId } from './investment-income.js';
import { today, ymOf, round2, num, addMonthsYM } from './util.js';
import { investmentValue, isPaid, isWithdraw } from './finance.js';
export function investmentMovements(s){
 const rows=[];
 for(const t of s.transactions||[]){
  if(!isPaid(t)||t.date>today())continue;
  const deposit=t.type==='expense'&&(t.investmentId||t.cat==='Investimentos')&&!t.goalId;
  const withdrawal=t.type==='income'&&!t.goalId&&(t.transactionRole==='investment_withdrawal'||(isWithdraw(t)&&(t.investmentId||t.cat==='Investimentos'||/resgate/i.test(t.desc||''))));
  if(deposit||withdrawal)rows.push({id:t.id,date:t.date,value:num(t.value),type:deposit?'deposit':'withdrawal',description:t.desc,source:'Extrato',investmentId:t.investmentId});
 }
 for(const m of s.profile?.investmentMovements||[]){
  if(['deposit','withdrawal'].includes(m.type)&&m.value>0&&m.date<=today())rows.push({...m,value:num(m.value),source:'Histórico informado'});
 }
 for(const inv of new Map([...(s.profile?.investmentArchive||[]),...(s.investments||[])].map(x=>[x.id,x])).values()){
  if(inv.purchaseDate&&inv.purchaseDate<=today()&&!rows.some(x=>x.type==='deposit'&&(x.id===inv.txId||(x.investmentId===inv.id&&(x.source==='Extrato'||x.date===inv.purchaseDate))))){
   rows.push({id:'legacy-'+inv.id,date:inv.purchaseDate,value:num(inv.costBasis??inv.value),type:'deposit',description:'Aplicação em '+inv.name,source:'Cadastro do investimento',investmentId:inv.id});
  }
 }
 return rows;
}
export function investmentEvolution(s,months){
 const movements=investmentMovements(s),current=ymOf(today());
 return months.map(month=>{
  const items=movements.filter(x=>ymOf(x.date)===month);
  const deposits=round2(items.filter(x=>x.type==='deposit').reduce((a,x)=>a+x.value,0));
  const withdrawals=round2(items.filter(x=>x.type==='withdrawal').reduce((a,x)=>a+x.value,0));
  const base=portfolioMonthBalance(s,addMonthsYM(month,-1)),actual=portfolioMonthBalance(s,month);
  const balance=actual.value;
  const opening=base.value;
  const gain=balance!==null&&opening!==null?round2(balance-opening-deposits+withdrawals):null;
  const knownIds=new Set(actual.assets.map(x=>x.id));
  const payments=dividendRows(s).filter(t=>isPaid(t)&&t.date<=today()&&ymOf(t.date)===month);
  const dividendItems=payments.filter(t=>knownIds.has(dividendAssetId(t,s)));
  const dividends=round2(dividendItems.reduce((a,t)=>a+num(t.value),0));
  const unlinkedDividends=round2(payments.filter(t=>!knownIds.has(dividendAssetId(t,s))).reduce((a,t)=>a+num(t.value),0));
  const totalReturn=gain===null?null:round2(gain+dividends);
  let fixedGain=0,marketGain=0;
  const unallocated=items.some(x=>!x.investmentId);
  for(const asset of actual.assets){
    const prev=base.assets.find(x=>x.id===asset.id);
    if(!prev||asset.value===null||prev.value===null||unallocated){if(['CDB','Renda fixa','Poupança'].includes(asset.type))fixedGain=null;else marketGain=null;continue;}
    const flows=items.filter(x=>x.investmentId===asset.id),net=flows.reduce((a,x)=>a+(x.type==='deposit'?x.value:-x.value),0);
    const growth=asset.value-prev.value-net;
    if(['CDB','Renda fixa','Poupança'].includes(asset.type)){if(fixedGain!==null)fixedGain+=growth;}else if(marketGain!==null)marketGain+=growth;
  }
  if(fixedGain!==null)fixedGain=round2(fixedGain);
  if(marketGain!==null)marketGain=round2(marketGain);
  const rate=totalReturn!==null&&opening>0&&deposits===0&&withdrawals===0?totalReturn/opening:null;
  return {assets:actual.assets,missing:actual.missing,estimated:actual.estimated||base.estimated,dividendItems,unlinkedDividends,fixedGain,marketGain,dividends,totalReturn,month,items,deposits,withdrawals,net:round2(deposits-withdrawals),opening,balance,gain,rate,partial:month===current,balanceSource:'Valores dos ativos cadastrados'};
 });
}

/* Valores mensais por ativo. Não aplica cotação atual a meses passados. */
export function assetMonthlyValue(inv,month,s){
 const [year,m]=month.split('-').map(Number);
 const end=month+'-'+String(new Date(year,m,0).getDate()).padStart(2,'0');
 const cutoff=month===ymOf(today())?today():end;
 const lastWeekday=new Date(year,m,0,12);while([0,6].includes(lastWeekday.getDay()))lastWeekday.setDate(lastWeekday.getDate()-1);
 const minClosingDate=month+'-'+String(lastWeekday.getDate()).padStart(2,'0');
 if(inv.purchaseDate&&inv.purchaseDate>cutoff||inv.closedAt&&inv.closedAt<=cutoff)return {value:0,source:'Fora da posição neste mês',estimated:false};
 const records=(s.profile?.investmentValuations||[]).filter(r=>r.investmentId===inv.id&&ymOf(r.date)===month&&r.date<=cutoff&&(month===ymOf(today())||r.date>=minClosingDate)&&Number.isFinite(Number(r.value))&&Number(r.value)>=0).sort((a,b)=>b.date.localeCompare(a.date));
 const manual=(s.profile?.investmentMovements||[]).filter(m=>m.investmentId===inv.id&&ymOf(m.date)===month&&m.date<=cutoff&&m.createdAt);
 if(manual.some(m=>!records.some(r=>r.date>=m.date&&(r.recordedAt||0)>=m.createdAt)))return {value:null,source:'Informe a posição real após a movimentação histórica para apurar o rendimento',estimated:false};
 if(records.length)return {value:round2(records[0].value),source:records[0].source+' · '+records[0].date,estimated:false};
 if(['CDB','Renda fixa'].includes(inv.type)&&inv.yieldRate!=null&&inv.purchaseDate){
  let label='Taxa prefixada cadastrada';
  if(inv.yieldType==='Pós-fixado'){
   if(!['CDI','SELIC'].includes(inv.yieldIndex||'CDI'))return {value:null,source:'Falta histórico do indexador '+(inv.yieldIndex||''),estimated:false};
   if(month!==ymOf(today()))return {value:null,source:'Sem série histórica do '+(inv.yieldIndex||'CDI')+'. Registre o saldo real da instituição neste mês.',estimated:false};
   label='Estimativa com taxa cadastrada e '+(inv.yieldIndex||'CDI')+' de referência; não é CDI histórico';
  }
  const anchor=(s.profile?.investmentValuations||[]).filter(r=>r.investmentId===inv.id&&r.date<cutoff&&Number.isFinite(Number(r.value))).sort((a,b)=>b.date.localeCompare(a.date))[0];
  const position=anchor?{...inv,value:anchor.value,purchaseDate:anchor.date}:inv;
  return {value:investmentValue(position,s,cutoff),source:label+' · antes de impostos',estimated:true};
 }
 if(month===ymOf(today())&&!inv.closedAt){if(['Ações','Fundos','Cripto'].includes(inv.type)&&(!inv.quoteAt||ymOf(inv.quoteAt)!==month))return {value:null,source:'Atualize a cotação deste mês ou informe o valor real do ativo',estimated:false};return {value:investmentValue(inv,s),source:inv.quoteAt?'Cotação registrada em '+inv.quoteAt:'Valor atual cadastrado',estimated:false};}
 return {value:null,source:'Sem cotação ou valor histórico deste ativo',estimated:false};
}
export function portfolioMonthBalance(s,month){
 const map=new Map([...(s.profile?.investmentArchive||[]),...(s.investments||[])].map(x=>[x.id,x]));
 const assets=[...map.values()].map(inv=>({id:inv.id,name:inv.name,type:inv.type,...assetMonthlyValue(inv,month,s)}));
 const missing=assets.filter(x=>x.value===null);
 return {value:missing.length?null:round2(assets.reduce((a,x)=>a+x.value,0)),assets,estimated:assets.some(x=>x.estimated),missing};
}
