/* Identificação de recebimentos dos investimentos; não inclui resgates. */
const normalized=value=>String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
export function isInvestmentDividend(t){
 if(t.type!=='income'||t.kind==='opening'||t.cat==='Saldo inicial'||t.kind==='withdraw'||t.goalId||t.transactionRole==='loan_principal_return')return false;
 const category=normalized(t.cat),description=normalized(t.desc);
 const explicit=t.transactionRole==='investment_dividend';
 if(!explicit&&(['salario','freelance','reembolso','venda','vale/beneficio'].includes(category)||/\b(resgate|resgatado|venda de (ativo|acao|cota)|devolucao do principal)\b/.test(description)||t.transactionRole==='loan_interest_income'||category==='juros / emprestimo'))return false;
 return explicit||/^(rendimentos?|proventos?|dividendos?|jcp|juros sobre (o )?capital proprio|cupons?|juros de investimentos)$/.test(category)||
   /\b(dividendos?|proventos?|jcp|juros sobre (o )?capital proprio|rendimento(s)? (de|do|da|sobre)|cupom (de|do))\b/.test(description);
}
export const dividendRows=s=>(s.transactions||[]).filter(isInvestmentDividend);
export function dividendAssetId(t,s){
 if(t.investmentId)return t.investmentId;
 const text=String(t.desc||'').toUpperCase();
 const matches=[...(s.investments||[]),...(s.profile?.investmentArchive||[])].filter(x=>{
  const ticker=String(x.ticker||x.symbol||x.name||'').trim().toUpperCase().replace(/\.SA$/,'');
  return /^[A-Z][A-Z0-9]{3}\d{1,2}$/.test(ticker)&&text.split(/[^A-Z0-9]+/).includes(ticker);
 });
 const ids=[...new Set(matches.map(x=>x.id))];
 return ids.length===1?ids[0]:null;
}
