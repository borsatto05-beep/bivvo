/* Classificação local de emissores conhecidos. Setor manual sempre tem prioridade. */
const groups={
 'Bancos':['BBAS','BBDC','ITUB','SANB','BPAC','ABCB','BRSR','BMGB','BPAN','PINE'],
 'Serviços financeiros':['B3SA','ITSA','CIEL','PSSA','BBSE','CXSE','IRBR'],
 'Petróleo e gás':['PETR','PRIO','RECV','BRAV','CSAN','UGPA','VBBR'],
 'Mineração':['VALE','CMIN','BRAP'],
 'Siderurgia':['CSNA','GGBR','GOAU','USIM','FESA'],
 'Energia elétrica':['TAEE','EGIE','CPFE','CMIG','CPLE','ENEV','ENGI','EQTL','NEOE','AURE','ALUP','AFLT','AXIA','ELET'],
 'Saúde':['HAPV','HYPE','RDOR','FLRY','DASA','ODPV','QUAL','PNVL','RADL'],
 'Saneamento':['SBSP','SAPR','CSMG','ORVR'],
 'Telecomunicações':['VIVT','TIMS','FIQE'],
 'Alimentos e bebidas':['ABEV','JBSS','JBSS32','BEEF','MRFG','BRFS','MDIA','SMTO','CAML','SLCE','AGRO','TTEN','SOJA'],
 'Varejo':['MGLU','LREN','AMER','BHIA','ASAI','CRFB','PETZ','CEAB','AZZA','VIVA','GMAT','GRND','ARZZ'],
 'Indústria':['INTB','WEGE','EMBR','TUPY','RAPT','FRAS','POMO','ROMI','LEVE','SHUL','KEPL'],
 'Papel e celulose':['SUZB','KLBN','RANI'],
 'Construção e imóveis':['CYRE','MRVE','DIRR','EZTC','EVEN','TEND','TRIS','CURY','JHSF','MULT','IGTI','ALOS','LOGG'],
 'Transportes e logística':['RAIL','RUMO','CCRO','MOTV','ECOR','STBP','HBSA','TGMA','PORT','VAMO','RENT','MOVI','SIMH'],
 'Tecnologia':['TOTS','LWSA','POSI','BMOB','SQIA'],
 'Educação':['YDUQ','COGN','ANIM','CSED'],
 'Química e petroquímica':['BRKM','UNIP','DEXP','FHER'],
 'Madeira e papel':['DXCO','EUCA'],
 'Fundos imobiliários · recebíveis':['MXRF11','KNCR11','KNIP11','KNSC11','CPTS11','RBRR11','RBRY11','HGCR11','IRDM11','IRIM11','VGIR11','VGIP11','RECR11','MCCI11','CVBI11'],
 'Fundos imobiliários · logística':['HGLG11','BTLG11','XPLG11','VILG11','LVBI11','BRCO11','HSLG11','GGRC11','PATL11'],
 'Fundos imobiliários · shopping centers':['XPML11','VISC11','HGBS11','HSML11','MALL11','ABCP11'],
 'Fundos imobiliários · escritórios':['PVBI11','HGRE11','JSRE11','VINO11','RCRB11','RECT11'],
 'Fundos imobiliários · diversificados':['KNRI11','HGRU11','TRXF11','ALZR11','RBVA11','RZTR11','GARE11'],
 'ETFs · ações brasileiras':['BOVA11','BOVV11','SMAL11','DIVO11','BOVB11','BRAX11','BBOV11','PIBB11','NDIV11'],
 'ETFs · ações internacionais':['IVVB11','SPXI11','WRLD11','NASD11','ACWI11','SPXB11'],
 'ETFs · renda fixa':['IMAB11','B5P211','IRFM11','LFTS11','B5MB11'],
 'ETFs · criptoativos':['HASH11','QBTC11','QETH11']
};
const catalog=new Map(Object.entries(groups).flatMap(([sector,keys])=>keys.map(key=>[key,sector])));
const translations={
 'Financial Services':'Serviços financeiros','Financials':'Serviços financeiros','Energy':'Petróleo e gás','Utilities':'Serviços de utilidade pública',
 'Healthcare':'Saúde','Health Care':'Saúde','Basic Materials':'Materiais básicos','Materials':'Materiais básicos',
 'Industrials':'Indústria','Technology':'Tecnologia','Information Technology':'Tecnologia','Real Estate':'Imóveis',
 'Communication Services':'Telecomunicações e comunicação','Consumer Defensive':'Consumo não cíclico','Consumer Staples':'Consumo não cíclico',
 'Consumer Cyclical':'Consumo cíclico','Consumer Discretionary':'Consumo cíclico'
};
const valid=v=>typeof v==='string'&&v.trim()&&!['não informado','nao informado','n/a','unknown','setor não identificado'].includes(v.trim().toLowerCase());
export function investmentSectorInfo(x){
 if(valid(x.sector))return {label:x.sector.trim(),source:'Informado no cadastro'};
 const raw=String(x.ticker||x.symbol||x.name||'').trim().toUpperCase().replace(/\.SA$/,'');
 const ticker=raw.match(/\b[A-Z][A-Z0-9]{3}[0-9]{1,2}\b/)?.[0]||raw;
 const known=catalog.get(ticker)||(/^[A-Z][A-Z0-9]{3}\d{1,2}$/.test(ticker)?catalog.get(ticker.replace(/\d{1,2}$/, '')):null);
 if(known)return {label:known,source:'Classificação local do ticker '+ticker};
 if(valid(x.quoteSector))return {label:translations[x.quoteSector]||x.quoteSector.trim(),source:'Informado pelo provedor de cotações'};
 if(['CDB','Renda fixa'].includes(x.type))return {label:'Renda fixa',source:'Classe do investimento'};
 if(x.type==='Poupança')return {label:'Poupança',source:'Classe do investimento'};
 if(x.type==='Cripto')return {label:'Criptoativos',source:'Classe do investimento'};
 return {label:'Setor não identificado',source:'Informe o setor ao editar o investimento'};
}
export const investmentSector=x=>investmentSectorInfo(x).label;
