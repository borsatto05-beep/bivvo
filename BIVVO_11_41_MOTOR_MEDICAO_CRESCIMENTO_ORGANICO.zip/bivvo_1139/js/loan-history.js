/* Rebuild a loan from its origin, payments and explicit renewals. No cash entry is left behind. */
import {round2,addMonthsDate,uid} from './util.js';
const base=l=>round2(l.interestMode==='fixed'?Number(l.interestFixed||0):l.principal*Number(l.interestRate||0)/100);
export function loanHistory(s,id){
 const loan=s.loans.find(x=>x.id===id);if(!loan)throw Error('Contrato não encontrado.');
 const cycles=s.loanCycles.filter(x=>x.loanId===id),payments=s.loanPayments.filter(x=>x.loanId===id);
 // Old automatic cycles did not carry the payment ID. Pair them in recorded order.
 const automatic=cycles.filter(x=>x.automatic),renewed=payments.filter(x=>x.autoRenewed);
 automatic.forEach((x,i)=>{if(!x.paymentId&&renewed[i])x.paymentId=renewed[i].id;});
 const events=[...payments.map(x=>({kind:'payment',item:x})),...cycles.filter(x=>x.type==='renewal'&&!x.automatic).map(x=>({kind:'renewal',item:x}))];
 events.sort((a,b)=>String(a.item.date).localeCompare(String(b.item.date))||Number(a.item.createdAt||(a.kind==='renewal'?8640000000000000:0))-Number(b.item.createdAt||(b.kind==='renewal'?8640000000000000:0)));
 const origin=cycles.find(x=>x.type==='created');
 const initial=loan.historyOrigin||{principal:Number(origin?.principal??loan.principalOriginal),interestDue:Number(origin?.interest??base({...loan,principal:Number(loan.principalOriginal)})),due:origin?.due||loan.due,interestMode:loan.interestMode,interestRate:loan.interestRate,interestFixed:loan.interestFixed,periodicity:loan.periodicity,status:'open'};
 if(!loan.historyOrigin){
  if(origin&&initial.interestMode==='percent'&&initial.principal)initial.interestRate=round2(initial.interestDue/initial.principal*100);
  if(origin&&initial.interestMode==='fixed')initial.interestFixed=initial.interestDue;
  loan.historyOrigin={...initial};
 }
 return {loan,events,initial:{...initial},automatic};
}
export function rebuildLoan(s,id){
 const {loan,events,initial,automatic}=loanHistory(s,id),state={...initial};
 const oldTx=s.transactions.filter(t=>t.loanId===id&&['loan_principal_return','loan_interest_income'].includes(t.transactionRole));
 s.transactions=s.transactions.filter(t=>!oldTx.includes(t));
 s.loanCycles=s.loanCycles.filter(c=>c.loanId!==id||!c.automatic);
 for(const {kind,item} of events)if(kind==='renewal'&&item.rate===undefined)item.rate=state.interestMode==='fixed'?item.interest:(item.principal?item.interest/item.principal*100:state.interestRate);
 for(const {kind,item} of events){
  item.before={...state};
  if(kind==='renewal'){
   const capital=item.capitalize??Number(item.capitalized||0)>0;
   if(capital){item.capitalized=state.interestDue;state.principal=round2(state.principal+state.interestDue);state.interestDue=0;}else item.capitalized=0;
   if(item.rate===undefined)item.rate=state.interestMode==='fixed'?item.interest:(item.principal?item.interest/item.principal*100:state.interestRate);
   if(state.interestMode==='fixed')state.interestFixed=item.rate;else state.interestRate=item.rate;
   state.due=item.due;state.status='open';item.principal=state.principal;item.interest=base(state);state.interestDue=round2(state.interestDue+item.interest);
  }else{
   const total=round2(state.principal+state.interestDue);
   if(item.amount>total+.004)throw Error('Um pagamento posterior ultrapassa o saldo recalculado. Corrija esse pagamento primeiro.');
   item.interest=Math.min(item.amount,state.interestDue);item.principal=round2(item.amount-item.interest);
   state.principal=round2(state.principal-item.principal);state.interestDue=round2(state.interestDue-item.interest);
   item.autoRenewed=state.periodicity==='monthly'&&state.principal>.004&&state.interestDue<=.004&&!item.autoRenewDisabled;
   state.status=state.principal+state.interestDue<=.004?'paid':'open';
   if(item.autoRenewed){state.due=addMonthsDate(state.due,1);state.interestDue=base(state);const old=automatic.find(c=>c.paymentId===item.id);s.loanCycles.push({id:old?.id||uid(),loanId:id,paymentId:item.id,date:item.date,due:state.due,principal:state.principal,interest:state.interestDue,capitalized:0,type:'renewal',automatic:true,createdAt:item.createdAt});}
   for(const [part,role,label] of [['principal','loan_principal_return','Principal recebido'],['interest','loan_interest_income','Juros recebidos']])if(item[part]>0){const old=oldTx.find(t=>t.loanPaymentId===item.id&&t.transactionRole===role);s.transactions.push({...old,id:old?.id||uid(),loanId:id,loanPaymentId:item.id,transactionRole:role,type:'income',value:item[part],cat:'Juros / Empréstimo',date:item.date,desc:label+' · '+loan.person,method:old?.method||'Transferência',status:'Pago'});}
  }
 }
 Object.assign(loan,state);return loan;
}
export function changeLoanEvent(s,loanId,kind,eventId,changes=null){
 const copy=structuredClone(s);const {loan}=loanHistory(copy,loanId);
 if(kind==='origin'){
  if(!changes)throw Error('Para remover a origem, exclua o contrato completo.');
  loan.historyOrigin={...loan.historyOrigin,...changes};loan.principalOriginal=loan.historyOrigin.principal;
  for(const tx of copy.transactions.filter(t=>t.loanId===loanId&&t.transactionRole==='loan_principal_out'))tx.value=loan.principalOriginal;
  const origin=copy.loanCycles.find(c=>c.loanId===loanId&&c.type==='created');if(origin)Object.assign(origin,{principal:loan.historyOrigin.principal,interest:loan.historyOrigin.interestDue,due:loan.historyOrigin.due});
 }else{
  const arr=kind==='payment'?copy.loanPayments:copy.loanCycles,event=arr.find(x=>x.id===eventId&&x.loanId===loanId);if(!event)throw Error('Item não encontrado.');
  if(event.automatic){const payment=copy.loanPayments.find(p=>p.id===event.paymentId);if(!payment)throw Error('Pagamento da renovação não encontrado.');if(changes)throw Error('Edite o pagamento que gerou esta renovação.');payment.autoRenewDisabled=true;}
  if(changes)Object.assign(event,changes);else if(kind==='payment')copy.loanPayments=arr.filter(x=>x!==event);else copy.loanCycles=arr.filter(x=>x!==event);
 }
 rebuildLoan(copy,loanId);return copy;
}
