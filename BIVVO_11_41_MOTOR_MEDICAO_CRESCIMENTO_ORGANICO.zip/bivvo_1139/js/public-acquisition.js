import { adminTrack } from './admin-analytics.js';

const route = location.pathname.replace(/\/+$/, '') || '/';
const once = new Set();
const sendOnce = (event, content='') => { const k=event+'|'+content; if(once.has(k)) return; once.add(k); adminTrack(event, route, {content}).catch(()=>{}); };
const slug = s => String(s||'').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'').slice(0,80);
const isSignup = a => /signup=1/.test(a.getAttribute('href') || '');
const isInternalContent = a => { try { const u=new URL(a.href,location.href); return u.origin===location.origin&&!isSignup(a)&&u.pathname!==location.pathname&&!u.pathname.startsWith('/#/'); } catch{return false;} };

adminTrack(route.startsWith('/aprenda/') ? 'seo_article_viewed' : 'seo_page_viewed', route).catch(()=>{});

// Engajamento: sem enviar texto digitado, renda, gastos ou resultados financeiros.
let maxDepth=0;
const depth=()=>{ const d=document.documentElement, max=Math.max(1,d.scrollHeight-d.clientHeight); const p=Math.round((scrollY/max)*100); for(const mark of [25,50,75,90]) if(p>=mark&&maxDepth<mark){maxDepth=mark;sendOnce('seo_engaged', 'scroll_'+mark);} };
addEventListener('scroll',depth,{passive:true});
setTimeout(()=>sendOnce('seo_engaged','time_30s'),30000);

// Ferramentas embutidas nas páginas 11.39/11.40: mede uso, nunca os valores.
const toolRoot=document.querySelector('.tool, [data-seo-tool], #salaryCalc, #feriasCalc, #budgetCalc');
if(toolRoot){
  const start=()=>sendOnce('seo_tool_started','embedded');
  toolRoot.addEventListener('input',start,{passive:true});
  toolRoot.addEventListener('change',start,{passive:true});
  const results=toolRoot.querySelector('.results')||toolRoot;
  const mo=new MutationObserver(()=>{ if(once.has('seo_tool_started|embedded')) sendOnce('seo_tool_completed','embedded'); });
  mo.observe(results,{subtree:true,childList:true,characterData:true,attributes:true});
}

document.addEventListener('click', e => {
  const video=e.target.closest('[data-bv-video]');
  if(video) sendOnce('seo_video_played', slug(video.getAttribute('aria-label')||video.textContent||'video'));
  const a=e.target.closest('a[href]'); if(!a)return;
  if(a.matches('.download-sheet,[download]')) sendOnce('seo_tool_downloaded', slug(a.getAttribute('download')||a.textContent||'download'));
  if(isSignup(a)) adminTrack('seo_signup_clicked',route,{content:slug(a.textContent||'cta')}).catch(()=>{});
  else if(isInternalContent(a)) adminTrack('seo_related_article_clicked',route,{content:new URL(a.href,location.href).pathname.slice(0,80)}).catch(()=>{});
});
