/* Bivvo Scan (cliente) — escolhe/fotografa o comprovante, reduz a imagem no aparelho e envia ao servidor.
   O servidor confere login e cota. O resultado volta para CONFIRMAÇÃO; nada é salvo automaticamente. */
import * as cloud from './cloud.js';
import { setUsage } from './plans.js';

export function pickImage({ camera = true } = {}) {
  return new Promise(resolve => {
    const input = document.createElement('input');
    input.type = 'file'; input.accept = 'image/*';
    if (camera) input.setAttribute('capture', 'environment');
    input.addEventListener('change', () => resolve(input.files?.[0] || null), { once: true });
    window.addEventListener('focus', () => setTimeout(() => { if (!input.files?.length) resolve(null); }, 800), { once: true });
    input.click();
  });
}
/* Reduz para no máximo 1600px no lado maior, JPEG ~0,82. Comprovantes continuam legíveis e o envio fica leve. */
export async function shrink(file, max = 1600) {
  const bmp = await createImageBitmap(file).catch(() => null);
  if (!bmp) throw new Error('Não consegui abrir esta imagem.');
  const k = Math.min(1, max / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas'); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  bmp.close?.();
  const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.82));
  const buf = new Uint8Array(await blob.arrayBuffer());
  let bin = ''; for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode(...buf.subarray(i, i + 0x8000));
  return { mediaType: 'image/jpeg', image: btoa(bin) };
}
/* Retorna { ok, data } ou { ok:false, code, error, usage } */
export async function readReceipt(file) {
  const payload = await shrink(file);
  const token = await cloud.accessToken();
  const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 30000);
  try {
    const r = await fetch('/api/scan-receipt', { method: 'POST', signal: ctrl.signal, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token }, body: JSON.stringify(payload) });
    const j = await r.json().catch(() => ({}));
    if (j.usage) setUsage('scan', j.usage.used);
    if (!r.ok) return { ok: false, code: j.code || (r.status === 402 ? 'quota' : 'error'), error: j.error || 'Não foi possível ler agora.', usage: j.usage };
    return { ok: true, data: j.data, usage: j.usage };
  } catch (e) { return { ok: false, code: 'network', error: e.name === 'AbortError' ? 'A leitura demorou demais. Tente de novo ou digite o valor.' : 'Sem conexão para ler o comprovante agora.' }; }
  finally { clearTimeout(t); }
}
