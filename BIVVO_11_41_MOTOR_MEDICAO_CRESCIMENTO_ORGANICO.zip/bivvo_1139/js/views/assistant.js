/* Bivvo — Fase 3: tela do Bivvo IA. */
import { h, money0 } from '../util.js';
import { canUseFeature } from '../plans.js';
import { openPaywall } from './pro.js';
import { toast } from '../ui.js';
import { track } from '../analytics.js';
import { toolResults, localAnswer, rayX, askAI, aiUsage } from '../assistant.js';
import { openDecisionAssistant } from './decision.js';
import { openCopilot, openWhatIf } from './copilot.js';
import { openSimulator } from './simulator.js';

const CONSENT='bivvo_ai_consent_v1', CRISIS_CTX='bivvo_recovery_crisis_context_v1';
function hasConsent(){ try{return localStorage.getItem(CONSENT)==='1';}catch{return false;} }
function consent(){ try{localStorage.setItem(CONSENT,'1');}catch{} }

export function renderAssistant(root) {
  const allowed=canUseFeature('assistant'), tools=toolResults(), usage=aiUsage();
  let crisis=null; try{crisis=JSON.parse(sessionStorage.getItem(CRISIS_CTX)||'null'); if(crisis && Date.now()-Number(crisis.at||0)>30*60*1000) crisis=null;}catch{}
  root.append(h('div.page-head', h('div', h('p.eyebrow-soft','BIVVO IA'), h('h2.h2','Pergunte sobre seu dinheiro'), h('p.muted','Respostas com base nos cálculos do seu próprio Bivvo. Seu extrato bruto não é enviado para a IA.'))));
  if (!allowed) { root.append(h('section.card.ai-lock', h('h3','Seu copiloto financeiro'), h('p.muted','O Bivvo IA faz parte do Pro. Ele usa os cálculos do app para explicar seu cenário sem enviar seu extrato bruto.'), h('button.btn.primary',{type:'button',onclick:()=>openPaywall({feature:'assistant',onUnlocked:()=>{root.innerHTML='';renderAssistant(root);}})},'Experimentar Bivvo IA'))); return; }

  const chat=h('div.ai-chat');
  const input=h('textarea.ai-input',{rows:3,maxlength:500,placeholder:'Ex.: Quanto posso gastar até receber?'});
  const send=h('button.btn.primary',{type:'button'},'Perguntar');
  const add=(who,title,text)=>chat.append(h('div.ai-msg.'+who, title?h('b',title):null, h('p',text)));
  add('bot',crisis?'Plano de recuperação':'Bivvo IA',crisis?`Você veio do modo "Meu dinheiro não vai dar". Vou manter o foco no essencial, no seu limite até receber e no próximo passo possível.`:'Posso explicar seu caixa, mês, previsão, cartões, patrimônio e compromissos. Para perguntas comuns, respondo no próprio aparelho.');
  const run=async q=>{
    q=String(q||'').trim(); if(!q)return; add('me',null,q); input.value='';
    const nq=q.normalize('NFD').replace(/[\u0300-\u036f]/g,'');
    if(/o que preciso saber|sos financeiro|vida financeira.*ordem|estou descontrolad|dinheiro.*nao vai dar|monte.*plano|montar.*plano/i.test(nq)){ add('bot','Bivvo Copiloto','Vou transformar seus números em uma ação prática para hoje.'); openCopilot({sos:/sos|nao vai dar|descontrolad/i.test(nq)}); track('assistant_used',{source:'copilot'}); return; }
    if(/posso comprar|devo comprar|comprar agora/i.test(nq)){ add('bot','Posso comprar?','Vou simular o impacto antes de você decidir.'); openSimulator(); track('assistant_used',{source:'purchase'}); return; }
    if(/e se|simular.*cenario|parar de parcelar|renda cair|usar.*reserva/i.test(nq)){ add('bot','Central E se?','Vou abrir simulações locais que não alteram seus dados.'); openWhatIf(); track('assistant_used',{source:'whatif'}); return; }
    if(/o que.*pago.*primeiro|nao tenho dinheiro.*pagar tudo|pago.*fatura.*conta|organize.*pagamentos/i.test(nq)){ add('bot','Decisão financeira','Vou comparar seus compromissos, vencimentos e saldo sem alterar nenhum lançamento.'); openDecisionAssistant(); track('assistant_used',{source:'decision'}); return; }
    const local=localAnswer(q,tools); if(local){ add('bot',local.title,local.text); track('assistant_used',{source:'local'}); return; }
    if(!hasConsent()){
      const ok=confirm('Para responder esta pergunta, o Bivvo enviará somente números agregados e resultados calculados (como saldo livre e previsão) ao serviço de IA. Descrições do extrato, nomes de compras e o extrato bruto não são enviados. Continuar?');
      if(!ok){add('bot','Privacidade','Tudo bem. Você pode usar as perguntas rápidas, que são respondidas somente no aparelho.');return;} consent();
    }
    send.disabled=true; send.textContent='Pensando…';
    try{ const r=await askAI(q,tools); add('bot',r.title||'Bivvo IA',r.answer); track('assistant_used',{source:'ai'}); }
    catch(e){ if(e.code==='quota') openPaywall({feature:'assistant',usage:e.usage,onUnlocked:()=>{root.innerHTML='';renderAssistant(root);}}); else toast(e.message); add('bot','Não consegui responder',e.message); }
    finally{send.disabled=false;send.textContent='Perguntar';}
  };
  send.onclick=()=>run(input.value); input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();run(input.value);}});
  const quick=['🧭 O que faço hoje?','🛒 Posso comprar?','💰 O que pago primeiro?','🚨 Meu dinheiro não vai dar','📅 Organize até meu salário','💳 Analise meu cartão','🔎 Onde meu dinheiro está vazando?','📉 Quero sair do vermelho','🛡️ Posso mexer na reserva?','🎯 Como melhorar meu Bivvo Score?','🔮 E se eu parar de parcelar?'];
  root.append(h('section.card.ai-ray', h('div.card-head',h('h3','Raio-X financeiro'),h('span.muted.sm','Agora')), h('div.ai-ray-list',rayX(tools).map(x=>h('p',x)))));
  root.append(h('section.card.ai-box', chat, h('div.ai-quick',quick.map(q=>h('button.chip',{type:'button',onclick:()=>run(q)},q))), h('div.ai-compose',input,send), h('p.hint',`Perguntas abertas com IA: ${usage.remaining === Infinity ? 'sem limite' : usage.remaining+' restantes neste mês'}. Perguntas rápidas locais não gastam cota.`)));
}
