/* Relatório mensal compartilhado entre Orçamento e Extrato. */
import { h, money, monthLabel, ymOf, today, round2, shortDate } from '../util.js';
import * as F from '../finance.js';
import { openSheet, progress, catIcon } from '../ui.js';
import { openBudgetForm } from './forms.js';
import { stat } from './components.js';
import { pie } from '../charts.js';

export function budgetReport(ym, s, sm=F.monthSummary(ym,s)) {
  const rows=F.budgetRows(ym,s);
  const spending=sm.cats.filter(c=>c.value>0).map(c=>({label:c.cat,value:c.value}));
  const spent=round2(spending.reduce((sum,c)=>sum+c.value,0));
  const limits=round2(rows.reduce((sum,r)=>sum+r.limit,0));
  const coveredSpent=round2(rows.reduce((sum,r)=>sum+r.spent,0));
  const remaining=round2(limits-coveredSpent);
  const exceeded=rows.filter(r=>r.spent>r.limit);
  const top=spending[0];
  const showCategory=item=>{
    const categories=new Set(item.members?item.members.map(c=>c.label):[item.label]);
    const transactions=F.monthTx(ym,s).filter(t=>F.isSpend(t)&&categories.has(t.cat)&&(ym!==ymOf(today())||t.date<=today()))
      .sort((a,b)=>b.date.localeCompare(a.date)||(b.createdAt||0)-(a.createdAt||0));
    openSheet({title:item.label,subtitle:monthLabel(ym),wide:true,content:h('div.category-purchases',
      h('div.stats',stat('Total no mês',money(item.value)),
        stat('Parte dos gastos',(item.share*100).toLocaleString('pt-BR',{maximumFractionDigits:1})+'%'),
        stat('Lançamentos',String(transactions.length))),
      h('h3','Compras e despesas'),
      h('ul.category-purchase-list',transactions.map(t=>h('li',
        h('div',h('b',t.desc||t.cat),h('small',[shortDate(t.date),item.members?t.cat:null,t.method,t.status||'Pendente'].filter(Boolean).join(' · '))),
        h('strong',money(t.value))))),
      h('p.hint','Lançamentos que compõem esta categoria no gráfico do mês.'))});
  };
  const showLimits=()=>{
    if(!rows.length){openBudgetForm();return;}
    let sheet;
    sheet=openSheet({title:'Limites do orçamento',subtitle:monthLabel(ym),wide:true,content:h('div',
      h('p.muted.sm',money(coveredSpent)+' de '+money(limits)+' usados nas categorias com limite.'),
      h('div.budget-list',rows.map(r=>h('div.brow',
        h('div.brow-top',h('span',h('i',{'aria-hidden':'true'},catIcon(r.cat)),r.cat),h('b',money(r.spent)+' / '+money(r.limit))),
        progress(r.spent,r.limit,r.ratio>=1?'bad':r.ratio>=.8?'warn':'good'),
        h('small.muted',r.left>=0?money(r.left)+' disponível':money(-r.left)+' acima do limite'))))),
      footer:[h('button.btn.primary',{type:'button',onclick:()=>{sheet.close();openBudgetForm();}},'Editar limites')]});
  };
  return h('section.card.budget-chart',
    h('div.budget-report-head',
      h('span.eyebrow','SEU DINHEIRO EM DETALHES'),
      h('h3','Para onde foi seu orçamento?'),
      h('p.budget-report-month',monthLabel(ym)),
      h('div.budget-report-total',money(spent)),
      h('p.muted.sm','em gastos registrados no mês')),
    h('div.budget-report-kpis',
      h('div',h('span','Limites definidos'),h('b',rows.length?money(limits):'Não definidos'),h('small',rows.length+' categorias com limite')),
      h('div',h('span','Gasto nas categorias com limite'),h('b',money(coveredSpent)),h('small','Base para acompanhar seu orçamento')),
      h('div',{class:remaining<0?'is-over':''},h('span',remaining<0?'Acima dos limites':'Disponível nos limites'),h('b',rows.length?money(Math.abs(remaining)):'—'),h('small','Soma dos limites menos os gastos'))),
    pie(spending,{onPick:showCategory}),
    spent>0?h('div.budget-report-notes',
      h('div',h('span.eyebrow','MAIOR PARTE DOS GASTOS'),h('b',top.label),h('p',money(top.value)+' · '+(top.value/spent*100).toLocaleString('pt-BR',{maximumFractionDigits:1})+'% do total do mês.')),
      h('div',{class:exceeded.length?'is-over':''},h('span.eyebrow','ATENÇÃO AOS LIMITES'),h('b',rows.length?(exceeded.length?exceeded.length+' categoria'+(exceeded.length>1?'s':'')+' acima do limite':'Tudo dentro dos limites'):'Defina seus limites'),
        h('p',exceeded.length?'Excesso somado: '+money(exceeded.reduce((sum,r)=>sum+Math.max(0,-r.left),0))+'.':rows.length?'Consulte os valores disponíveis no botão de limites.':'Adicione limites para comparar o planejado com seus gastos.'))):null,
    h('div.budget-limits-action',h('button.btn',{type:'button',onclick:showLimits},rows.length?'Ver limites do orçamento':'Definir limites do orçamento')),
    h('p.budget-report-source','Fonte: seus lançamentos e limites no Bivvo. '+(ym===ymOf(today())?'Mês em andamento: gastos até hoje; agendados futuros ficam fora do gráfico.':'Gastos registrados no mês selecionado.')+' Inclui categorias sem limite; valores podem incluir pagamentos pendentes.'));

}
