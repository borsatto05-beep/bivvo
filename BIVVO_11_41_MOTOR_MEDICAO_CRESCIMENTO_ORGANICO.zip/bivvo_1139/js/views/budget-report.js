/* Relatório mensal compartilhado entre Orçamento e Extrato. */
import { h, money, monthLabel, ymOf, today, round2 } from '../util.js';
import * as F from '../finance.js';
import { openSheet } from '../ui.js';
import { stat } from './components.js';
import { pie } from '../charts.js';

export function budgetReport(ym, s, sm=F.monthSummary(ym,s)) {
  const rows=F.budgetRows(ym,s);
  const spending=sm.cats.filter(c=>c.value>0).map(c=>({label:c.cat,value:c.value}));
  const spent=round2(spending.reduce((sum,c)=>sum+c.value,0));
  const limits=round2(rows.reduce((sum,r)=>sum+r.limit,0));
  const coveredSpent=round2(rows.reduce((sum,r)=>sum+r.spent,0));
  const remaining=round2(limits-coveredSpent);
  const exceeded=rows.filter(r=>r.spent>r.limit);
  const top=spending[0];
  const showCategory=item=>{
    const row=rows.find(r=>r.cat===item.label);
    openSheet({title:item.label,subtitle:monthLabel(ym),content:h('div',
      h('div.stats',stat('Gasto no mês',money(item.value)),
        stat('Parte dos gastos',(item.share*100).toLocaleString('pt-BR',{maximumFractionDigits:1})+'%'),
        row?stat('Limite mensal',money(row.limit)):null),
      item.members?h('div.budget-group-detail',item.members.map(c=>h('div',h('span',c.label),h('b',money(c.value))))):
        h('p.notice',row?(row.left<0?money(-row.left)+' acima do limite.':money(row.left)+' disponível nesta categoria.'):'Esta categoria ainda não tem limite definido.'))});
  };
  return h('section.card.budget-chart',
    h('div.budget-report-head',
      h('span.eyebrow','SEU DINHEIRO EM DETALHES'),
      h('h3','Para onde foi seu orçamento?'),
      h('p.budget-report-month',monthLabel(ym)),
      h('div.budget-report-total',money(spent)),
      h('p.muted.sm','em gastos registrados no mês')),
    h('div.budget-report-kpis',
      h('div',h('span','Limites definidos'),h('b',rows.length?money(limits):'Não definidos'),h('small',rows.length+' categorias com limite')),
      h('div',h('span','Gasto nas categorias com limite'),h('b',money(coveredSpent)),h('small','Base para acompanhar seu orçamento')),
      h('div',{class:remaining<0?'is-over':''},h('span',remaining<0?'Acima dos limites':'Disponível nos limites'),h('b',rows.length?money(Math.abs(remaining)):'—'),h('small','Soma dos limites menos os gastos'))),
    pie(spending,{onPick:showCategory}),
    spent>0?h('div.budget-report-notes',
      h('div',h('span.eyebrow','MAIOR PARTE DOS GASTOS'),h('b',top.label),h('p',money(top.value)+' · '+(top.value/spent*100).toLocaleString('pt-BR',{maximumFractionDigits:1})+'% do total do mês.')),
      h('div',{class:exceeded.length?'is-over':''},h('span.eyebrow','ATENÇÃO AOS LIMITES'),h('b',rows.length?(exceeded.length?exceeded.length+' categoria'+(exceeded.length>1?'s':'')+' acima do limite':'Tudo dentro dos limites'):'Defina seus limites'),
        h('p',exceeded.length?'Excesso somado: '+money(exceeded.reduce((sum,r)=>sum+Math.max(0,-r.left),0))+'.':rows.length?'Acompanhe os valores disponíveis nas categorias abaixo.':'Adicione limites para comparar o planejado com seus gastos.'))):null,
    h('p.budget-report-source','Fonte: seus lançamentos e limites no Bivvo. '+(ym===ymOf(today())?'Mês em andamento: gastos até hoje; agendados futuros ficam fora do gráfico.':'Gastos registrados no mês selecionado.')+' Inclui categorias sem limite; valores podem incluir pagamentos pendentes.'));

}
