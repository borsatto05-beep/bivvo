/* Origem dos indicadores mensais da Inicial, com os critérios do resumo financeiro. */
import { h, money, today, ymOf, monthLabel, shortDate, num, round2 } from '../util.js';
import * as F from '../finance.js';
import { openSheet } from '../ui.js';

export function openHomeMonthDetail(kind, ym, s) {
  const sm=F.monthSummary(ym,s), all=F.monthTx(ym,s);
  const occurred=ym===ymOf(today())?all.filter(t=>t.date<=today()):all;
  const title={income:'Entrou',spend:'Gastei',saved:'Guardei'}[kind];
  const list=(items,negative=false)=>h('ul.category-purchase-list',items.map(t=>h('li',
    h('div',h('b',t.desc||t.name||t.cat||'Lançamento'),
      h('small',[t.date?shortDate(t.date):null,t.cat,t.method,t.status].filter(Boolean).join(' · '))),
    h('strong',(negative?'− ':'')+money(t.value)))));
  const section=(label,items,negative=false)=>h('section.month-origin-section',h('h3',label),
    items.length?list(items,negative):h('p.muted.sm','Nenhum lançamento neste grupo.'));
  const equation=(label,value)=>h('div.month-origin-equation',h('span',label),h('b',money(value)));
  const sum=items=>round2(items.reduce((total,t)=>total+num(t.value),0));
  const content=h('div.month-origin');
  let value;
  if(kind==='income'){
    value=sm.incomePaid;
    const paid=all.filter(t=>F.isRealIncome(t)&&F.isPaid(t));
    const pending=all.filter(t=>F.isRealIncome(t)&&!F.isPaid(t));
    content.append(h('p.notice','Soma das entradas marcadas como pagas e com data neste mês. Saldo inicial, resgates e devolução do principal de empréstimos ficam fora.'),
      section('Entradas recebidas',paid),equation('Total que entrou',value));
    if(pending.length)content.append(section('A receber · fora do total acima',pending),equation('Ainda a receber',sum(pending)));
  }else if(kind==='spend'){
    value=sm.spend;
    const expenses=occurred.filter(F.isSpend).sort((a,b)=>b.date.localeCompare(a.date));
    content.append(h('p.notice','Soma das despesas de consumo, incluindo compras no cartão e despesas pendentes. Valores guardados, saldo inicial e principal emprestado ficam fora.'+(ym===ymOf(today())?' No mês atual, entram apenas datas até hoje.':'')),
      section('Despesas que compõem o total',expenses),equation('Total gasto',value));
    const planned=ym===ymOf(today())?all.filter(t=>F.isSpend(t)&&t.date>today()):[];
    if(planned.length)content.append(section('Agendados · fora do total acima',planned),equation('Total agendado',sm.planned));
  }else{
    value=sm.saved;
    const deposits=occurred.filter(F.isSave),withdrawals=occurred.filter(F.isWithdraw);
    const legacy=s.investments.filter(x=>!x.txId&&String(x.purchaseDate||'').startsWith(ym))
      .map(x=>({name:x.name||'Investimento',date:x.purchaseDate,cat:'Investimento sem lançamento vinculado',value:num(x.costBasis??x.value)}));
    const raw=round2(sum(deposits)-sum(withdrawals)+sum(legacy));
    content.append(h('p.notice','Valores destinados a metas, reserva e investimentos, menos os resgates do período. Investimentos antigos sem lançamento vinculado também entram, pelo custo registrado no mês da compra.'),
      section('Valores guardados',deposits),equation('Aportes e valores guardados',sum(deposits)));
    if(withdrawals.length)content.append(section('Resgates descontados',withdrawals,true),equation('Menos resgates',-sum(withdrawals)));
    if(legacy.length)content.append(section('Investimentos sem lançamento vinculado',legacy),equation('Mais investimentos antigos',sum(legacy)));
    if(raw<0)content.append(equation('Resultado antes do ajuste',raw),h('p.hint','Os resgates superaram os aportes. O indicador Guardei mostra zero quando o resultado é negativo.'));
    content.append(equation('Total guardado no mês',value));
  }
  openSheet({title:title+' · '+monthLabel(ym),subtitle:'De onde vem este valor: '+money(value),wide:true,content});
}
