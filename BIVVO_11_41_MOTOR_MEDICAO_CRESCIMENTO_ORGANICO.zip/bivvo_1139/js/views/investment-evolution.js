import { h,s as svg,money,money0,today,ymOf,addMonthsYM,monthLabel,shortDate,parseMoney,round2,uid } from '../util.js';
import * as store from '../store.js';
import { investmentEvolution } from '../investment-evolution.js';
import { investmentValue } from '../finance.js';
import { openSheet,field,toast } from '../ui.js';
const pct=n=>(n*100).toLocaleString('pt-BR',{maximumFractionDigits:2})+'%';
const closingDate=month=>{const [y,m]=month.split('-').map(Number);return month+'-'+String(new Date(y,m,0).getDate()).padStart(2,'0');};
function recordClosing(s,month=ymOf(today())){
 const selected=h('input.input',{type:'month',value:month,max:ymOf(today()),'aria-label':'Mês do valor do ativo'});
 const asset=h('select.input',{'aria-label':'Ativo do histórico'},s.investments.map(x=>h('option',{value:x.id},x.name)));
 const amount=h('input.input',{inputmode:'decimal','aria-label':'Valor total do ativo no mês'});
 const msg=h('p.form-msg',{role:'alert'});
 const update=()=>{const row=(s.profile.investmentValuations||[]).filter(x=>x.investmentId===asset.value&&ymOf(x.date)===selected.value).sort((a,b)=>b.date.localeCompare(a.date))[0];amount.value=row?String(row.value).replace('.',','):'';};
 selected.addEventListener('change',update);asset.addEventListener('change',update);update();
 let sheet;
 const form=h('form.form',{onsubmit:e=>{e.preventDefault();save();}},field('Ativo',asset),field('Mês',selected),field('Valor total desse ativo no mês',amount),h('p.notice','Use a posição real do extrato da corretora: quantidade × cotação, ou saldo informado pela instituição. O registro completa o histórico desse ativo e não altera seu saldo de caixa. Não há preenchimento por taxa arbitrária.'),msg);
 sheet=openSheet({title:'Registrar valor histórico do ativo',content:form,footer:[h('button.btn.primary',{type:'button',onclick:()=>form.requestSubmit()},'Salvar valor do ativo')]});
 function save(){
  const value=parseMoney(amount.value),month=selected.value;
  if(!asset.value||!/^\d{4}-\d{2}$/.test(month)||month>ymOf(today())||!amount.value.trim()||value<0){msg.textContent='Selecione o ativo, um mês válido e um valor não negativo.';return;}
  const date=month===ymOf(today())?today():closingDate(month);
  store.commit(st=>{st.profile.investmentValuations=[...(st.profile.investmentValuations||[]).filter(x=>!(x.investmentId===asset.value&&ymOf(x.date)===month)),{investmentId:asset.value,value:round2(value),date,source:'Valor histórico informado',recordedAt:Date.now()}];});
  sheet.close();toast('Histórico do ativo registrado.');
 }
}
function captureObservations(s){
 const additions=[];
 for(const inv of s.investments){
  if(['CDB','Renda fixa'].includes(inv.type)||inv.purchaseDate>today()||(['Ações','Fundos','Cripto'].includes(inv.type)&&!inv.quoteAt))continue;
  const date=inv.quoteAt||today(),value=investmentValue(inv,s);
  const previous=(s.profile.investmentValuations||[]).find(x=>x.investmentId===inv.id&&x.date===date);
  if(previous?.source==='Valor histórico informado')continue;
  if(previous&&previous.value===value)continue;
  additions.push({investmentId:inv.id,value,date,source:inv.quoteAt?'Cotação registrada':'Valor atual cadastrado',recordedAt:Date.now()});
 }
 if(additions.length)store.commit(st=>{for(const row of additions)st.profile.investmentValuations=[...(st.profile.investmentValuations||[]).filter(x=>!(x.investmentId===row.investmentId&&x.date===row.date)),row];},{silent:true,reason:'investment-observations'});
}
function recordMovement(s){
 const type=h('select.input',{'aria-label':'Tipo de movimentação'},h('option',{value:'deposit'},'Aporte'),h('option',{value:'withdrawal'},'Retirada'));
 const asset=h('select.input',{'aria-label':'Ativo da movimentação'},s.investments.map(x=>h('option',{value:x.id},x.name)));
 const amount=h('input.input',{inputmode:'decimal','aria-label':'Valor da movimentação'});
 const date=h('input.input',{type:'date',value:today(),max:today(),'aria-label':'Data da movimentação'});
 const desc=h('input.input',{maxlength:80,'aria-label':'Descrição da movimentação',placeholder:'Ex.: aporte de dezembro'});
 const msg=h('p.form-msg',{role:'alert'});
 let sheet;const form=h('form.form',{onsubmit:e=>{e.preventDefault();save();}},field('Tipo',type),field('Ativo',asset),field('Valor',amount),field('Data',date),field('Descrição',desc),h('p.notice','Use para completar o histórico de aportes e retiradas que ainda não constam no gráfico. Não duplica no extrato nem altera suas posições atuais. Aplicações e resgates registrados no app já entram automaticamente. Após completar uma movimentação histórica, informe o valor real do ativo no mês para conferir o rendimento.'),msg);
 sheet=openSheet({title:'Completar histórico de movimentações',content:form,footer:[h('button.btn.primary',{type:'button',onclick:()=>form.requestSubmit()},'Salvar movimentação')]});
 function save(){const value=parseMoney(amount.value);if(!asset.value||!(value>0)||!date.value||date.value>today()){msg.textContent='Informe valor positivo e data até hoje.';return;}
 store.commit(st=>{st.profile.investmentMovements=[...(st.profile.investmentMovements||[]),{id:uid(),type:type.value,investmentId:asset.value,value:round2(value),date:date.value,createdAt:Date.now(),description:desc.value.trim()||(type.value==='deposit'?'Aporte informado':'Retirada informada')}];});sheet.close();toast('Movimentação adicionada ao histórico.');}
}
export function portfolioEvolution(s){
 captureObservations(s);
 const card=h('section.card.portfolio-evolution');
 const years=[...new Set([...(s.profile.investmentValuations||[]).map(x=>x.date.slice(0,4)),...s.investments.map(x=>(x.purchaseDate||today()).slice(0,4)),...(s.profile.investmentMovements||[]).map(x=>x.date.slice(0,4))])].filter(y=>y!==today().slice(0,4)).sort().reverse();
 const period=h('select.input.sm',{'aria-label':'Período da evolução da carteira'},h('option',{value:'6'},'Últimos 6 meses'),h('option',{value:'12'},'Últimos 12 meses'),h('option',{value:'year'},'Ano atual'),years.map(y=>h('option',{value:'y:'+y},'Ano '+y)));
 const view=h('select.input.sm',{'aria-label':'Visualização da evolução'},h('option',{value:'returns'},'Rendimentos por origem'),h('option',{value:'flows'},'Aportes e retiradas'));
 const body=h('div.portfolio-evolution-body');
 card.append(h('div.card-head',h('div',h('h3','Evolução dos investimentos'),h('p.hint','Aportes, retiradas, saldo e rendimento da carteira.')),h('div.evolution-controls',view,period)),
 h('div.btn-row.portfolio-actions',h('button.btn.sm',{type:'button',onclick:()=>recordClosing(s)},'Registrar valor do ativo'),h('button.btn.sm',{type:'button',onclick:()=>recordMovement(s)},'Registrar aporte ou retirada')),body);
 function draw(){
  const cur=ymOf(today()),year=period.value.startsWith('y:')?period.value.slice(2):cur.slice(0,4);
  const months=period.value==='year'||period.value.startsWith('y:')?Array.from({length:12},(_,i)=>year+'-'+String(i+1).padStart(2,'0')).filter(x=>x<=cur):Array.from({length:Number(period.value)},(_,i)=>addMonthsYM(cur,i-Number(period.value)+1));
  const rows=investmentEvolution(s,months),series=row=>view.value==='flows'?[[row.deposits,'#3977cb'],[-row.withdrawals,'#ce5577']]:[[row.fixedGain,'#7840c4'],[row.marketGain,'#b98521'],[row.dividends,'#00876c']];
  const max=Math.max(1,...rows.flatMap(r=>series(r).map(([value])=>Math.abs(value||0))));
  const chart=svg('svg',{viewBox:'0 0 900 330',role:'group','aria-label':'Aportes, retiradas e rendimento por mês'});
  const width=810/rows.length,zero=170,scale=120/max;
  for(let i=-1;i<=1;i++){const y=zero-i*120;chart.append(svg('line',{x1:65,x2:885,y1:y,y2:y,class:'dividend-gridline'}),svg('text',{x:55,y:y+4,'text-anchor':'end',class:'dividend-axis'},(max*i).toLocaleString('pt-BR',{notation:'compact',maximumFractionDigits:1})));}
  const detail=row=>{
   const eq=(label,value)=>h('div.month-origin-equation',h('span',label),h('b',value===null?'Sem saldo registrado':money(value)));
   let sheet;
   sheet=openSheet({title:monthLabel(row.month),subtitle:'Origem da evolução dos investimentos',wide:true,content:h('div.month-origin',
    eq('Saldo anterior',row.opening),eq('Aportes',row.deposits),eq('Retiradas',row.withdrawals),eq(row.partial?'Saldo atual · mês em andamento':'Saldo no mês',row.balance),eq('Renda fixa · taxa cadastrada',row.fixedGain),eq('Valorização / desvalorização',row.marketGain),eq('Dividendos e rendimentos pagos',row.dividends),eq('Resultado total dos investimentos',row.totalReturn),
    row.rate!==null?h('p.notice','Resultado total sobre o saldo anterior, sem aportes ou retiradas: '+pct(row.rate)+'.'):null,
    h('p.hint',row.gain===null?'Para completar o cálculo, registre os valores históricos dos ativos que estão sem cotação neste mês ou no mês anterior.':'Cálculo: saldo do mês − saldo anterior − aportes + retiradas. Para renda fixa, o valor atual usa a taxa cadastrada; em ações e fundos, inclui variação de cotação.'),
    h('h3','Base por ativo'),h('ul.category-purchase-list',row.assets.map(x=>h('li',h('div',h('b',x.name),h('small',x.source+(x.estimated?' · estimado':''))),h('strong',x.value===null?'Sem histórico':money(x.value))))),
    h('h3','Dividendos e rendimentos pagos'),h('ul.category-purchase-list',row.dividendItems.map(t=>h('li',h('div',h('b',t.desc),h('small',shortDate(t.date))),h('strong',money(t.value))))),
    row.unlinkedDividends>0?h('p.notice',money(row.unlinkedDividends)+' de proventos sem ativo vinculado ficam no gráfico de proventos e não entram no resultado por ativos até serem vinculados.'):null,
    h('h3','Aportes e retiradas'),h('ul.category-purchase-list',row.items.map(x=>h('li',h('div',h('b',x.description),h('small',shortDate(x.date)+' · '+x.source)),h('strong',(x.type==='withdrawal'?'− ':'+ ')+money(x.value)),
      x.source==='Histórico informado'?h('button.link.sm',{type:'button','aria-label':'Excluir movimentação '+x.description,onclick:()=>{store.commit(st=>{st.profile.investmentMovements=st.profile.investmentMovements.filter(m=>m.id!==x.id);});sheet.close();}},'Excluir'):null))),
    row.items.length?null:h('p.muted.sm','Nenhum aporte ou retirada neste mês.')),
    footer:[h('button.btn',{type:'button',onclick:()=>{sheet.close();setTimeout(()=>recordClosing(s,row.month),240);}},'Informar valor histórico de um ativo')]});
  };
  rows.forEach((row,i)=>{
   const x=65+i*width,w=width*(view.value==='flows'?.3:.22);
   const g=svg('g',{tabindex:0,role:'button','aria-label':monthLabel(row.month)+': aportes '+money(row.deposits)+', retiradas '+money(row.withdrawals)+', rendimento '+(row.gain===null?'não apurado':money(row.gain)),class:'portfolio-flow-bar'});
   g.append(svg('rect',{x:x+3,y:35,width:width-6,height:260,fill:'transparent'}));
   series(row).forEach(([value,color],j)=>{if(value===null||value===0)return;const height=Math.max(1,Math.abs(value)*scale);g.append(svg('rect',{x:x+width*.1+j*(w+width*.025),y:value>=0?zero-height:zero,width:w,height,rx:2,fill:color}));});
   g.addEventListener('click',()=>detail(row));g.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();detail(row);}});chart.append(g);
   chart.append(svg('text',{x:x+width/2,y:318,'text-anchor':'middle',class:'dividend-axis'},row.month.slice(5)+'/'+row.month.slice(2,4)));
  });
  const balances=rows.filter(r=>r.balance!==null),maxBalance=Math.max(1,...balances.map(r=>r.balance));
  const line=svg('svg',{viewBox:'0 0 900 230',role:'group','aria-label':'Evolução do saldo dos investimentos'});
  for(let i=0;i<=3;i++){const y=180-i*50;line.append(svg('line',{x1:65,x2:885,y1:y,y2:y,class:'dividend-gridline'}),svg('text',{x:55,y:y+4,'text-anchor':'end',class:'dividend-axis'},(maxBalance*i/3).toLocaleString('pt-BR',{notation:'compact',maximumFractionDigits:1})));}
  let previous=null;
  rows.forEach((row,i)=>{
   const x=65+width*(i+.5),y=180-(row.balance||0)/maxBalance*150;
   if(row.balance!==null){if(previous)line.append(svg('line',{x1:previous.x,y1:previous.y,x2:x,y2:y,stroke:'#00876c','stroke-width':3}));
    const dot=svg('circle',{cx:x,cy:y,r:5,fill:'#00876c',tabindex:0,role:'button','aria-label':monthLabel(row.month)+': saldo '+money(row.balance)});
    dot.append(svg('title',{},money(row.balance)));dot.addEventListener('click',()=>detail(row));dot.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();detail(row);}});line.append(dot);previous={x,y};
   }else previous=null;
   line.append(svg('text',{x,y:210,'text-anchor':'middle',class:'dividend-axis'},row.month.slice(5)+'/'+row.month.slice(2,4)));
  });
  const table=h('div.portfolio-history-table',h('div.portfolio-history-head',h('span','Mês'),h('span','Aportes'),h('span','Retiradas'),h('span','Renda fixa'),h('span','Valorização'),h('span','Dividendos'),h('span','Resultado total'),h('span','Saldo')));
  rows.forEach(row=>table.append(h('button',{type:'button',onclick:()=>detail(row)},h('b',row.month.slice(5)+'/'+row.month.slice(0,4)),h('span',money0(row.deposits)),h('span',money0(row.withdrawals)),h('span',row.fixedGain===null?'Sem histórico':money(row.fixedGain)+(row.estimated?' *':'')),h('span',row.marketGain===null?'Sem histórico':money(row.marketGain)),h('span',money(row.dividends)),h('span',row.totalReturn===null?'A apurar':money(row.totalReturn)+(row.rate!==null?' · '+pct(row.rate):'')),h('span',row.balance===null?'Sem registro':money(row.balance)+(row.partial?' *':'')))));
  body.replaceChildren(h('h4',view.value==='flows'?'Aportes e retiradas do mês':'Rendimento dos ativos e dividendos'),h('div.dividend-key',...(view.value==='flows'?[['Aportes','#3977cb'],['Retiradas','#ce5577']]:[['Renda fixa','#7840c4'],['Valorização dos ativos','#b98521'],['Dividendos recebidos','#00876c']]).map(([label,color])=>h('span',h('i',{vars:{'--slice-color':color},class:'flow-color'}),label))),
    h('p.hint','Valores em R$. Retiradas e perdas aparecem abaixo de zero. Deslize para ver todos os meses.'),
    h('div.dividend-chart-scroll',chart),h('h4','Evolução do saldo da carteira'),h('div.dividend-chart-scroll',line),h('div.portfolio-table-scroll',table),
    h('p.hint','Resultado total = renda fixa + valorização dos ativos + dividendos pagos. Aportes e retiradas são separados. Dividendos recebidos fora da carteira não aumentam a linha do saldo até serem reinvestidos. Percentual apenas em meses sem movimentações, com saldo anterior positivo.'),
    ...(rows.some(r=>r.unlinkedDividends>0)?[h('p.notice','Há proventos sem ativo vinculado. Eles continuam no gráfico de proventos; vincule-os ao ativo para incluí-los no resultado da carteira.')]:[]),
    h('p.hint','Base: ativos cadastrados, taxas informadas, cotações registradas e dividendos recebidos vinculados. Sem cotação histórica, não inventamos a valorização. * Renda fixa é estimativa antes de impostos; CDI/SELIC usa a referência cadastrada, não uma série histórica do indexador.'));
 }
 period.addEventListener('change',draw);view.addEventListener('change',draw);draw();return card;
}
