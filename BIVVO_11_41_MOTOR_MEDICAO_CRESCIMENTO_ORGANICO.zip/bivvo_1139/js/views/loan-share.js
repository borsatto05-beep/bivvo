import { h, money, shortDate } from '../util.js';
import { openSheet, toast } from '../ui.js';
const messageDate=date=>shortDate(date)+'/'+String(date).slice(0,4);
export function loanMessage(loan,{title='Resumo do empréstimo',payment,cycle}={}){
 const principal=Number(loan.principal||0),interest=Math.max(0,Number(loan.interestDue??(loan.interestMode==='fixed'?loan.interestFixed:principal*Number(loan.interestRate||0)/100))||0);
 const period=loan.periodicity==='monthly'?'ao mês':'único';
 const rate=Number(loan.interestRate||0).toLocaleString('pt-BR',{maximumFractionDigits:4});
 const agreement=loan.interestMode==='fixed'?money(loan.interestFixed||0):rate+'%';
 const paid=loan.status==='paid'||principal+interest<=.004;
 const heading=payment?'Comprovante de pagamento':cycle?'Renovação do seu empréstimo':title==='Contrato atualizado'?'Seu empréstimo foi atualizado':title==='Empréstimo registrado'?'Seu empréstimo foi registrado':'Resumo do seu empréstimo';
 const lines=['Olá, '+loan.person+'! 👋','','📋 *'+heading+'*','','💵 Valor emprestado: '+money(loan.principalOriginal??principal),'📈 Juros combinados: '+agreement+' ('+period+')'];
 if(payment)lines.push('','✅ *Pagamento registrado*','📅 Data: '+messageDate(payment.date),'💰 Valor recebido: '+money(payment.amount),'📈 Juros pagos: '+money(payment.interest),'💵 Valor abatido do empréstimo: '+money(payment.principal));
 if(cycle)lines.push('','🔄 *Renovação registrada*','📅 Data: '+messageDate(cycle.date),'💵 Valor emprestado no ciclo: '+money(cycle.principal),'📈 Juros do ciclo: '+money(cycle.interest),'📅 Vencimento do ciclo: '+messageDate(cycle.due),...(cycle.capitalized?['➕ Juros incorporados ao valor emprestado: '+money(cycle.capitalized)]:[]));
 lines.push('','🧾 *O que falta pagar*','Valor emprestado restante: '+money(principal),'Juros a pagar: '+money(interest),'','💰 *Total a pagar: '+money(principal+interest)+'*');
 if(!paid&&loan.due)lines.push('📅 *Vencimento: '+messageDate(loan.due)+'*');
 if(paid)lines.push('✅ *Empréstimo quitado!*');
 if(payment?.autoRenewed)lines.push('','🔄 Após este pagamento, o contrato foi renovado automaticamente para o próximo ciclo.');
 lines.push('','O total acima já considera os pagamentos registrados.');
 return lines.join('\n');
}
export function shareLoan(loan,options={}){
 const text=loanMessage(loan,options),box=h('textarea.input.loan-share-message',{readOnly:true,rows:12,'aria-label':'Mensagem para o cliente'},text);
 async function copy(){try{await navigator.clipboard.writeText(text);toast('Mensagem copiada.');}catch{box.focus();box.select();toast('Selecione e copie a mensagem acima.');}}
 openSheet({title:'Compartilhar com o cliente',subtitle:options.title||loan.person,content:h('div.form',h('p.hint','Confira os valores antes de enviar. A mensagem inclui somente este contrato.'),box),footer:[
 h('button.btn',{type:'button',onclick:copy},'Copiar mensagem'),
 h('a.btn',{href:'https://wa.me/?text='+encodeURIComponent(text),target:'_blank',rel:'noopener noreferrer'},'WhatsApp'),
 ...(navigator.share?[h('button.btn.primary',{type:'button',onclick:async()=>{try{await navigator.share({title:'Empréstimo · '+loan.person,text});}catch(e){if(e.name!=='AbortError')toast('Não foi possível compartilhar. Use Copiar mensagem ou WhatsApp.');}}},'Compartilhar')]:[])
 ]});
}
