import { h, money, shortDate } from '../util.js';
import { openSheet, toast } from '../ui.js';
export function loanMessage(loan,{title='Resumo do empréstimo',payment,cycle}={}){
 const principal=Number(loan.principal||0),interest=Math.max(0,Number(loan.interestDue??(loan.interestMode==='fixed'?loan.interestFixed:principal*Number(loan.interestRate||0)/100))||0);
 const lines=['Bivvo · '+title,'Cliente: '+loan.person];
 if(payment)lines.push('Pagamento em '+shortDate(payment.date)+': '+money(payment.amount),'Juros pagos: '+money(payment.interest),'Principal pago: '+money(payment.principal));
 if(cycle)lines.push('Renovação em '+shortDate(cycle.date),'Principal do ciclo: '+money(cycle.principal),'Juros do ciclo: '+money(cycle.interest),'Vencimento do ciclo: '+shortDate(cycle.due),...(cycle.capitalized?['Juros capitalizados: '+money(cycle.capitalized)]:[]));
 if(payment||cycle)lines.push('','Situação atual do contrato:');
 lines.push('Principal restante: '+money(principal),'Juros pendentes: '+money(interest),'Total a receber: '+money(principal+interest),'Situação: '+(loan.status==='paid'||principal+interest<=.004?'Quitado':'Em aberto'));
 if(loan.due)lines.push('Vencimento atual: '+shortDate(loan.due));
 if(payment?.autoRenewed)lines.push('Após este pagamento, o contrato foi renovado automaticamente para o próximo ciclo.');
 return lines.join('\n');
}
export function shareLoan(loan,options={}){
 const text=loanMessage(loan,options),box=h('textarea.input.loan-share-message',{readOnly:true,rows:12,'aria-label':'Mensagem para o cliente'},text);
 async function copy(){try{await navigator.clipboard.writeText(text);toast('Mensagem copiada.');}catch{box.focus();box.select();toast('Selecione e copie a mensagem acima.');}}
 openSheet({title:'Compartilhar com o cliente',subtitle:options.title||loan.person,content:h('div.form',h('p.hint','Confira os valores antes de enviar. A mensagem inclui somente este contrato.'),box),footer:[
 h('button.btn',{type:'button',onclick:copy},'Copiar mensagem'),
 h('a.btn',{href:'https://wa.me/?text='+encodeURIComponent(text),target:'_blank',rel:'noopener noreferrer'},'WhatsApp'),
 ...(navigator.share?[h('button.btn.primary',{type:'button',onclick:async()=>{try{await navigator.share({title:'Empréstimo · '+loan.person,text});}catch(e){if(e.name!=='AbortError')toast('Não foi possível compartilhar. Use Copiar mensagem ou WhatsApp.');}}},'Compartilhar')]:[])
 ]});
}
