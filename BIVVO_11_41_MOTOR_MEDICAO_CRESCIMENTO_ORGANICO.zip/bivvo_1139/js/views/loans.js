import { h, money, today, uid, round2, parseMoney, addMonthsDate, addMonthsYM, diffDays, ymOf, monthShort, monthLabel, shortDate } from '../util.js';
import * as store from '../store.js';
import { openSheet, field, toast, confirmSheet } from '../ui.js';
import { donut, bars, progressBar } from '../charts.js';
import { ctx, rerender } from '../nav.js';

const S=()=>store.getState();
const baseInterest=l=>l.interestMode==='fixed'?Number(l.interestFixed||0):round2(Number(l.principal||0)*Number(l.interestRate||0)/100);
const interestDue=l=>Math.max(0,round2(l.interestDue ?? baseInterest(l)));
const totalDue=l=>round2(Number(l.principal||0)+interestDue(l));
const isPaid=l=>l.status==='paid'||totalDue(l)<=0.004;
const overdueDays=l=>!isPaid(l)&&l.due&&l.due<today()?Math.max(1,diffDays(l.due,today())):0;
const loanStatus=l=>isPaid(l)?{key:'paid',label:'Quitado'}:overdueDays(l)?{key:'overdue',label:`Vencido há ${overdueDays(l)} dia${overdueDays(l)>1?'s':''}`}:(l.due===today()?{key:'today',label:'Vence hoje'}:{key:'open',label:'Em dia'});
const paidFor=(s,id)=>(s.loanPayments||[]).filter(p=>p.loanId===id);
const principalRecovered=(s,l)=>paidFor(s,l.id).reduce((a,p)=>a+Number(p.principal||0),0);
const interestReceived=(s,l)=>paidFor(s,l.id).reduce((a,p)=>a+Number(p.interest||0),0);

function newLoan(){
  const person=h('input.input',{placeholder:'Nome da pessoa',maxlength:60}), principal=h('input.input',{inputmode:'decimal',placeholder:'0,00'}), mode=h('select.input',h('option',{value:'percent'},'Percentual (%)'),h('option',{value:'fixed'},'Valor fixo (R$)')), interest=h('input.input',{inputmode:'decimal',placeholder:'10'}), periodicity=h('select.input',h('option',{value:'monthly'},'Mensal'),h('option',{value:'single'},'Único')), due=h('input.input',{type:'date',value:today()}), note=h('textarea.input',{rows:2,placeholder:'Observação (opcional)',maxlength:180}), preview=h('div.loan-preview'), msg=h('p.form-msg');
  const update=()=>{const p=parseMoney(principal.value),v=parseMoney(interest.value),i=mode.value==='fixed'?v:round2(p*v/100);preview.replaceChildren(h('small','PRÉVIA'),h('div.loan-preview-grid',h('span','Principal',h('b',money(p))),h('span','Juros',h('b',money(i))),h('span','Total a receber',h('b',money(p+i)))));};
  [principal,interest,mode].forEach(x=>x.addEventListener('input',update)); update();
  const sh=openSheet({title:'Novo empréstimo',subtitle:'Principal e juros ficam separados para não inflar sua renda.',content:h('div.form',field('Pessoa',person),field('Valor principal',principal),field('Tipo de juros',mode),field('Juros',interest),field('Periodicidade',periodicity),field('Vencimento',due),field('Observação',note),preview,msg),footer:[h('button.btn.primary',{type:'button',onclick:()=>{const p=parseMoney(principal.value),v=parseMoney(interest.value);if(!person.value.trim()||p<=0||v<0||!due.value){msg.textContent='Informe pessoa, valor e vencimento.';return;}store.commit(s=>{const id=uid(), l={id,person:person.value.trim(),principalOriginal:p,principal:p,interestMode:mode.value,interestRate:mode.value==='percent'?v:0,interestFixed:mode.value==='fixed'?v:0,periodicity:periodicity.value,due:due.value,status:'open',note:note.value.trim(),createdAt:Date.now()};l.interestDue=baseInterest(l);s.loans.push(l);s.loanCycles.push({id:uid(),loanId:id,date:today(),due:l.due,principal:p,interest:l.interestDue,type:'created'});});sh.close();toast('Empréstimo registrado.');}},'Salvar')]});
}


function editLoan(l, parentSheet){
  const s=S(), payments=paidFor(s,l.id), hasPayments=payments.length>0;
  const person=h('input.input',{value:l.person||'',maxlength:60,placeholder:'Nome da pessoa'}),
    principal=h('input.input',{inputmode:'decimal',value:String(l.principalOriginal??l.principal??0).replace('.',','),disabled:hasPayments}),
    mode=h('select.input',h('option',{value:'percent'},'Percentual (%)'),h('option',{value:'fixed'},'Valor fixo (R$)')),
    interest=h('input.input',{inputmode:'decimal'}),
    periodicity=h('select.input',h('option',{value:'monthly'},'Mensal'),h('option',{value:'single'},'Único')),
    due=h('input.input',{type:'date',value:l.due||today()}),
    note=h('textarea.input',{rows:3,maxlength:180,placeholder:'Observação (opcional)'},l.note||''),
    preview=h('div.loan-preview'), msg=h('p.form-msg');
  mode.value=l.interestMode||'percent'; periodicity.value=l.periodicity||'monthly';
  interest.value=String(mode.value==='fixed'?(l.interestFixed||0):(l.interestRate||0)).replace('.',',');
  const update=()=>{const p=hasPayments?Number(l.principal||0):parseMoney(principal.value),v=parseMoney(interest.value),i=mode.value==='fixed'?v:round2(p*v/100);preview.replaceChildren(h('small','PRÉVIA DO CONTRATO'),h('div.loan-preview-grid',h('span',hasPayments?'Principal atual':'Principal',h('b',money(p))),h('span','Juros do ciclo',h('b',money(i))),h('span','Total estimado',h('b',money(p+i)))));};
  [principal,interest,mode].forEach(x=>x.addEventListener('input',update)); update();
  const sh=openSheet({title:`Editar · ${l.person}`,subtitle:hasPayments?'O principal original fica bloqueado porque este contrato já possui pagamentos.':'Você pode corrigir também o valor original enquanto não houver pagamentos.',content:h('div.form',field('Pessoa',person),field('Valor principal',principal,hasPayments?'Bloqueado após o primeiro pagamento para preservar o histórico.':''),field('Tipo de juros',mode),field('Juros',interest),field('Periodicidade',periodicity),field('Vencimento',due),field('Observação',note),preview,msg),footer:[h('button.btn.primary',{type:'button',onclick:()=>{const name=person.value.trim(),p=parseMoney(principal.value),v=parseMoney(interest.value);if(!name||(!hasPayments&&p<=0)||v<0||!due.value){msg.textContent='Revise pessoa, valor, juros e vencimento.';return;}store.commit(st=>{const loan=st.loans.find(x=>x.id===l.id);if(!loan)return;const oldName=loan.person;loan.person=name;loan.interestMode=mode.value;loan.interestRate=mode.value==='percent'?v:0;loan.interestFixed=mode.value==='fixed'?v:0;loan.periodicity=periodicity.value;loan.due=due.value;loan.note=note.value.trim();if(!hasPayments){loan.principalOriginal=p;loan.principal=p;}loan.interestDue=baseInterest(loan);for(const tx of st.transactions.filter(x=>x.loanId===loan.id)){if(tx.transactionRole==='loan_principal_out'){if(!hasPayments)tx.value=p;tx.desc=`Empréstimo para ${name}`;}else if(tx.transactionRole==='loan_principal_return')tx.desc=`Principal recebido · ${name}`;else if(tx.transactionRole==='loan_interest_income')tx.desc=`Juros recebidos · ${name}`;}if(!hasPayments){const created=st.loanCycles.find(c=>c.loanId===loan.id&&c.type==='created');if(created){created.principal=p;created.interest=loan.interestDue;created.due=loan.due;}}});sh.close();parentSheet?.close();toast('Contrato atualizado.');}},'Salvar alterações')]});
}

async function deleteLoan(l, parentSheet){
  const s=S(), payments=paidFor(s,l.id), txs=(s.transactions||[]).filter(x=>x.loanId===l.id), cycles=(s.loanCycles||[]).filter(x=>x.loanId===l.id);
  const ok=await confirmSheet({title:`Excluir contrato de ${l.person}?`,message:`Esta ação remove o contrato e todo o histórico ligado a ele (${payments.length} pagamento${payments.length===1?'':'s'}). O histórico ligado ao contrato também será removido. Somente juros efetivamente recebidos afetam o saldo.`,confirmLabel:'Excluir contrato',danger:true});
  if(!ok)return;
  store.markDeleted(l.id,payments.map(x=>x.id),txs.map(x=>x.id),cycles.map(x=>x.id));
  store.commit(st=>{st.loans=st.loans.filter(x=>x.id!==l.id);st.loanPayments=st.loanPayments.filter(x=>x.loanId!==l.id);st.loanCycles=st.loanCycles.filter(x=>x.loanId!==l.id);st.transactions=st.transactions.filter(x=>x.loanId!==l.id);});
  parentSheet?.close(); toast('Contrato excluído.');
}

function payLoan(l){
  const amount=h('input.input',{inputmode:'decimal',placeholder:'0,00'}), preview=h('div.loan-preview'), msg=h('p.form-msg');
  const update=()=>{const a=Math.max(0,parseMoney(amount.value)), i=Math.min(a,interestDue(l)), p=Math.min(Number(l.principal||0),Math.max(0,a-i)), rest=round2(totalDue(l)-i-p);preview.replaceChildren(h('small','COMO O BIVVO VAI DISTRIBUIR'),h('div.loan-preview-grid',h('span','Juros',h('b',money(i))),h('span','Principal',h('b',money(p))),h('span','Restará',h('b',money(rest)))));};amount.addEventListener('input',update);update();
  const sh=openSheet({title:`Receber de ${l.person}`,subtitle:`Saldo a receber ${money(totalDue(l))}`,content:h('div.form',h('p.notice',`Principal ${money(l.principal)} · juros pendentes ${money(interestDue(l))}. O pagamento quita juros primeiro e depois amortiza o principal. Se os juros do ciclo forem quitados e ainda restar principal em um contrato mensal, o Bivvo renova automaticamente para o próximo mês e calcula novos juros sobre o principal restante.`),field('Valor recebido',amount),preview,msg),footer:[h('button.btn.primary',{type:'button',onclick:()=>{const requested=parseMoney(amount.value), max=totalDue(l);if(requested<=0){msg.textContent='Informe o valor recebido.';return;}if(requested>max+0.004){msg.textContent=`O máximo a receber neste contrato é ${money(max)}.`;return;}store.commit(s=>{const loan=s.loans.find(x=>x.id===l.id), a=Math.min(requested,totalDue(loan)), i=Math.min(a,interestDue(loan)), p=Math.min(loan.principal,Math.max(0,a-i));loan.interestDue=round2(interestDue(loan)-i);loan.principal=round2(loan.principal-p);const currentInterestCleared=loan.interestDue<=0.004;const shouldAutoRenew=loan.periodicity==='monthly'&&loan.principal>0.004&&currentInterestCleared;if(loan.principal<=0.004&&currentInterestCleared){loan.status='paid';loan.interestDue=0;}else if(shouldAutoRenew){const previousDue=loan.due||today();loan.due=addMonthsDate(previousDue,1);loan.status='open';const newInterest=baseInterest(loan);loan.interestDue=round2(newInterest);s.loanCycles.push({id:uid(),loanId:loan.id,date:today(),due:loan.due,principal:loan.principal,interest:newInterest,capitalized:0,type:'renewal',automatic:true});}else loan.status='open';const pid=uid();s.loanPayments.push({id:pid,loanId:loan.id,date:today(),amount:round2(i+p),interest:i,principal:p,autoRenewed:shouldAutoRenew,createdAt:Date.now()});if(p>0)s.transactions.push({id:uid(),loanId:loan.id,loanPaymentId:pid,transactionRole:'loan_principal_return',type:'income',value:p,cat:'Juros / Empréstimo',date:today(),desc:`Principal recebido · ${loan.person}`,method:'Transferência',status:'Pago'});if(i>0)s.transactions.push({id:uid(),loanId:loan.id,loanPaymentId:pid,transactionRole:'loan_interest_income',type:'income',value:i,cat:'Juros / Empréstimo',date:today(),desc:`Juros recebidos · ${loan.person}`,method:'Transferência',status:'Pago'});});sh.close();toast('Pagamento registrado. Se restou principal após quitar os juros, o próximo ciclo foi renovado automaticamente.');}},'Registrar pagamento')]});
}

function renewLoan(l){
  const capitalize=h('input',{type:'checkbox'}), rate=h('input.input',{inputmode:'decimal',value:String(l.interestMode==='fixed'?(l.interestFixed||0):(l.interestRate||0)).replace('.',',')}), due=h('input.input',{type:'date',value:addMonthsDate(l.due||today(),1)}), msg=h('p.form-msg');
  const sh=openSheet({title:`Renovar · ${l.person}`,subtitle:'Nada é capitalizado automaticamente.',content:h('div.form',h('label.check',capitalize,h('span','Capitalizar juros pendentes no principal')),field(l.interestMode==='fixed'?'Juros do novo ciclo (R$)':'Taxa do novo ciclo (%)',rate),field('Novo vencimento',due),h('p.notice','Se capitalizar, os juros pendentes viram principal. Se não capitalizar, continuam separados do principal.'),msg),footer:[h('button.btn.primary',{type:'button',onclick:()=>{const v=parseMoney(rate.value);if(v<0||!due.value){msg.textContent='Revise taxa e vencimento.';return;}store.commit(s=>{const loan=s.loans.find(x=>x.id===l.id), oldInterest=interestDue(loan);if(capitalize.checked&&oldInterest>0){loan.principal=round2(loan.principal+oldInterest);loan.interestDue=0;}if(loan.interestMode==='fixed')loan.interestFixed=v;else loan.interestRate=v;loan.due=due.value;loan.status='open';loan.interestDue=round2(interestDue(loan)+baseInterest(loan));s.loanCycles.push({id:uid(),loanId:loan.id,date:today(),due:loan.due,principal:loan.principal,interest:baseInterest(loan),capitalized:capitalize.checked?oldInterest:0,type:'renewal'});});sh.close();toast('Empréstimo renovado.');}},'Confirmar renovação')]});
}

function timeline(s,l){
  const events=[];
  events.push({date:(l.createdAt?new Date(l.createdAt):null),iso:null,label:'Dinheiro emprestado',value:l.principalOriginal,kind:'out'});
  (s.loanCycles||[]).filter(c=>c.loanId===l.id).forEach(c=>{if(c.type==='renewal')events.push({date:null,iso:c.date,label:c.capitalized?`Renovado · ${money(c.capitalized)} capitalizados`:'Empréstimo renovado',value:c.interest,kind:'cycle'});});
  paidFor(s,l.id).forEach(p=>events.push({date:p.createdAt?new Date(p.createdAt):null,iso:p.date,label:`Pagamento · juros ${money(p.interest)} · principal ${money(p.principal)}`,value:p.amount,kind:'in'}));
  events.sort((a,b)=>String(b.iso||b.date?.toISOString()||'').localeCompare(String(a.iso||a.date?.toISOString()||'')));
  return h('div.loan-timeline',events.map(e=>{const d=e.iso|| (e.date?`${e.date.getFullYear()}-${String(e.date.getMonth()+1).padStart(2,'0')}-${String(e.date.getDate()).padStart(2,'0')}`:today());return h('div.loan-event',h('span.loan-dot',{class:e.kind}),h('div',h('b',e.label),h('small',shortDate(d))),h('strong',money(e.value)));}));
}

function loanDetail(l){
  const s=S(), st=loanStatus(l), rec=principalRecovered(s,l), ints=interestReceived(s,l);
  let sh;
  const footer=[
    h('button.btn.ghost.danger-text',{type:'button',onclick:()=>deleteLoan(l,sh)},'Excluir'),
    h('button.btn',{type:'button',onclick:()=>editLoan(l,sh)},'Editar')
  ];
  if(!isPaid(l)) footer.push(h('button.btn',{type:'button',onclick:()=>renewLoan(l)},'Renovar'),h('button.btn.primary',{type:'button',onclick:()=>payLoan(l)},'Registrar pagamento'));
  else footer.push(h('button.btn',{type:'button',disabled:true},'Quitado'));
  sh=openSheet({title:l.person,subtitle:st.label,wide:true,content:h('div.loan-detail',h('div.loan-detail-kpis',h('div.stat',h('span','Principal original'),h('b',money(l.principalOriginal))),h('div.stat',h('span','Principal atual'),h('b',money(l.principal))),h('div.stat',h('span','Juros pendentes'),h('b',money(interestDue(l)))),h('div.stat',h('span','Total a receber'),h('b',money(totalDue(l))))),progressBar(rec,l.principalOriginal,'Principal recuperado'),h('div.loan-meta',h('span',`Juros recebidos: ${money(ints)}`),h('span',`Vencimento: ${l.due?shortDate(l.due):'—'}`),h('span',l.interestMode==='fixed'?`Juros fixos: ${money(l.interestFixed)}`:`Taxa: ${l.interestRate||0}%`)),h('div.section-head',h('h3','Histórico')),timeline(s,l),l.note?h('p.notice',l.note):null),footer});
}


export function openLoanCalendarDetail(id){
  const s=S(), l=(s.loans||[]).find(x=>x.id===id);
  if(!l) return;
  const st=loanStatus(l), total=totalDue(l), interest=interestDue(l);
  const rows=[];
  const row=(k,v)=>rows.push(h('div.kv',h('span',k),h('b',v)));
  row('Vencimento',l.due?shortDate(l.due):'—');
  row('Principal restante',money(l.principal));
  row('Juros do ciclo',money(interest));
  row(l.interestMode==='fixed'?'Juros':'Taxa',l.interestMode==='fixed'?money(l.interestFixed||0):`${Number(l.interestRate||0)}%`);
  row('Situação',st.label);
  if(l.note) row('Observação',l.note);
  let sheet;
  const actions=[];
  if(!isPaid(l)) actions.push(h('button.btn.primary',{type:'button',onclick:()=>{sheet.close();setTimeout(()=>payLoan(l),120);}},'Registrar pagamento'));
  actions.push(h('button.btn',{type:'button',onclick:()=>{sheet.close();setTimeout(()=>editLoan(l),120);}},'Editar empréstimo'));
  actions.push(h('button.btn',{type:'button',onclick:()=>{sheet.close();setTimeout(()=>loanDetail(l),120);}},'Ver histórico'));
  sheet=openSheet({label:`Vencimento de ${l.person}`,content:[
    h('div.detail-head',h('span.tx-ico.lg.loan-due-icon',{'aria-hidden':'true'},'💰'),h('h2',l.person),h('p.detail-amount.in',money(total)),h('span.loan-status',{class:st.key},st.label)),
    h('div.kvs',rows),
    h('div.stack-actions',actions)
  ]});
}

function personDetail(person){const s=S(), list=(s.loans||[]).filter(l=>l.person===person), active=list.filter(l=>!isPaid(l)), principal=active.reduce((a,l)=>a+Number(l.principal||0),0), due=active.reduce((a,l)=>a+totalDue(l),0), ints=list.reduce((a,l)=>a+interestReceived(s,l),0), overdue=active.filter(l=>overdueDays(l)).length;openSheet({title:person,subtitle:`${list.length} empréstimo${list.length===1?'':'s'} · ${overdue?`${overdue} vencido${overdue>1?'s':''}`:'sem atrasos'}`,wide:true,content:h('div',h('div.loan-detail-kpis',h('div.stat',h('span','Principal pendente'),h('b',money(principal))),h('div.stat',h('span','Total a receber'),h('b',money(due))),h('div.stat',h('span','Juros recebidos'),h('b',money(ints)))),h('div.loan-list',list.map(l=>loanCard(s,l,true))))});}

function loanCard(s,l,compact=false){const st=loanStatus(l), rec=principalRecovered(s,l), ints=interestReceived(s,l);return h('section.card.loan-row',{class:`loan-${st.key}`},h('div.loan-row-head',h('div',h('b',l.person),h('small',l.due?`Vence ${shortDate(l.due)}`:'Sem vencimento')),h('span.loan-status',{class:st.key},st.label)),h('div.loan-amounts',h('span',h('small','Principal'),h('strong',money(l.principal))),h('span',h('small','Juros'),h('strong',money(interestDue(l)))),h('span',h('small','A receber'),h('strong',money(totalDue(l))))),progressBar(rec,l.principalOriginal,'Principal recuperado'),h('small.loan-earned',`Juros já recebidos: ${money(ints)}`),h('div.btn-row',h('button.btn',{type:'button',onclick:()=>loanDetail(l)},'Detalhes'),!isPaid(l)&&!compact?h('button.btn.primary',{type:'button',onclick:()=>payLoan(l)},'Registrar pagamento'):null));}

export function renderLoans(root){
  const s=S(), loans=s.loans||[], selectedYM=ctx.month||ymOf(today());
  const loanCreatedYM=l=>{if(!l.createdAt)return '';const d=new Date(l.createdAt);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;};
  const hasActivityInMonth=l=>loanCreatedYM(l)===selectedYM||String(l.due||'').startsWith(selectedYM)||paidFor(s,l.id).some(p=>String(p.date||'').startsWith(selectedYM));
  const monthLoans=loans.filter(hasActivityInMonth);
  const active=loans.filter(l=>!isPaid(l)), principal=active.reduce((a,l)=>a+Number(l.principal||0),0), ints=active.reduce((a,l)=>a+interestDue(l),0);
  const monthPayments=(s.loanPayments||[]).filter(p=>String(p.date||'').startsWith(selectedYM));
  const received=monthPayments.reduce((a,p)=>a+Number(p.interest||0),0), overdue=active.filter(l=>overdueDays(l)).reduce((a,l)=>a+totalDue(l),0), total=principal+ints;
  const shift=n=>{ctx.month=addMonthsYM(selectedYM,n);rerender();};
  const monthSwitch=h('div.month-switch',{role:'group','aria-label':'Mês dos empréstimos'},
    h('button.icon-btn',{type:'button','aria-label':'Mês anterior',onclick:()=>shift(-1)},'‹'),
    h('button.month-label',{type:'button',onclick:()=>{if(ctx.month!==ymOf(today())){ctx.month=ymOf(today());rerender();}}},monthLabel(selectedYM)),
    h('button.icon-btn',{type:'button','aria-label':'Próximo mês',onclick:()=>shift(1)},'›'));
  const filter=h('select.input.loan-filter',h('option',{value:'active'},'Em aberto'),h('option',{value:'overdue'},'Vencidos'),h('option',{value:'paid'},'Quitados'),h('option',{value:'all'},'Todos'));
  const listHost=h('div.loan-list');
  const draw=()=>{let list=monthLoans;if(filter.value==='active')list=monthLoans.filter(l=>!isPaid(l));if(filter.value==='overdue')list=monthLoans.filter(l=>overdueDays(l));if(filter.value==='paid')list=monthLoans.filter(isPaid);listHost.replaceChildren(...(list.length?list.map(l=>loanCard(s,l)): [h('div.empty',h('b',`Nenhum empréstimo com atividade em ${monthLabel(selectedYM).toLowerCase()}.`),h('p','O filtro considera criação, vencimento ou pagamento no mês selecionado.'))]));};
  filter.addEventListener('change',draw);
  root.append(h('div.page-head',h('div',h('span.eyebrow','A receber'),h('h2','Empréstimos'),h('p',active.length?`${money(total)} a receber · ${overdue?`${money(overdue)} vencidos`:'nenhum valor vencido'}`:'Acompanhe principal, juros, pagamentos e atrasos.')),h('button.btn.primary',{type:'button',onclick:newLoan},'Novo empréstimo')),
    h('div.page-head',monthSwitch,h('span.muted.sm',`Filtro: ${monthLabel(selectedYM)}`)),
    h('div.loan-kpis',h('div.stat',h('span','Principal pendente'),h('b',money(principal))),h('div.stat',h('span','Total a receber'),h('b',money(total))),h('div.stat',h('span','Juros a receber'),h('b',money(ints))),h('div.stat',h('span',`Juros recebidos · ${monthShort(selectedYM)}`),h('b',money(received))),h('div.stat.danger',h('span','Vencido'),h('b',money(overdue)))));
  if(loans.length){
    const people=[...new Set(active.map(l=>l.person))].map(person=>({label:person,value:active.filter(l=>l.person===person).reduce((a,l)=>a+totalDue(l),0),person})).sort((a,b)=>b.value-a.value);
    const months={};(s.loanPayments||[]).forEach(p=>{const ym=ymOf(p.date);months[ym]=(months[ym]||0)+Number(p.interest||0);});const interestMonths=Object.entries(months).sort(([a],[b])=>a.localeCompare(b)).slice(-6).map(([ym,value])=>({label:monthShort(ym).toUpperCase(),value}));
    root.append(h('div.loans-grid',h('section.card',h('div.section-head',h('div',h('h3','Carteira de empréstimos'),h('p','Toque em uma pessoa para ver os contratos.'))),donut(people,{center:'A receber',onPick:x=>personDetail(x.person)})),h('section.card',h('div.section-head',h('div',h('h3','Por pessoa'),h('p','Principal + juros pendentes.'))),bars(people,{onPick:x=>personDetail(x.person)}))),interestMonths.length?h('section.card.loan-interest-chart',h('div.section-head',h('div',h('h3','Juros recebidos'),h('p','Últimos meses com recebimento.'))),bars(interestMonths)):null);
    root.append(h('div.loan-list-head',h('div',h('h3','Contratos do mês'),h('p.muted.sm','Criação, vencimento ou pagamento no período selecionado.')),filter),listHost);draw();
  } else root.append(h('div.empty',h('b','Nenhum empréstimo cadastrado.'),h('p','Cadastre um empréstimo e acompanhe principal, juros, pagamentos e vencimentos.')));
}
export function openLoanForm(){newLoan();}
