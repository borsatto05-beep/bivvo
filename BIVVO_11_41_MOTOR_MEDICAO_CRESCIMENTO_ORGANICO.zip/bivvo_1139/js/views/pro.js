/* Bivvo 10.5 — planos pagos com checkout seguro no Mercado Pago. */
import { isDemo } from '../store.js';
import { h, money, shortDate } from '../util.js';
import { openSheet, toast, confirmSheet } from '../ui.js';
import { PRICES, getPlanInfo, PLAN_LIMITS, refreshPlan } from '../plans.js';
import { track } from '../analytics.js';
import { adminTrack } from '../admin-analytics.js';
import { getConversionOffer, markConversionShown, markConversionClosed } from '../conversion-engine.js';
import { startSubscription, syncBilling, cancelSubscription, pauseSubscription, reactivateSubscription, currentSubscription, startProTrial } from '../billing.js';

const BENEFITS = () => [
  { icon: '📸', title: 'Comprovantes inteligentes', text: `${PLAN_LIMITS.pro.scansPerMonth} leituras por mês no Pro (no Grátis são ${PLAN_LIMITS.free.scansPerMonth}).` },
  { icon: '🧠', title: 'Mais recursos de IA', text: 'Cotas maiores para recursos inteligentes do Bivvo.' },
  { icon: '📊', title: 'Previsão que olha para frente', text: 'Plus enxerga 30 dias. Pro chega a 90 dias e libera análises avançadas.' },
  { icon: '🛍️', title: 'Posso comprar? Pro', text: 'Compare cenários e veja o impacto da decisão antes de gastar.' }
];
const FEATURE_COPY = {
  scan: u => ({ title: `Você usou suas ${u?.limit ?? PLAN_LIMITS.free.scansPerMonth} leituras inteligentes deste mês.`, text: 'Você pode continuar digitando o valor normalmente ou escolher um plano com mais leituras.' }),
  cards: () => ({ title: 'Você chegou ao limite do plano Grátis.', text: 'Seus dados atuais continuam seguros.' }),
  assistant: () => ({ title: '✨ Tire suas dúvidas sobre dinheiro com o Bivvo IA', text: 'Descubra se uma compra cabe no orçamento, quanto você pode gastar e como suas decisões afetam o mês.' }),
  forecast30: () => ({ title: 'Quer enxergar os próximos 30 dias?', text: 'No Plus, a previsão mostra um horizonte maior e ajuda a antecipar dias apertados.' }),
  advancedForecast: () => ({ title: 'Quer enxergar os próximos 90 dias?', text: 'O Pro amplia a previsão para você se preparar com mais antecedência.' }),
  advancedSimulator: () => ({ title: 'Quer analisar essa compra com mais profundidade?', text: 'O Pro compara cenários e mostra mais impacto futuro antes de você decidir.' }),
  futureCards12: () => ({ title: 'Quer ver até 12 meses de parcelas futuras?', text: 'O Plus amplia a visão do comprometimento do cartão.' })
};
export function openPaywall({ feature = 'scan', usage, onUnlocked, placement = 'feature', explicit = true } = {}) {
  const offer=getConversionOffer({feature,placement,explicit,currentPlan:getPlanInfo().plan});
  if(!offer.shouldShow && !explicit) return null;
  if(offer.shouldShow){ markConversionShown(offer); track('conversion_opportunity_shown',{feature,placement,trigger:offer.trigger,plan:offer.recommendedPlan}); }
  const copy = (FEATURE_COPY[feature] || FEATURE_COPY.scan)(usage);
  track('paywall_viewed', { feature, placement, trigger:offer.trigger||'premium_feature_attempt', plan:offer.recommendedPlan||'pro' });
  adminTrack('paywall_viewed', 'paywall_' + feature).catch(() => {});
  const info = getPlanInfo();
  const canTrial = info.plan === 'free';
  let sheet;
  const startTrial = async (e) => {
    track('conversion_opportunity_clicked',{feature,placement,trigger:offer.trigger||'premium_feature_attempt',plan:offer.recommendedPlan||'pro'});
    const b=e.currentTarget; b.disabled=true; const old=b.textContent; b.textContent='Ativando Pro…';
    try {
      const r=await startProTrial();
      track('trial_started',{source:feature,plan:'pro'});
      adminTrack('trial_started','paywall_' + feature).catch(()=>{});
      await refreshPlan();
      sheet.close();
      track('premium_feature_used',{feature,source:'trial'});
      adminTrack('premium_feature_used','paywall_' + feature).catch(()=>{});
      toast(r.message || 'Bivvo Pro liberado por 7 dias.');
      if (typeof onUnlocked === 'function') setTimeout(()=>onUnlocked(), 80);
    } catch(err) { b.disabled=false; b.textContent=old; toast(err.message || 'Não foi possível iniciar o teste.'); }
  };
  const footer=[h('button.btn.ghost', { type:'button', onclick:()=>{ markConversionClosed(offer); track('paywall_closed',{feature,placement,trigger:offer.trigger||'premium_feature_attempt'}); sheet.close(); } }, 'Agora não')];
  if (canTrial) footer.push(h('button.btn.primary', { type:'button', onclick:startTrial }, 'Experimentar Pro por 7 dias'));
  else footer.push(h('button.btn.primary', { type:'button', onclick:()=>{ track('conversion_opportunity_clicked',{feature,placement,trigger:offer.trigger||'premium_feature_attempt',plan:offer.recommendedPlan||'pro'}); sheet.close(); setTimeout(()=>openProScreen({source:feature}),150); } }, 'Ver planos'));
  sheet = openSheet({
    title: copy.title,
    label: 'Bivvo Premium',
    content: h('div.paywall',
      h('p.muted', copy.text),
      feature === 'assistant' ? h('div.paywall-benefits',
        h('p','✓ Respostas usando os cálculos do seu Bivvo'),
        h('p','✓ Simulações antes de gastar'),
        h('p','✓ Análises personalizadas')
      ) : null,
      canTrial ? h('p.hint','7 dias de Pro · sem cartão · sem cobrança automática ao final do teste.') : null
    ),
    footer
  });
  return sheet;
}
export function openProScreen({ source = 'menu' } = {}) {
  track('pro_screen_viewed', { source });
  track('plans_viewed',{source});
  const info = getPlanInfo(); const active = info.plan !== 'free' && info.expiresAt;
  const plans = [
    ['plus','Plus','Previsão 30 dias · alertas · visão ampliada do cartão'],
    ['pro','Pro','Previsão 90 dias · Posso comprar? avançado · recursos inteligentes'],
    ['family','Família','Até 4 pessoas · espaço familiar com privacidade']
  ];
  let interval = 'annual';
  const pricingHost = h('div');
  const intervalLabel = h('p.plan-cycle-note');
  const monthlyBtn = h('button.plan-cycle-btn', { type:'button', onclick:()=>setIntervalChoice('monthly') }, 'Mensal');
  const annualBtn = h('button.plan-cycle-btn', { type:'button', onclick:()=>setIntervalChoice('annual') }, 'Anual · 2 meses grátis');

  const subscribe = async (e,key) => {
    if(isDemo()){openSheet({title:'Assinatura de demonstração',content:h('p','Você escolheu o Bivvo '+key+'. Os recursos já estão liberados para testar. Nenhum pagamento é solicitado e nenhuma cobrança é feita.')});return;}
    const b=e.currentTarget; b.disabled=true; const old=b.textContent; b.textContent='Preparando checkout…';
    track('plan_selected',{plan:key,source,interval});
    const price = interval === 'annual' ? PRICES[key].annual : PRICES[key].monthly;
    const ok = await confirmSheet({
      title:`Assinar Bivvo ${key === 'plus' ? 'Plus' : key === 'pro' ? 'Pro' : 'Família'}?`,
      message: interval === 'annual'
        ? `${money(price)} por ano. Isso equivale a ${money(price/12)}/mês e economiza ${money(PRICES[key].monthly*12-price)} em 12 meses. O pagamento é processado com segurança pelo Mercado Pago.`
        : `${money(price)} por mês, com cobrança recorrente pelo Mercado Pago. Você pode gerenciar ou cancelar a renovação pelo Bivvo.`,
      confirmLabel:'Ir para pagamento'
    });
    if (!ok) { b.disabled=false; b.textContent=old; return; }
    try { track('checkout_started',{plan:key,source,interval}); await startSubscription(key, interval); }
    catch(err){ b.disabled=false; b.textContent=old; toast(err.message || 'Não foi possível abrir o pagamento.'); }
  };

  function renderPrices(){
    const cards = plans.map(([key,name,desc]) => {
      const annual = interval === 'annual';
      const total = annual ? PRICES[key].annual : PRICES[key].monthly;
      const monthlyEq = PRICES[key].annual / 12;
      const saving = PRICES[key].monthly * 12 - PRICES[key].annual;
      return h('div.pro-price' + (key === 'pro' ? '.recommended' : ''),
        key === 'pro' ? h('span.plan-badge','MAIS ESCOLHIDO') : null,
        h('small', 'Bivvo ' + name),
        h('b', annual ? money(monthlyEq) : money(total)), h('span','por mês'),
        annual ? h('small.plan-total', `${money(total)}/ano · economize ${money(saving)}`) : h('small.plan-total','cobrança mensal'),
        h('small', desc),
        h('button.btn.primary.block', { type:'button', disabled: info.plan===key, onclick:e=>subscribe(e,key) }, info.plan===key ? 'Seu plano atual' : annual ? `Assinar ${name} anual` : `Assinar ${name}`)
      );
    });
    pricingHost.replaceChildren(h('div.pro-prices', cards));
    intervalLabel.textContent = interval === 'annual' ? 'Plano anual: você paga o equivalente a 10 meses e usa por 12.' : 'Plano mensal: flexibilidade com cobrança mês a mês.';
    monthlyBtn.classList.toggle('active', interval === 'monthly');
    annualBtn.classList.toggle('active', interval === 'annual');
  }
  function setIntervalChoice(next){
    interval = next;
    track('billing_interval_selected',{interval:next,source});
    renderPrices();
  }
  renderPrices();

  const sync = h('button.btn.ghost.block', { type:'button', onclick: async e => {
    const b=e.currentTarget; b.disabled=true; b.textContent='Atualizando…';
    try { await syncBilling(); await refreshPlan(); toast('Assinatura atualizada.'); b.textContent='Atualizado ✓'; }
    catch(err){ toast(err.message); b.textContent='Atualizar assinatura'; b.disabled=false; }
  }}, 'Já paguei · atualizar assinatura');
  const trial = !active ? h('button.btn.ghost.block', { type:'button', onclick: async e => { const b=e.currentTarget; b.disabled=true; const old=b.textContent; b.textContent='Ativando teste…'; try { const r=await startProTrial(); track('trial_started',{source,plan:'pro'}); adminTrack('trial_started','plans').catch(()=>{}); await refreshPlan(); toast(r.message || 'Teste Pro ativado.'); b.textContent='Pro liberado por 7 dias ✓'; } catch(err){ b.disabled=false; b.textContent=old; toast(err.message); } } }, 'Experimentar Pro por 7 dias · sem cartão') : null;
  const manage = active ? h('button.btn.ghost.block', { type:'button', onclick: () => openSubscriptionManager() }, 'Gerenciar minha assinatura') : null;
  openSheet({ label:'Planos Bivvo', wide:true, content:h('div.pro-screen',
    h('p.pro-kicker',isDemo()?'Demonstração · sem cobrança':'Bivvo Premium'), h('h2','Escolha o plano ideal para você.'),
    h('p.muted','Comece no seu ritmo. No anual, você economiza o equivalente a 2 mensalidades.'),
    active ? h('p.pro-active', `Você está no ${info.name} até ${shortDate(info.expiresAt.slice(0,10))}.`) : null,
    h('ul.pro-list', BENEFITS().map(b=>h('li',h('span.pro-ico',{'aria-hidden':'true'},b.icon),h('div',h('b',b.title),h('small',b.text))))),
    h('div.plan-cycle', monthlyBtn, annualBtn), intervalLabel, pricingHost, trial, manage, sync,
    h('div.checkout-trust', h('b','Pagamento seguro'), h('small','Processado pelo Mercado Pago. O Bivvo não recebe nem armazena os dados do seu cartão.'), h('small','Você vê o valor e confirma antes de seguir para o pagamento.'))
  )});
}


async function openSubscriptionManager() {
  try {
    const sub = await currentSubscription();
    if (!sub) return toast('Nenhuma assinatura encontrada.');
    const activeRenewal = sub.status === 'authorized';
    const paused = sub.status === 'paused';
    const statusText = activeRenewal ? 'Renovação automática ativa' : paused ? 'Assinatura pausada' : sub.status === 'cancelled' ? 'Renovação cancelada' : `Status: ${sub.status}`;
    const content = h('div.pro-screen', h('p.pro-kicker','MINHA ASSINATURA'), h('h2',getPlanInfo().name), h('p.muted',statusText),
      sub.next_payment_date ? h('p.hint', `${activeRenewal ? 'Próxima cobrança prevista' : 'Período informado'}: ${shortDate(String(sub.next_payment_date).slice(0,10))}`) : null,
      h('p.hint','Você pode cancelar sem obstáculos. Antes da confirmação final, o Bivvo mostra no máximo uma alternativa de pausa; se não quiser, o cancelamento segue normalmente.'));
    let sheet;
    let cancelReason = 'other';
    const doCancel = async b => {
      b.disabled=true; const old=b.textContent; b.textContent='Cancelando…';
      try {
        const r=await cancelSubscription();
        track('subscription_canceled',{plan:sub.plan,reason:cancelReason});
        track('cancellation_completed',{plan:sub.plan,reason:cancelReason});
        await refreshPlan(); sheet.close(); toast(r.message||'Renovação cancelada.');
      } catch(err){ b.disabled=false;b.textContent=old;toast(err.message||'Não foi possível cancelar.'); }
    };
    const showPauseOffer = () => {
      track('cancel_offer_viewed',{plan:sub.plan,reason:cancelReason});
      const offer = openSheet({
        title:'Antes de cancelar',
        content:h('div.pro-screen',
          h('h3','Quer só dar uma pausa?'),
          h('p.muted','Você pode pausar a renovação e reativar depois. É uma única alternativa, sem insistência.'),
          h('p.hint','Se preferir cancelar, seguimos normalmente. Seu acesso já pago é preservado conforme o período vigente.')
        ),
        footer:[
          h('button.btn.ghost',{type:'button',onclick:async e=>{const b=e.currentTarget;b.disabled=true;b.textContent='Pausando…';try{const r=await pauseSubscription();track('subscription_paused',{plan:sub.plan,reason:cancelReason});track('cancel_retained_pause',{plan:sub.plan,reason:cancelReason});await refreshPlan();offer.close();sheet.close();toast(r.message||'Assinatura pausada.');}catch(err){b.disabled=false;b.textContent='Pausar assinatura';toast(err.message);}}},'Pausar assinatura'),
          h('button.btn.danger',{type:'button',onclick:async e=>{offer.close(); if(await confirmSheet({title:'Cancelar renovação?',message:'Não haverá novas cobranças. O acesso já pago é preservado conforme o período vigente.',confirmLabel:'Confirmar cancelamento',danger:true})) await doCancel(e.currentTarget);}},'Continuar cancelamento')
        ]
      });
    };
    const cancelFlow = () => {
      track('cancel_flow_started',{plan:sub.plan});
      const reasons = [
        ['price','Está caro para mim'],
        ['low_use','Não estou usando'],
        ['missing_feature','Faltou um recurso'],
        ['technical','Tive problema técnico'],
        ['temporary','Quero parar por um tempo'],
        ['other','Outro motivo']
      ];
      let reasonSheet;
      const buttons = reasons.map(([reason,label])=>h('button.btn.ghost.block',{type:'button',onclick:()=>{cancelReason=reason;track('cancel_reason_selected',{plan:sub.plan,reason});reasonSheet.close();setTimeout(showPauseOffer,80);}},label));
      reasonSheet=openSheet({
        title:'Por que você quer cancelar?',
        content:h('div.pro-screen',h('p.muted','Sua resposta ajuda a melhorar o Bivvo. Não pedimos detalhes financeiros.'),...buttons),
        footer:[h('button.btn.ghost',{type:'button',onclick:()=>reasonSheet.close()},'Voltar')]
      });
    };
    const footer=[h('button.btn.ghost',{type:'button',onclick:()=>sheet.close()},'Fechar')];
    if (activeRenewal) footer.push(h('button.btn.danger',{type:'button',onclick:cancelFlow},'Cancelar renovação'));
    if (paused) footer.push(h('button.btn.primary',{type:'button',onclick:async e=>{const b=e.currentTarget;b.disabled=true;b.textContent='Reativando…';try{const r=await reactivateSubscription();track('subscription_reactivated',{plan:sub.plan});await refreshPlan();sheet.close();toast(r.message||'Assinatura reativada.');}catch(err){b.disabled=false;b.textContent='Reativar assinatura';toast(err.message);}}},'Reativar assinatura'));
    sheet=openSheet({label:'Minha assinatura',content,footer});
  } catch(e){ toast(e.message||'Não foi possível carregar sua assinatura.'); }
}
