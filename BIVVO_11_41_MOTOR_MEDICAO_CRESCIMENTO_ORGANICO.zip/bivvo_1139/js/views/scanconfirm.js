/* Bivvo Scan — confirmação. Uma leitura NUNCA vira lançamento sem o toque em "Confirmar". */
import { h, money, today } from '../util.js';
import * as store from '../store.js';
import { openSheet, catIcon, field } from '../ui.js';
import { moneyInput } from './forms.js';
import { saveParsed, openSmartCapture } from '../quickcapture.js';
import { toNumber } from '../quickparse.js';

const METHODS = ['PIX', 'Débito', 'Crédito', 'Dinheiro', 'Boleto', 'Transferência'];
const norm = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

export function openScanConfirm(d) {
  const s = store.getState();
  /* segunda conferência no aparelho: se o texto lido e o número divergem, vale o texto e o alerta aparece */
  const fromText = toNumber(String(d.valueText || '').replace(/[^\d.,]/g, ''));
  if (fromText > 0 && d.value != null && Math.abs(fromText - d.value) > 0.009) d = { ...d, value: fromText, mismatch: true };
  const value = moneyInput(d.value, { big: true, label: 'Valor' });
  const descText = d.merchant || d.description || 'Compra';
  const desc = h('input.input', { type: 'text', maxLength: 60, value: descText, 'aria-label': 'Descrição' });
  const cats = store.categories('expense', s);
  const guess = store.autoCategory(descText, 'expense', s) || cats.find(c => norm(c) === norm(d.categoryHint)) || cats.find(c => d.categoryHint && norm(c).startsWith(norm(d.categoryHint).slice(0, 5))) || 'Outros';
  const cat = h('select.input', { 'aria-label': 'Categoria' }, cats.map(c => h('option', { value: c }, `${catIcon(c)} ${c}`))); cat.value = cats.includes(guess) ? guess : cats[0];
  const date = h('input.input', { type: 'date', value: d.date && d.date <= today() ? d.date : today(), max: today(), 'aria-label': 'Data' });
  const method = h('select.input', { 'aria-label': 'Forma de pagamento' }, METHODS.filter(m => m !== 'Crédito' || s.cards.length).map(m => h('option', { value: m }, m)));
  method.value = d.method && (d.method !== 'Crédito' || s.cards.length) ? d.method : 'PIX';
  const card = h('select.input', { 'aria-label': 'Cartão' }, s.cards.map(c => h('option', { value: c.name }, c.name)));
  const parts = h('select.input', { 'aria-label': 'Parcelas' }, Array.from({ length: 24 }, (_, i) => h('option', { value: i + 1 }, i ? `${i + 1}x` : 'À vista')));
  parts.value = String(d.installments || 1);
  const creditRow = h('div.row2', field('Cartão', card), field('Parcelas', parts, 'O valor é o total da compra.'));
  const paintCredit = () => { creditRow.hidden = method.value !== 'Crédito'; };
  method.addEventListener('change', paintCredit); paintCredit();
  const careful = d.mismatch || d.confidence < 0.7 || d.value == null;
  const msg = h('p.form-msg', { role: 'alert' });
  const sheet = openSheet({
    title: 'Confirmar lançamento', subtitle: d.demo?'Comprovante fictício para testar a conferência e o lançamento.':'Lido do comprovante. Confira antes de salvar.',
    content: h('div.form.scan-confirm',
      h('div.scan-read' + (careful ? '.warn' : ''), h('small', 'Valor lido no comprovante'), h('b', d.valueText || (d.value != null ? money(d.value) : 'não identificado')), careful ? h('small', d.value == null ? 'Não consegui ler o valor. Digite abaixo.' : 'Confira o valor com atenção: a leitura não ficou totalmente clara.') : null),
      field('Valor da compra', value), field('Descrição', desc), h('div.row2', field('Categoria', cat), field('Data', date)), field('Forma de pagamento', method), creditRow, msg,
      h('p.hint', 'A imagem não foi guardada.')),
    footer: [h('button.btn.ghost', { type: 'button', onclick: () => edit() }, 'Editar'), h('button.btn.primary', { type: 'button', onclick: () => confirm() }, 'Confirmar')]
  });
  if (careful) setTimeout(() => value.focus(), 120);
  const build = () => {
    const v = value.getValue();
    if (!(v > 0)) { msg.textContent = 'Informe o valor da compra.'; value.focus(); return null; }
    const isCredit = method.value === 'Crédito' && s.cards.length;
    const c = isCredit ? s.cards.find(x => x.name === card.value) || s.cards[0] : null;
    return { value: v, desc: desc.value.trim() || 'Compra', type: 'expense', cat: cat.value, date: date.value || today(), parts: isCredit ? Number(parts.value) : 1, card: c, future: false, method: isCredit ? 'Crédito' : method.value };
  };
  function confirm() { const p = build(); if (!p) return; sheet.close(); saveParsed(p, { cat: p.cat, cardName: p.card?.name, source: 'scan' }); }
  async function edit() {
    const p = build(); sheet.close();
    const { openTxForm } = await import('./forms.js');
    setTimeout(() => openTxForm({ mode: p?.card ? 'card' : 'expense', preset: p ? { value: p.value, desc: p.desc, cat: p.cat, date: p.date, card: p.card?.name, parts: p.parts } : {} }), 150);
  }
}

export function openScanUnavailable(reason) {
  const text = reason === 'demo' ? 'A leitura de comprovantes usa sua conta (são 5 leituras grátis por mês). Na demonstração, digite ou fale o gasto.'
    : 'A leitura de comprovantes ainda não foi ativada neste Bivvo. Enquanto isso, digite ou fale o gasto.';
  const sheet = openSheet({ title: 'Leitura de comprovante', content: h('p.sheet-text', text),
    footer: [h('button.btn.ghost', { type: 'button', onclick: () => sheet.close() }, 'Fechar'), h('button.btn.primary', { type: 'button', onclick: () => { sheet.close(); setTimeout(() => openSmartCapture(), 150); } }, 'Digitar o gasto')] });
}
