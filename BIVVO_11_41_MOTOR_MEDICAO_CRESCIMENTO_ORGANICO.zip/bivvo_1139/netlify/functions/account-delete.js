const SUPABASE_URL='https://gqfirbhzjuzspermyvfy.supabase.co';

function adminHeaders(key, extra={}){
  const h={apikey:key,'Cache-Control':'no-store',...extra};
  // Legacy service_role keys are JWTs and may be used as Bearer tokens.
  // New sb_secret_* keys must be sent as API keys, not Bearer JWTs.
  if(String(key).startsWith('eyJ')) h.Authorization='Bearer '+key;
  return h;
}

exports.handler=async(event)=>{
  const headers={'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
  const out=(statusCode,body)=>({statusCode,headers,body:JSON.stringify(body)});
  if(event.httpMethod!=='POST') return out(405,{error:'Método não permitido.'});
  const jwt=String(event.headers.authorization||event.headers.Authorization||'').replace(/^Bearer\s+/i,'').trim();
  if(!jwt) return out(401,{error:'Sessão ausente.'});

  // First validate this exact token with Supabase Auth. Only then trust its claims.
  const publicKey=process.env.SUPABASE_PUBLISHABLE_KEY||'sb_publishable_AGD0F361Dci_rgnplWctlg_cD_9vUoz';
  const ur=await fetch(SUPABASE_URL+'/auth/v1/user',{headers:{apikey:publicKey,Authorization:'Bearer '+jwt,'Cache-Control':'no-store'}});
  if(!ur.ok) return out(401,{error:'Sessão inválida ou expirada.'});
  const user=await ur.json();

  let claims={};
  try{claims=JSON.parse(Buffer.from(jwt.split('.')[1]||'','base64url').toString('utf8'))}catch{}
  if(!user?.id || claims.sub!==user.id) return out(401,{error:'Usuário inválido.'});
  const issued=Number(claims.iat||0);
  if(!issued || (Date.now()/1000-issued)>300) return out(401,{error:'Reautenticação recente obrigatória para excluir a conta.'});

  const adminKey=process.env.SUPABASE_SECRET_KEY||process.env.SUPABASE_SERVICE_ROLE_KEY;
  if(!adminKey) return out(503,{error:'Configure SUPABASE_SECRET_KEY (ou a chave service_role legada) no Netlify.'});

  // A senha acabou de ser confirmada no cliente e este token foi validado acima.
  // Se a conta tiver MFA verificado, o SDK do Supabase exige o desafio antes de
  // enviar a sessão AAL2. Não dependa de uma RPC SQL opcional para excluir a conta:
  // instalações antigas do Bivvo podem não ter essa função e acabavam recebendo 503.
  const aal=claims.aal||'aal1';
  if(!['aal1','aal2'].includes(aal)) return out(401,{error:'Nível de autenticação inválido.'});

  const dr=await fetch(SUPABASE_URL+'/auth/v1/admin/users/'+encodeURIComponent(user.id),{
    method:'DELETE',headers:adminHeaders(adminKey)
  });
  if(!dr.ok){const j=await dr.json().catch(()=>({}));return out(500,{error:j.msg||j.message||'Falha ao excluir conta.'})}
  return out(200,{ok:true});
};
