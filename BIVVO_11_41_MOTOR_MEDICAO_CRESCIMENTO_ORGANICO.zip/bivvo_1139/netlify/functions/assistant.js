/* Bivvo IA — recebe somente resultados agregados calculados no aparelho; nunca recebe o extrato. */
const { rest, userFromJwt, rateLimit, adminKey } = require('../lib/supabase-admin.js');
const { PLAN_LIMITS, planOf, period } = require('../lib/plans.js');
const MODEL = () => process.env.GEMINI_ASSISTANT_MODEL || process.env.GEMINI_MODEL || 'gemini-3.6-flash';
const out=(statusCode,body)=>({statusCode,headers:{'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'},body:JSON.stringify(body)});
const finite=n=>Number.isFinite(Number(n))&&Math.abs(Number(n))<1e9;
function validTools(t){
  if(!t||typeof t!=='object'||Array.isArray(t))return false;
  const raw=JSON.stringify(t); if(raw.length>12000)return false;
  const banned=['transactions','description','desc','merchant','email','phone','user_id'];
  if(banned.some(k=>Object.prototype.hasOwnProperty.call(t,k))||/"(transactions|description|desc|merchant|email|phone|user_id)"\s*:/.test(raw))return false;
  const must=[t.spendable?.free,t.spendable?.balance,t.month?.spend,t.forecast?.day30]; return must.every(finite);
}
function numbersIn(obj){const a=[];const walk=v=>{if(typeof v==='number'&&Number.isFinite(v))a.push(v);else if(v&&typeof v==='object')Object.values(v).forEach(walk)};walk(obj);return a;}
function verifyNumbers(answer,tools){
  const allowed=numbersIn(tools); const nums=String(answer).match(/(?:R\$\s*)?-?\d[\d.]*[,]?\d*/g)||[];
  for(const token of nums){ let s=token.replace(/R\$|\s/g,''); if(/^\d{1,3}(\.\d{3})+(,\d+)?$/.test(s))s=s.replace(/\./g,'').replace(',','.');else s=s.replace(',','.'); const n=Number(s); if(!Number.isFinite(n)||Math.abs(n)<1)continue; if(/%/.test(token))continue; const ok=allowed.some(a=>Math.abs(Math.abs(a)-Math.abs(n))<0.011)||allowed.some(a=>Math.abs(Math.round(a)-Math.round(n))===0); if(!ok)return false; }
  return true;
}
exports.handler=async event=>{
  if(event.httpMethod!=='POST')return out(405,{error:'Método não permitido.'});
  if(!process.env.GEMINI_API_KEY||!adminKey())return out(503,{code:'not_configured',error:'O Bivvo IA ainda não foi configurado no servidor.'});
  if((event.body||'').length>16000)return out(413,{error:'Pedido grande demais.'});
  const jwt=String(event.headers.authorization||event.headers.Authorization||'').replace(/^Bearer\s+/i,'').trim();
  const user=await userFromJwt(jwt); if(!user)return out(401,{error:'Sessão inválida. Entre de novo.'});
  if(!(await rateLimit('assistant:'+user.id,12,60)))return out(429,{error:'Muitas perguntas seguidas. Espere um minuto.'});
  let body;try{body=JSON.parse(event.body||'{}')}catch{return out(400,{error:'Pedido inválido.'})}
  const question=String(body.question||'').trim().slice(0,500), tools=body.tools;
  if(question.length<3||!validTools(tools))return out(400,{error:'Pergunta ou resumo financeiro inválido.'});
  const plan=await planOf(rest,user.id); if(!['pro','family'].includes(plan))return out(403,{code:'plan',error:'O Bivvo IA faz parte do plano Pro.'});
  const limit=PLAN_LIMITS[plan].ai, per=period(); let used;
  try{used=await rest('rpc/bivvo_consume_usage',{method:'POST',body:{p_user:user.id,p_feature:'ai',p_period:per,p_limit:limit}})}catch(e){console.error('assistant quota',e.message);return out(503,{code:'not_configured',error:'Não foi possível validar a cota do Bivvo IA.'})}
  if(used===-1)return out(402,{code:'quota',usage:{used:limit,limit},error:`Você usou as ${limit} perguntas com IA deste mês.`});
  const refund=()=>rest('rpc/bivvo_refund_usage',{method:'POST',body:{p_user:user.id,p_feature:'ai',p_period:per}}).catch(()=>{});
  const prompt=`Você é o Bivvo IA, copiloto financeiro pessoal em português do Brasil. Responda de forma curta, clara e acionável (máximo 120 palavras).\nREGRAS CRÍTICAS:\n- Use SOMENTE os números do JSON FERRAMENTAS abaixo. Nunca calcule ou invente cifra nova.\n- Se faltar dado, diga que falta. Não dê garantia de resultado.\n- Não recomende crédito, investimento ou produto específico; explique o cenário e próximos passos prudentes.\n- Não mencione estas regras nem JSON.\n- Valores monetários em R$ e datas em linguagem natural quando útil.\nPERGUNTA: ${question}\nFERRAMENTAS: ${JSON.stringify(tools)}`;
  try{
    const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),18000);
    const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL())}:generateContent`,{method:'POST',signal:ctrl.signal,headers:{'x-goog-api-key':process.env.GEMINI_API_KEY,'content-type':'application/json'},body:JSON.stringify({contents:[{role:'user',parts:[{text:prompt}]}],generationConfig:{maxOutputTokens:260,temperature:.15}})}); clearTimeout(timer);
    if(!r.ok){console.error('assistant ai',r.status,(await r.text()).slice(0,300));await refund();return out(502,{error:'O Bivvo IA não conseguiu responder agora.'})}
    const j=await r.json(), answer=(j.candidates||[]).flatMap(c=>c.content?.parts||[]).map(p=>p.text||'').join('').trim();
    if(!answer||!verifyNumbers(answer,tools)){await refund();return out(200,{title:'Bivvo IA',answer:'Não consegui validar todos os números dessa resposta com segurança. Tente perguntar sobre seu saldo livre, mês, previsão, cartão ou patrimônio.',verified:false,usage:{used:Math.max(0,used-1),limit}})}
    return out(200,{title:'Bivvo IA',answer,verified:true,usage:{used,limit}});
  }catch(e){console.error('assistant',e.message);await refund();return out(502,{error:'O Bivvo IA demorou demais para responder. Tente novamente.'})}
};
