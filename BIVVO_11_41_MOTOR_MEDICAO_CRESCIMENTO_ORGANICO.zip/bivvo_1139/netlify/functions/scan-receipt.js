/* Bivvo Scan — lê um comprovante e devolve os campos para o usuário CONFIRMAR.
   Nunca grava lançamento. A imagem não é armazenada: só passa por aqui e pela API de IA. */
const { rest, userFromJwt, rateLimit, adminKey } = require('../lib/supabase-admin.js');
const { PLAN_LIMITS, planOf, period } = require('../lib/plans.js');

const MODEL = () => process.env.GEMINI_MODEL || 'gemini-3.6-flash';
const METHODS = ['PIX', 'Débito', 'Crédito', 'Dinheiro', 'Boleto', 'Transferência'];
const toNumber = t => {
  let s = String(t || '').replace(/[^\d.,]/g, '');
  if (/^\d{1,3}(\.\d{3})+(,\d{1,2})?$/.test(s)) s = s.replace(/\./g, '').replace(',', '.');
  else if (/^\d+,\d{1,2}$/.test(s)) s = s.replace(',', '.');
  else if (/^\d{1,3}(,\d{3})+(\.\d{1,2})?$/.test(s)) s = s.replace(/,/g, '');
  const n = Number(s); return Number.isFinite(n) ? n : NaN;
};

const RESPONSE_SCHEMA = {
  type: 'OBJECT',
  properties: {
    is_receipt: { type: 'BOOLEAN' },
    value_text: { type: ['STRING', 'NULL'] },
    value: { type: ['NUMBER', 'NULL'] },
    date: { type: ['STRING', 'NULL'] },
    merchant: { type: ['STRING', 'NULL'] },
    description: { type: ['STRING', 'NULL'] },
    payment_method: { type: ['STRING', 'NULL'] },
    installments: { type: ['INTEGER', 'NULL'] },
    category_hint: { type: ['STRING', 'NULL'] },
    confidence: { type: 'NUMBER' }
  },
  required: [
    'is_receipt',
    'value_text',
    'value',
    'date',
    'merchant',
    'description',
    'payment_method',
    'installments',
    'category_hint',
    'confidence'
  ]
};

const PROMPT = `Você lê comprovantes brasileiros (Pix, cupom fiscal, nota, boleto pago, recibo de cartão).
Responda SOMENTE com um objeto JSON, sem texto antes ou depois, neste formato:
{"is_receipt":true,"value_text":"texto exato do valor total pago como aparece na imagem, ex.: R$ 83,70","value":83.70,"date":"AAAA-MM-DD ou null","merchant":"nome do estabelecimento ou recebedor ou null","description":"descrição curta em português ou null","payment_method":"PIX|Débito|Crédito|Dinheiro|Boleto|Transferência|null","installments":null,"category_hint":"uma palavra como Mercado, Restaurante, Farmácia, Transporte, Combustível ou null","confidence":0.0}
Regras: "value" é o TOTAL efetivamente pago (não subtotal, não troco). Se houver parcelamento, "value" é o total da compra e "installments" o número de parcelas.
Nunca invente: se não conseguir ler um campo, use null e reduza "confidence". Se não for um comprovante, "is_receipt": false.`;

exports.handler = async event => {
  const headers = { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' };
  const out = (statusCode, body) => ({ statusCode, headers, body: JSON.stringify(body) });
  if (event.httpMethod !== 'POST') return out(405, { error: 'Método não permitido.' });
  if (!process.env.GEMINI_API_KEY) return out(503, { code: 'not_configured', error: 'A leitura de comprovantes ainda não foi configurada no servidor.' });
  if (!adminKey()) return out(503, { code: 'not_configured', error: 'Configure SUPABASE_SECRET_KEY no Netlify.' });
  if ((event.body || '').length > 3_000_000) return out(413, { error: 'Imagem grande demais. Tente uma foto mais próxima do comprovante.' });

  const jwt = String(event.headers.authorization || event.headers.Authorization || '').replace(/^Bearer\s+/i, '').trim();
  const user = await userFromJwt(jwt);
  if (!user) return out(401, { error: 'Sessão inválida. Entre de novo.' });
  if (!(await rateLimit('scan:' + user.id, 8, 60))) return out(429, { error: 'Muitas leituras seguidas. Espere um minuto.' });

  let body; try { body = JSON.parse(event.body || '{}'); } catch { return out(400, { error: 'Pedido inválido.' }); }
  const media = String(body.mediaType || '');
  const data = String(body.image || '');
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(media) || !/^[A-Za-z0-9+/=]{1000,}$/.test(data)) return out(400, { error: 'Envie uma imagem JPG, PNG ou WebP.' });

  /* cota no SERVIDOR: consome antes, devolve se a leitura falhar */
  const plan = await planOf(rest, user.id), limit = PLAN_LIMITS[plan].scan, per = period();
  let used;
  try { used = await rest('rpc/bivvo_consume_usage', { method: 'POST', body: { p_user: user.id, p_feature: 'scan', p_period: per, p_limit: limit } }); }
  catch (e) { console.error('scan quota', e.message); return out(503, { code: 'not_configured', error: 'Rode supabase-monetizacao.sql no Supabase para liberar a leitura de comprovantes.' }); }
  if (used === -1) return out(402, { code: 'quota', plan, usage: { used: limit, limit }, error: `Você usou as ${limit} leituras inteligentes deste mês.` });
  const refund = () => rest('rpc/bivvo_refund_usage', { method: 'POST', body: { p_user: user.id, p_feature: 'scan', p_period: per } }).catch(() => {});

  try {
    const ctrl = new AbortController(); const timer = setTimeout(() => ctrl.abort(), 20000);
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL())}:generateContent`, {
      method: 'POST', signal: ctrl.signal,
      headers: { 'x-goog-api-key': process.env.GEMINI_API_KEY, 'content-type': 'application/json' },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [
          { inline_data: { mime_type: media, data } },
          { text: PROMPT }
        ] }],
        generationConfig: { responseMimeType: 'application/json', maxOutputTokens: 1200 }
      })
    });
    clearTimeout(timer);
    if (!r.ok) { console.error('scan ai', r.status, (await r.text()).slice(0, 300)); await refund(); return out(502, { error: 'Não consegui ler agora. Tente de novo ou digite o valor.' }); }
    const j = await r.json();
    const text = (j.candidates || []).flatMap(c => (c.content && c.content.parts) || []).map(p => p.text || '').join('');
    const cleaned = text
      .replace(/^```(?:json)?\s*/i, '')
      .replace(/\s*```$/i, '')
      .trim();
    const m = cleaned.match(/\{[\s\S]*\}/);
    let o;
    try {
      o = JSON.parse(m ? m[0] : cleaned);
    } catch {
      console.error('scan json parse', cleaned.slice(0, 500));
      await refund();
      return out(422, { error: 'Consegui analisar a imagem, mas não consegui organizar os dados. Tente novamente.' });
    }
    if (!o.is_receipt) { await refund(); return out(422, { error: 'Isso não parece um comprovante. Tente outra imagem.' }); }

    /* validação: o número e o texto do valor precisam concordar. 18,90 nunca vira 189,00 em silêncio. */
    const v = Number(o.value), vt = toNumber(o.value_text);
    let value = Number.isFinite(v) && v > 0 && v < 1e7 ? Math.round(v * 100) / 100 : null;
    let confidence = Math.max(0, Math.min(1, Number(o.confidence) || 0));
    const mismatch = value != null && Number.isFinite(vt) && Math.abs(vt - value) > 0.009;
    if (mismatch) { value = Math.round(vt * 100) / 100; confidence = Math.min(confidence, 0.4); }
    if (value == null && Number.isFinite(vt) && vt > 0) { value = Math.round(vt * 100) / 100; confidence = Math.min(confidence, 0.5); }
    const date = /^\d{4}-\d{2}-\d{2}$/.test(o.date || '') ? o.date : null;
    const clean = x => (typeof x === 'string' ? x.replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, 60) : null) || null;
    return out(200, {
      ok: true, plan, usage: { used, limit },
      data: { value, valueText: clean(o.value_text), date, merchant: clean(o.merchant), description: clean(o.description), method: METHODS.includes(o.payment_method) ? o.payment_method : null,
        installments: Number.isInteger(o.installments) && o.installments > 1 && o.installments <= 48 ? o.installments : null, categoryHint: clean(o.category_hint), confidence, mismatch }
    });
  } catch (e) {
    console.error('scan', e.message); await refund();
    return out(504, { error: 'A leitura demorou demais. Tente de novo ou digite o valor.' });
  }
};
