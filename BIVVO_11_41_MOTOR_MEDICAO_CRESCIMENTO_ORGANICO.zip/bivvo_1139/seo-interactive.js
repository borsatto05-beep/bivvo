(()=>{
  const num=v=>Number(String(v||'').replace(/\./g,'').replace(',','.'))||0;
  const brl=v=>v.toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
  const qBtn=document.getElementById('qCalc');
  if(qBtn) qBtn.addEventListener('click',()=>{
    const s=num(document.getElementById('qSaldo')?.value), c=num(document.getElementById('qContas')?.value), d=Math.max(1,Math.floor(num(document.getElementById('qDias')?.value)));
    const livre=Math.max(0,s-c), dia=livre/d;
    document.getElementById('qResultado').textContent=brl(dia);
    document.getElementById('qTexto').textContent=livre>0?`${brl(livre)} livres para ${d} dia${d>1?'s':''}.`:'Pelos valores informados, não há sobra livre antes da próxima renda.';
    const box=document.querySelector('.live-result');
    if(box&&!document.getElementById('qSignup')){
      const a=document.createElement('a'); a.id='qSignup'; a.className='primary-cta';
      a.textContent='Quero isso automático no Bivvo';
      const u=new URL('/',location.origin);u.searchParams.set('signup','1');u.searchParams.set('utm_source',new URLSearchParams(location.search).get('utm_source')||'public_tool');u.searchParams.set('utm_medium',new URLSearchParams(location.search).get('utm_medium')||'calculator');u.searchParams.set('utm_campaign',new URLSearchParams(location.search).get('utm_campaign')||'quanto_posso_gastar_result');
      const ref=new URLSearchParams(location.search).get('ref'); if(ref&&/^[a-f0-9]{8}$/.test(ref))u.searchParams.set('ref',ref);
      a.href=u.toString(); a.setAttribute('data-seo','signup'); a.setAttribute('data-seo-target','calculator_result'); box.append(a);
    }
  });
  const cBtn=document.getElementById('cCalc');
  if(cBtn) cBtn.addEventListener('click',()=>{
    const l=num(document.getElementById('cLimite')?.value), fa=num(document.getElementById('cFatura')?.value), p=num(document.getElementById('cParcelas')?.value);
    const usado=fa+p, livre=Math.max(0,l-usado), pct=l?Math.min(100,usado/l*100):0;
    document.getElementById('cResultado').textContent=brl(livre);
    document.getElementById('cTexto').textContent=`${pct.toFixed(0)}% do limite está comprometido considerando fatura e parcelas informadas.`;
  });
})();
