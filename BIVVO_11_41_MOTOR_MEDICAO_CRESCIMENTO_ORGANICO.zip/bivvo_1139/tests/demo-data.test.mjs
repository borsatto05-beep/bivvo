import assert from 'node:assert/strict';
const RealDate=Date;
let now=new RealDate(2026,9,22,12).getTime();
globalThis.Date=class extends RealDate{constructor(...args){super(...(args.length?args:[now]));}static now(){return now;}};
globalThis.window={addEventListener(){}};
globalThis.sessionStorage={getItem(){return null},setItem(){},removeItem(){}};
globalThis.localStorage=globalThis.sessionStorage;
const {buildDemo}=await import('../js/demo.js');
const F=await import('../js/finance.js');
const store=await import('../js/store.js');
const {addMonthsYM,ymOf,today}=await import('../js/util.js');
for(const [y,m,d] of [[2026,9,22],[2027,0,1],[2028,1,29],[2026,11,31]]){
 now=new RealDate(y,m,d,12).getTime();
 const s=buildDemo();store.load(s,{demo:true});
 assert(s.loans.length>=15);assert(s.investments.length>=15);assert(s.loanPayments.length>=15);
 assert(s.transactions.filter(F.isSpend).length>=15);assert(s.transactions.filter(F.isRealIncome).length>=15);
 const ids=s.transactions.map(t=>t.id);assert.equal(new Set(ids).size,ids.length);
 assert(s.transactions.every(t=>t.desc&&t.cat&&/^\d{4}-\d{2}-\d{2}$/.test(t.date)&&Number.isFinite(t.value)&&t.value>=0));
 for(let i=0;i<6;i++){
  const ym=addMonthsYM(ymOf(today()),-i),summary=F.monthSummary(ym,store.getState());
  assert(F.monthTx(ym,store.getState()).length>=15);
  assert(summary.income>0);assert(summary.spend>0);
  assert(s.loans.some(l=>l.due.startsWith(ym)));
  assert(s.investments.some(x=>x.purchaseDate.startsWith(ym)));
 }
 assert(s.investments.every(x=>s.transactions.some(t=>t.id===x.txId&&t.investmentId===x.id&&F.isSave(t))));
}
console.log('OK: seis meses e mínimos por grupo, IDs únicos, valores válidos, vínculos de investimentos e datas em início/fim de mês, virada do ano e ano bissexto.');
