const {readFileSync}=require('node:fs');
const vm=require('node:vm');
const assert=require('node:assert/strict');
function h(tag,...children){
  const props=children[0]&&typeof children[0]==='object'&&!Array.isArray(children[0])&&!children[0].tag?children.shift():{};
  const node={tag,props,children:children.flat(Infinity).filter(x=>x!=null),value:'',addEventListener(k,f){this[k]=f;},append(...xs){this.children.push(...xs);},replaceChildren(...xs){this.children=xs;}};
  if(tag.startsWith('select'))node.value=node.children[0].props.value;
  return node;
}
const loan=(id,due,extra={})=>({id,person:id,due,principal:100,principalOriginal:100,interestDue:10,status:'open',createdAt:new Date(2026,9,1).getTime(),...extra});
const state={loans:[
  loan('outubro','2026-10-15'),loan('novembro','2026-11-15'),
  loan('renovado','2026-11-10'),loan('quitado','2026-10-10',{status:'paid'}),
  loan('setembro','2026-09-10'),loan('outro-ano','2027-10-15'),
  loan('parcial','2026-10-28',{interestDue:5})
],loanPayments:[{loanId:'renovado',date:'2026-10-10',interest:10},{loanId:'novembro',date:'2026-10-12',interest:10}]};
const ctx={month:'2026-10'};
const money=n=>'R$ '+n;
const sandbox={console,Date,Math,Number,String,Set,store:{getState:()=>state},ctx,h,money,today:()=>'2026-10-22',round2:n=>Math.round(n*100)/100,ymOf:s=>String(s||'').slice(0,7),diffDays:()=>7,monthLabel:s=>s,monthShort:s=>s,shortDate:s=>s,progressBar:()=>null,donut:()=>null,bars:()=>null,rerender(){}};
vm.createContext(sandbox);
const source=readFileSync(__dirname+'/../js/views/loans.js','utf8').replace(/^import .*;\n/gm,'').replace(/^export /gm,'');
vm.runInContext(source,sandbox);
function walk(n){return typeof n==='object'?[n,...n.children.flatMap(walk)]:[];}
function text(n){return typeof n==='object'?n.children.map(text).join(' '):String(n);}
function render(){const root=h('root');sandbox.renderLoans(root);return root;}
let root=render();
let nodes=walk(root);
const list=nodes.find(n=>n.tag==='div.loan-list');
assert.match(text(list),/outubro/);assert.match(text(list),/parcial/);
for(const name of ['novembro','renovado','quitado','setembro','outro-ano'])assert(!text(list).includes(name),name+' deve ficar fora');
assert.match(text(nodes.find(n=>n.tag==='div.page-head')),/R\$ 215 a receber/);
assert.match(text(nodes.find(n=>n.tag==='div.page-head')),/R\$ 110 vencidos/);
const filter=nodes.find(n=>n.tag==='select.input.loan-filter');
filter.value='paid';filter.change();assert.match(text(list),/quitado/);assert(!text(list).includes('novembro'));
filter.value='overdue';filter.change();assert.match(text(list),/outubro/);assert(!text(list).includes('parcial'));
ctx.month='2026-11';root=render();const november=walk(root).find(n=>n.tag==='div.loan-list');assert.match(text(november),/novembro/);assert.match(text(november),/renovado/);assert(!text(november).includes('outubro'));
ctx.month='2026-12';root=render();assert.match(text(walk(root).find(n=>n.tag==='div.loan-list')),/Nenhum empréstimo/);
console.log('OK: pendentes, renovação, quitação, pagamento parcial, totais, vencidos, navegação, ano e mês vazio.');
