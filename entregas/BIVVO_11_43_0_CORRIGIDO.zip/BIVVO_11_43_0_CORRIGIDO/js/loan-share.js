import {money,round2} from './util.js';

export function loanShareText(loan){
  const principal=Math.max(0,Number(loan.principal)||0);
  const interest=Math.max(0,round2(loan.interestDue!=null?Number(loan.interestDue)||0:loan.interestMode==='fixed'?Number(loan.interestFixed)||0:principal*(Number(loan.interestRate)||0)/100));
  const original=Math.max(0,Number(loan.principalOriginal??principal)||0);
  const due=/^\d{4}-\d{2}-\d{2}$/.test(loan.due||'')?loan.due.split('-').reverse().join('/'):'Não informado';
  const period=loan.periodicity==='monthly'?'ao mês':'único';
  const terms=loan.interestMode==='fixed'?`${money(loan.interestFixed||0)} (${period})`:`${Number(loan.interestRate)||0}% (${period})`;
  const lines=[`Olá, ${loan.person||'cliente'}! Segue o resumo do seu empréstimo:`, '',`Valor emprestado: ${money(original)}`,`Juros combinados: ${terms}`,`Principal pendente: ${money(principal)}`,`Juros pendentes: ${money(interest)}`,`Total a pagar no vencimento: ${money(round2(principal+interest))}`,`Vencimento: ${due}`];
  if(loan.status==='paid'||principal+interest<=0.004)lines.push('Situação: quitado.');
  return lines.join('\n');
}
