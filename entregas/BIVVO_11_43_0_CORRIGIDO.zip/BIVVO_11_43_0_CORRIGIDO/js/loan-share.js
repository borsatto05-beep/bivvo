import {money,round2} from './util.js';

export function loanShareSummary(loan){
  const principal=Math.max(0,Number(loan.principal)||0);
  const interest=Math.max(0,round2(loan.interestDue!=null?Number(loan.interestDue)||0:loan.interestMode==='fixed'?Number(loan.interestFixed)||0:principal*(Number(loan.interestRate)||0)/100));
  const original=Math.max(0,Number(loan.principalOriginal??principal)||0);
  const due=/^\d{4}-\d{2}-\d{2}$/.test(loan.due||'')?loan.due.split('-').reverse().join('/'):'Não informado';
  const period=loan.periodicity==='monthly'?'ao mês':'único';
  const terms=loan.interestMode==='fixed'?`${money(loan.interestFixed||0)} (${period})`:`${Number(loan.interestRate)||0}% (${period})`;
  return {principal,interest,original,due,terms,total:round2(principal+interest),paid:loan.status==='paid'||principal+interest<=0.004};
}

export function loanShareText(loan){
  const s=loanShareSummary(loan);
  const lines=[`Olá, ${loan.person||'cliente'}! 👋`, '', '📋 *Resumo do seu empréstimo*', '', `💵 Valor emprestado: ${money(s.original)}`, `📈 Juros combinados: ${s.terms}`];
  if(s.principal!==s.original)lines.push(`✅ Valor emprestado já devolvido: ${money(Math.max(0,round2(s.original-s.principal)))}`);
  lines.push('', '🧾 *O que falta pagar*', `Valor emprestado restante: ${money(s.principal)}`, `Juros a pagar: ${money(s.interest)}`, '', `💰 *Total a pagar: ${money(s.total)}*`, `📅 *Vencimento: ${s.due}*`, '', s.paid?'✅ Empréstimo quitado.':'O total acima já considera os pagamentos registrados.');
  return lines.join('\n');
}
