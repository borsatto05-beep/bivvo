/* Bivvo — entrada do app: autenticação, roteamento, ciclo de vida. */
import { h, $, $$, clear, VERSION, today, debounce } from './util.js';
import * as store from './store.js';
import * as cloud from './cloud.js';
import { toast, openSheet, askSheet, closeAllSheets } from './ui.js';
import { buildDemo } from './demo.js';
import { settleChallenges } from './insights.js';
import { renderHome } from './views/home.js';
import { renderExtrato } from './views/extrato.js';
import { renderCards } from './views/cards.js';
import { renderPlans } from './views/plans.js';
import { renderYou } from './views/you.js';
import { renderAdmin } from './views/admin.js?v=8.19.3';
import { adminMe } from './admin-api.js';
import { adminTrack, trackVisit, trackSignupStart } from './admin-analytics.js?v=8.19.3';
import { renderCalendar } from './views/calendar.js';
import { renderForecast } from './views/forecast.js';
import { renderAssistant } from './views/assistant.js?v=11.42.6';
import { renderFamily } from './views/family.js';
import { renderLoans } from './views/loans.js?v=11.42.6';
import { renderRecovery } from './views/recovery.js';
import { openQuickAdd, openTxForm } from './views/forms.js';
import { startOnboarding } from './views/onboarding.js';
import { celebrateChallenge } from './views/stories.js';
import { ctx, setHooks } from './nav.js';
import { initPlatform, openInstallGuide, scheduleInstallOffer } from './platform.js';
import { openSmartCapture, shouldOfferEveningCapture, markEveningCaptureShown } from './quickcapture.js?v=11.43.0';
import { syncDigest } from './push.js';
import { refreshPlan } from './plans.js';
import { track, trackOnce } from './analytics.js';
import { maybeActivateReferral } from './referral.js';
import { readSplitFromHash, renderSplitPublic } from './views/split.js';
import { markRetentionMilestones, maybeOfferMonthlyReport, markSmartReturn, maybeOfferSmartReturn } from './retention.js';
import { initErrorTracking } from './telemetry.js';
import { bindPublicTools } from './public-tools.js';
initErrorTracking();

const ROUTES = {
  inicio: { title: 'Início', render: renderHome },
  extrato: { title: 'Movimentações', render: renderExtrato },
  cartoes: { title: 'Cartões', render: renderCards },
  calendario: { title: 'Calendário', render: renderCalendar },
  previsao: { title: 'Previsão', render: renderForecast },
  assistente: { title: 'Bivvo IA', render: renderAssistant },
  familia: { title: 'Família', render: renderFamily },
  emprestimos: { title: 'Empréstimos', render: renderLoans },
  jornada: { title: 'Minha Jornada', render: renderRecovery },
  planos: { title: 'Planejamento', render: renderPlans },
  voce: { title: 'Você', render: renderYou },
  admin: { title: 'Administração', render: renderAdmin }
};
let booted = false;
let startupCaptureShown = false;
let startupCaptureTimer = null;
let splitView = false;
trackVisit();
window.__bivvoStoreOnboarded = () => !!store.getState().profile.onboarded;

/* ---------------- roteamento ---------------- */
function parseHash() {
  const raw = location.hash.replace(/^#\/?/, '');
  const [path, query = ''] = raw.split('?');
  const name = ROUTES[path] ? path : 'inicio';
  const params = Object.fromEntries(new URLSearchParams(query));
  return { name, params };
}
function go(route, params = {}) {
  const q = new URLSearchParams(params).toString();
  const target = '#/' + route + (q ? '?' + q : '');
  const nav = () => { if (location.hash === target) render(true); else location.hash = target; };
  if (document.querySelector('.sheet-wrap')) { closeAllSheets(); setTimeout(nav, 120); } else nav();
}
window.addEventListener('hashchange', () => { if (splitView) return; closeAllSheets(); render(true); });

const view = () => $('#view');
let lastRoute = null;
function render(routeChanged = false) {
  if (!booted) return;
  const { name, params } = parseHash();
  if(name==='emprestimos'&&!store.loansEnabled()){go('inicio');return;}
  ctx.route = name; ctx.params = params;
  const el = view();
  const keepScroll = !routeChanged && lastRoute === name ? window.scrollY : 0;
  const r = ROUTES[name];
  clear(el);
  el.dataset.route = name;
  try { r.render(el, ctx); }
  catch (e) { console.error(e); el.append(h('div.empty', h('b', 'Esta tela encontrou um erro.'), h('p', 'Seus dados estão seguros. Recarregue a página para tentar de novo.'))); }
  $('#tbTitle').textContent = r.title;
  document.title = r.title + ' · Bivvo';
  syncNav();
  $$('[data-route]').forEach(b => { const on = b.dataset.route === name || (!!b.closest('.tabbar') && b.dataset.route==='planos' && (name==='previsao'||(name==='calendario'&&store.loansEnabled()))); b.classList.toggle('on', on); if (on) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current'); });
  if (routeChanged) { window.scrollTo(0, 0); el.classList.remove('enter'); void el.offsetWidth; el.classList.add('enter'); }
  else if (keepScroll) window.scrollTo(0, keepScroll);
  lastRoute = name;
  if (!ctx.demo) adminTrack('page_view', name).catch(() => {});
  if (name === 'inicio' && params.shared === '1') {
    history.replaceState(history.state, '', '#/inicio'); ctx.params = {}; startupCaptureShown = true;
    caches.open('bivvo-share').then(async c => { const r = await c.match('./__shared-receipt'); await c.delete('./__shared-receipt'); if (!r || Number(r.headers.get('X-Bivvo-Expires') || 0) < Date.now()) return; track('share_target_used'); const { startScan } = await import('./quickcapture.js'); startScan(await r.blob()); }).catch(() => {});
  }
  if (name === 'inicio' && params.simular === '1') { history.replaceState(history.state, '', '#/inicio'); ctx.params = {}; startupCaptureShown = true; import('./views/simulator.js').then(m => setTimeout(() => m.openSimulator(), 200)); }
  if (name === 'inicio' && params.capture === '1') { history.replaceState(history.state, '', '#/inicio'); ctx.params = {}; startupCaptureShown = true; setTimeout(() => openSmartCapture(), 200); }
}
const rerender = debounce(() => render(false), 16);

function syncNav() {
  const loans = store.loansEnabled();
  document.body.classList.toggle('mod-loans', loans);
  $$('.rail [data-route="emprestimos"]').forEach(b => { b.hidden = !loans; });
  $$('.tabbar [data-route="emprestimos"]').forEach(b => { b.hidden = !loans; });
  $$('.tabbar [data-route="calendario"]').forEach(b => { b.hidden = loans; });
}
const pushDigestSoon = debounce(() => { syncDigest(); }, 5000);

store.onChange(({ reason }) => {
  if (!booted) return;
  if (reason !== 'load' && reason !== 'settle') {
    const fresh = store.commit(s => settleChallenges(s), { reason: 'settle', silent: true });
    if (fresh?.length) setTimeout(() => celebrateChallenge(fresh[0]), 400);
  }
  rerender();
  if (!ctx.demo) { pushDigestSoon(); referralSoon(); }
});
const referralSoon = debounce(() => { maybeActivateReferral(); }, 8000);

/* ---------------- shell ---------------- */
function bindShell() {
  $$('[data-route]').forEach(b => b.addEventListener('click', () => go(b.dataset.route)));
  $$('[data-action="add"]').forEach(b => b.addEventListener('click', () => openQuickAdd()));
  $('#demoSignup')?.addEventListener('click', () => leaveDemo(true));
  cloud.onSyncStatus(st => {
    const d = $('#syncDot'); if (!d) return;
    d.dataset.state = st;
    d.title = { saving: 'Salvando…', pending: 'Alterações pendentes', saved: 'Tudo salvo na nuvem', error: 'Não foi possível salvar. Tentaremos de novo.', offline: 'Sem internet. Salvaremos quando voltar.', idle: '' }[st] || '';
    d.setAttribute('aria-label', d.title);
    const status=$('#syncStatus');
    if(status){status.textContent=!navigator.onLine?'Sem conexão · dados locais disponíveis':ctx.demo?'Demonstração · dados locais':{saving:'Sincronizando…',pending:'Salvo no aparelho · sincronização pendente',saved:'Salvo na nuvem',error:'Salvo no aparelho · não foi possível sincronizar',offline:'Sem conexão · salvo no aparelho',idle:ctx.demo?'Demonstração · dados locais':''}[st]||'';status.dataset.state=st;}
  });
  const syncOnOpen = async () => {
    if (!booted || ctx.demo || !cloud.currentUser()) return;
    const r = await cloud.syncNow();
    if (r?.changed) toast('Dados sincronizados com a nuvem.');
  };
  window.addEventListener('online',()=>{const status=$('#syncStatus');if(status){status.textContent=ctx.demo?'Demonstração · dados locais':cloud.currentUser()?'Conexão restabelecida · sincronizando…':'';status.dataset.state='pending';}syncOnOpen();});
  window.addEventListener('offline',()=>{const status=$('#syncStatus');if(status){status.textContent='Sem conexão · dados locais disponíveis';status.dataset.state='offline';}});
  window.addEventListener('pageshow', () => { syncOnOpen(); });
  document.addEventListener('visibilitychange', async () => {
    if (document.visibilityState === 'hidden') { cloud.flush().catch(() => {}); if (!ctx.demo) syncDigest(); }
    else { await syncOnOpen(); }
  });
  window.addEventListener('pagehide', () => { cloud.flush().catch(() => {}); });
  window.addEventListener('bivvo:remote-reset', () => toast('Os dados foram zerados em outro aparelho.'));
  document.addEventListener('keydown', e => {
    if (e.key === 'n' && !e.metaKey && !e.ctrlKey && !/input|textarea|select/i.test(document.activeElement?.tagName || '') && !document.body.classList.contains('sheet-open') && booted) { e.preventDefault(); openQuickAdd(); }
  });
}

function setAdminNavVisible(visible) {
  const desktop = $('#adminNav');
  const mobile = $('#adminNavMobile');
  const tabbar = document.querySelector('.tabbar');
  if (desktop) desktop.hidden = !visible;
  if (mobile) mobile.hidden = !visible;
  if (tabbar) tabbar.classList.toggle('admin-enabled', visible);
}

function showAuth({ direct = false } = {}) {
  booted = false;
  setAdminNavVisible(false);
  document.body.classList.remove('booting', 'in-app', 'demo');
  $('#app').hidden = true; $('#landing').hidden = direct; $('#auth').hidden = !direct;
  closeAllSheets();
}
async function showApp({ demo = false } = {}) {
  $('#landing').hidden = true;
  ctx.demo = demo;
  document.body.classList.toggle('demo', demo);
  document.body.classList.remove('booting');
  document.body.classList.add('in-app');
  $('#auth').hidden = true; $('#app').hidden = false;
  $('#demoBar').hidden = !demo;
  setAdminNavVisible(false);
  booted = true;
  if (!location.hash) history.replaceState(history.state, '', '#/inicio');
  store.commit(s => settleChallenges(s), { reason: 'settle', silent: true });
  render(true);
  if (!demo) {
    refreshPlan().catch(() => {});
    trackOnce('app_open', 'day');
    maybeOfferSmartReturn();
    markSmartReturn();
    markRetentionMilestones(cloud.currentUser());
    setTimeout(() => maybeOfferMonthlyReport(), 1200);
    adminMe()
      .then(() => setAdminNavVisible(true))
      .catch(() => setAdminNavVisible(false));
  }
  clearTimeout(startupCaptureTimer);
  if (!startupCaptureShown && shouldOfferEveningCapture({ demo })) {
    startupCaptureShown = true;
    startupCaptureTimer = setTimeout(() => {
      if (!booted || document.querySelector('.sheet-wrap') || !shouldOfferEveningCapture({ demo: ctx.demo })) return;
      markEveningCaptureShown();
      openSmartCapture({ startup: true, onDisable: () => { store.commit(s => { s.profile.eveningCapture = false; }); toast('Pronto. Você pode religar em Você → Avisos e lembretes.'); } });
    }, 900);
  }
  if (ctx.params.add === 'expense') setTimeout(() => openTxForm({ mode: 'expense' }), 300);
  if (!demo && !store.getState().profile.onboarded && !store.getState().profile.onboardingDeferred) setTimeout(() => startOnboarding({ onDemo: enterDemo }), 300);
  if (!demo) scheduleInstallOffer({ isNewUser: sessionStorage.getItem('bivvo_just_signed_up') === '1' });
}

/* ---------------- demo ---------------- */
function enterDemo() {
  closeAllSheets();
  store.load(buildDemo(), { demo: true });
  showApp({ demo: true });
  toast('Você está na demonstração. Nada aqui é salvo.');
}
async function leaveDemo(toSignup) {
  store.load(store.emptyState(), { demo: true });
  ctx.demo = false;
  if (cloud.currentUser()) { await bootUser(cloud.currentUser()); return; }
  showAuth({ direct: true });
  if (toSignup) setAuthMode('signup');
}

/* ---------------- sessão real ---------------- */
async function bootUser(user) {
  document.body.classList.add('booting');
  const cache = store.readSessionCache(user.id);
  if (cache) { store.load(cache, { userId: user.id }); showApp(); }
  try {
    const remote = await cloud.loadRemote();
    store.load(remote || store.emptyState(), { userId: user.id });
    if (!remote) { try { sessionStorage.setItem('bivvo_just_signed_up','1'); } catch {} await cloud.push({ force: true }).catch(() => {}); trackOnce('signup'); adminTrack('signup_completed', 'signup').catch(() => {}); }
    if (!cache) showApp(); else render(false);
  } catch (e) {
    console.error(e);
    if (!cache) { store.load(store.emptyState(), { userId: user.id }); showApp(); }
    toast('Não foi possível carregar da nuvem agora. Suas próximas alterações serão salvas quando a conexão voltar.', { tone: 'warn' });
  }
  cloud.securityLog('login');
}

/* ---------------- tela de entrada ---------------- */
let authMode = 'login';
function setAuthMode(mode) {
  authMode = mode;
  if (mode === 'signup') trackSignupStart();
  const f = $('#authForm');
  f.dataset.mode = mode;
  $$('.auth-tab').forEach(t => t.classList.toggle('on', t.dataset.mode === mode));
  $('#authSubmit').textContent = mode === 'signup' ? 'Criar minha conta' : mode === 'forgot' ? 'Enviar link de recuperação' : 'Entrar';
  $('#authPassword').autocomplete = mode === 'signup' ? 'new-password' : 'current-password';
  $('#authPassword').required = mode !== 'forgot';
  $('#authConfirm').required = mode === 'signup';
  $('#authName').required = mode === 'signup';
  $('#authPhone').required = mode === 'signup';
  authMsg('');
}
function authMsg(text, tone = 'err') { const m = $('#authMsg'); m.textContent = text; m.dataset.tone = text ? tone : ''; }
const askMfa = () => askSheet({ title: 'Verificação em duas etapas', message: 'Digite o código de 6 dígitos do seu aplicativo autenticador.', label: 'Código', inputmode: 'numeric', autocomplete: 'one-time-code', placeholder: '000000', pattern: /^\d{6}$/, confirmLabel: 'Verificar' });

function initLandingExperiment(){
  const key='bivvo_ab_landing_hero_v1'; let variant='A';
  try { variant=localStorage.getItem(key)||((crypto.getRandomValues(new Uint8Array(1))[0]%2)?'B':'A'); localStorage.setItem(key,variant); } catch {}
  const h1=document.querySelector('.landing-copy h1'), start=document.querySelector('#landingStart');
  if(variant==='B'){
    if(h1) h1.innerHTML='Pare de adivinhar quanto pode gastar <em>hoje.</em>';
    if(start) start.textContent='Descobrir meu limite grátis';
  }
  document.documentElement.dataset.abLandingHero=variant;
  adminTrack('ab_exposure','landing',{content:'landing_hero:'+variant}).catch(()=>{});
  return variant;
}
function bindAuth() {
  const landingVariant=initLandingExperiment();
  $('#landingDemo')?.addEventListener('click', () => { adminTrack('landing_demo_clicked', 'landing').catch(() => {}); enterDemo(); });
  $('#landingLogin')?.addEventListener('click', () => showAuth({ direct: true }));
  const startFree = () => { adminTrack('ab_conversion','landing',{content:'landing_hero:'+landingVariant}).catch(() => {}); adminTrack('landing_signup_clicked', 'landing').catch(() => {}); showAuth({ direct: true }); setAuthMode('signup'); };
  $('#landingStart')?.addEventListener('click', startFree);
  $('#landingStartBottom')?.addEventListener('click', startFree);
  $('#landingHow')?.addEventListener('click', () => { adminTrack('landing_how_clicked', 'landing').catch(() => {}); $('#landingBenefits')?.scrollIntoView({ behavior: 'smooth', block: 'start' }); });
  $$('.auth-tab').forEach(t => t.addEventListener('click', () => setAuthMode(t.dataset.mode)));
  $('#authForgot').addEventListener('click', () => setAuthMode('forgot'));
  $('#authDemo').addEventListener('click', enterDemo);
  $('#authForm').addEventListener('submit', async e => {
    e.preventDefault();
    const email = $('#authEmail').value.trim();
    const pass = $('#authPassword').value;
    const conf = $('#authConfirm').value;
    const name = $('#authName').value.trim();
    const phone = $('#authPhone').value.trim();
    const btn = $('#authSubmit');

    if (!email) return authMsg('Informe seu e-mail.');
    if (authMode === 'signup' && name.length < 3) return authMsg('Informe seu nome completo.');
    if (authMode === 'signup' && phone.replace(/\D/g, '').length < 10) return authMsg('Informe um telefone/WhatsApp válido.');
    if (authMode !== 'forgot' && pass.length < 10) return authMsg('A senha precisa ter pelo menos 10 caracteres.');
    if (authMode === 'signup' && pass !== conf) return authMsg('As senhas não são iguais.');

    btn.disabled = true; const label = btn.textContent; btn.textContent = 'Aguarde…'; authMsg('');
    try {
      if (authMode === 'forgot') { await cloud.sendRecovery(email); authMsg('Se existir uma conta com esse e-mail, você vai receber um link para criar uma nova senha.', 'ok'); }
      else if (authMode === 'signup') {
        const data = await cloud.signUp(email, pass, name, phone);

        // TikTok Pixel: registra Lead somente após um cadastro realmente aceito pelo Supabase.
        // Não envia e-mail, telefone, nome, external_id nem dados financeiros.
        // Em projetos com confirmação de e-mail, tentativas com e-mail já existente podem
        // retornar um usuário sem identities; por isso esse caso não conta como conversão.
        const isNewRegistration = !!data?.user && (!Array.isArray(data.user.identities) || data.user.identities.length > 0);
        if (isNewRegistration && window.bivvoPrivacy?.marketingAllowed()) {
          // Um único event_id é compartilhado entre Pixel e Events API para deduplicação.
          // O user_id serve apenas para o servidor confirmar que o cadastro acabou de existir;
          // ele NÃO é enviado ao TikTok.
          const eventId = 'bivvo_lead_' + (crypto.randomUUID?.() || (Date.now() + '_' + Math.random().toString(36).slice(2)));
          if (window.ttq?.track) {
            try { window.ttq.track('Lead', {}, { event_id: eventId }); } catch {}
          }
          try {
            const qs = new URLSearchParams(location.search);
            const ttclid = qs.get('ttclid') || '';
            if (data.session?.access_token) fetch('/api/tiktok-event', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', Authorization:'Bearer ' + data.session.access_token },
              body: JSON.stringify({ user_id: data.user.id, event_id: eventId, url: location.origin + location.pathname, ttclid, consent:true }),
              keepalive: true
            }).catch(() => {});
          } catch {}
        }

        if (data.session) await cloud.openCurrentSession();
        else authMsg('Conta criada. Confirme pelo link enviado ao seu e-mail e depois entre.', 'ok');
      } else {
        await cloud.signIn(email, pass, askMfa);
        await cloud.openCurrentSession();
      }
    } catch (err) { authMsg(cloud.friendlyAuthError(err)); }
    finally { btn.disabled = false; btn.textContent = label; }
  });
}

function recoveryFlow() {
  const pass = h('input.input', { type: 'password', autocomplete: 'new-password', minLength: 10, placeholder: 'Mínimo 10 caracteres' });
  const pass2 = h('input.input', { type: 'password', autocomplete: 'new-password', minLength: 10, placeholder: 'Repita a senha' });
  const msg = h('p.form-msg');
  const sheet = openSheet({
    title: 'Criar nova senha',
    content: [h('label.field', h('span', 'Nova senha'), pass), h('label.field', h('span', 'Confirmar senha'), pass2), msg],
    footer: [h('button.btn.primary', { type: 'button', onclick: async () => {
      if (pass.value.length < 10) { msg.textContent = 'Use pelo menos 10 caracteres.'; return; }
      if (pass.value !== pass2.value) { msg.textContent = 'As senhas não são iguais.'; return; }
      try { await cloud.setNewPassword(pass.value); sheet.close(); toast('Senha atualizada.'); await cloud.openCurrentSession(); }
      catch (e) { msg.textContent = cloud.friendlyAuthError(e); }
    } }, 'Salvar nova senha')]
  });
}

/* ---------------- início ---------------- */
function captureReferral() {
  try {
    const ref = new URLSearchParams(location.search).get('ref');
    if (ref && /^[a-f0-9]{8}$/.test(ref)) { localStorage.setItem('bivvo_ref', ref); history.replaceState(null, '', location.pathname + location.hash); setAuthMode('signup'); }
  } catch { /* ignore */ }
}

setHooks({ go, enterDemo, leaveDemo, render });

function purgeLegacyStorage() {
  try {
    for (const k of Object.keys(localStorage)) if (/^(mf_|bivvo_demo|bivvo_welcome|bivvo_v7|v724)/i.test(k)) localStorage.removeItem(k);
    for (const k of Object.keys(sessionStorage)) if (/^mf_/.test(k)) sessionStorage.removeItem(k);
  } catch { /* modo privado */ }
}


async function registerServiceWorker() {
  if (!('serviceWorker' in navigator) || location.protocol !== 'https:') return;
  try {
    const reg = await navigator.serviceWorker.register('./sw.js', { updateViaCache: 'none' });
    // Força a conferência do sw.js depois de um deploy; evita PWA preso em versão antiga.
    reg.update().catch(() => {});
  } catch { /* app continua funcionando sem PWA */ }
}

async function start() {
  purgeLegacyStorage(); initPlatform();
  if ('caches' in window) caches.open('bivvo-share').then(async c => { const r=await c.match('./__shared-receipt'); if(r && Number(r.headers.get('X-Bivvo-Expires') || 0)<Date.now()) await c.delete('./__shared-receipt'); }).catch(()=>{});
  $('#appVersion') && ($('#appVersion').textContent = 'v' + VERSION);
  bindShell(); bindAuth(); bindPublicTools(); setAuthMode('login'); captureReferral();
  if (new URLSearchParams(location.search).get('signup') === '1') { showAuth({ direct: true }); setAuthMode('signup'); }
  const split = readSplitFromHash();
  if (split) {
    splitView = true;
    document.body.classList.remove('booting'); document.body.classList.add('split-mode');
    const el = $('#splitPage'); el.hidden = false; $('#landing').hidden = true;
    const leave = () => { splitView = false; el.hidden = true; document.body.classList.remove('split-mode'); history.replaceState(null, '', location.pathname); };
    renderSplitPublic(el, split, {
      onTry: () => { leave(); enterDemo(); },
      onOpen: () => { leave(); location.reload(); }
    });
    registerServiceWorker();
    return;
  }
  if (new URLSearchParams(location.search).get('demo') === '1') { enterDemo(); }
  try {
    await cloud.initAuth({
      onSignedIn: user => { if (ctx.demo) { ctx.demo = false; } bootUser(user); },
      onSignedOut: () => { if (!ctx.demo) { store.load(store.emptyState(), { demo: true }); showAuth(); } },
      onRecovery: recoveryFlow
    });
  } catch (e) {
    if (!ctx.demo) showAuth();
    authMsg(cloud.friendlyAuthError(e));
  }
  registerServiceWorker();
}
start();
