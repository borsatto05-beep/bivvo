let paid=false;
export const hasPaidAccess=()=>paid;
export const setPaidAccess=plan=>{paid=['plus','pro','family'].includes(plan);};
