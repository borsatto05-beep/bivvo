/* Bivvo 10.5 — planos e permissões (entitlements). ÚNICO lugar que decide o que cada plano pode.
   Regra da casa: nenhum arquivo testa `plan === 'pro'`. Use canUseFeature / getPlanLimits / getRemainingUsage.

   Enquanto não houver cobrança real (BILLING_LIVE = false):
   - nada que já existia no Bivvo é bloqueado;
   - só recursos que geram custo (leitura de comprovante com IA) têm limite, e o limite é
     conferido também no servidor (netlify/functions/scan-receipt.js). O limite daqui só serve para a interface. */
import * as cloud from './cloud.js';
import {setPaidAccess} from './paid-access.js';

export const BILLING_LIVE = true;

/* Preços em um só lugar (altere aqui). */
export const PRICES = {
  plus: { monthly: 9.9, annual: 99.0 },
  pro: { monthly: 19.9, annual: 199.0 },
  family: { monthly: 39.99, annual: 399.0 }
};

/* Limites mensais por plano. Infinity = sem limite. Espelhado em netlify/lib/plans.js. */
export const PLAN_LIMITS = {
  free: { cards: 3, scansPerMonth: 0, aiPerMonth: 0 },
  plus: { cards: Infinity, scansPerMonth: 30, aiPerMonth: 30 },
  pro: { cards: Infinity, scansPerMonth: 200, aiPerMonth: 300 },
  family: { cards: Infinity, scansPerMonth: 200, aiPerMonth: 300 }
};

/* Qual plano mínimo libera cada recurso. Recursos que não estão aqui são livres para todos. */
const FEATURE_MIN_PLAN = {
  unlimitedCards: 'plus', advancedReports: 'plus', exportCSV: 'plus', smartNotifications: 'plus',
  loans:'plus', company:'plus', couple:'plus', assistant: 'plus', advancedForecast: 'pro', forecast30: 'plus', advancedSimulator: 'pro', futureCards12: 'plus', smartAlerts: 'plus'
};
/* Recursos que já existiam antes dos planos: só passam a ser cobrados quando a cobrança existir. */
const LEGACY_FREE_UNTIL_BILLING = new Set(['unlimitedCards', 'advancedReports', 'exportCSV', 'smartNotifications']);
const RANK = { free: 0, plus: 1, pro: 2, family: 3 };

export const PLAN_NAMES = { free: 'Bivvo Grátis', plus: 'Bivvo Plus', pro: 'Bivvo Pro', family: 'Bivvo Família' };

/* ---------- estado do plano (vem do servidor; falha = Grátis, nunca trava o app) ---------- */
let current = { plan: 'free', source: 'default', expiresAt: null, usage: {} };
let loading = null;
const listeners = new Set();
export const onPlanChange = fn => { listeners.add(fn); return () => listeners.delete(fn); };

export async function refreshPlan({ timeout = 4000 } = {}) {
  if (loading) return loading;
  loading = (async () => {
    const u = cloud.currentUser();
    if (!u) { setPaidAccess('free');current = { plan: 'free', source: 'default', expiresAt: null, usage: {} }; return current; }
    try {
      const c = await cloud.sb();
      const ym = new Date().toISOString().slice(0, 7);
      const q = Promise.all([
        c.from('entitlements').select('plan,source,expires_at').eq('user_id', u.id).gt('expires_at', new Date().toISOString()).order('expires_at', { ascending: false }),
        c.from('usage_counters').select('feature,used').eq('user_id', u.id).eq('period', ym)
      ]);
      const [ent, use] = await Promise.race([q, new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), timeout))]);
      const best = (ent.data || []).sort((a, b) => (RANK[b.plan] || 0) - (RANK[a.plan] || 0))[0];
      current = { plan: best?.plan && RANK[best.plan] != null ? best.plan : 'free', source: best?.source || 'default', expiresAt: best?.expires_at || null, usage: Object.fromEntries((use.data || []).map(r => [r.feature, r.used])) };
    } catch { /* tabelas ainda não criadas, sem rede ou lento: segue no Grátis */ }
    setPaidAccess(current.plan);
    listeners.forEach(fn => { try { fn(current); } catch { /* ignore */ } });
    return current;
  })().finally(() => { loading = null; });
  return loading;
}
export const getUserPlan = () => current.plan;
export const getPlanInfo = () => ({ ...current, name: PLAN_NAMES[current.plan] });
export const getPlanLimits = (plan = current.plan) => PLAN_LIMITS[plan] || PLAN_LIMITS.free;

export function canUseFeature(feature, plan = current.plan) {
  const min = FEATURE_MIN_PLAN[feature];
  if (!min) return true;
  if (!BILLING_LIVE && LEGACY_FREE_UNTIL_BILLING.has(feature)) return true;
  return (RANK[plan] || 0) >= RANK[min];
}
/* Quanto ainda resta no mês para um recurso com cota ('scan' | 'ai'). */
export function getRemainingUsage(feature) {
  const key = feature === 'scan' ? 'scansPerMonth' : 'aiPerMonth';
  const limit = getPlanLimits()[key];
  const used = Number(current.usage[feature] || 0);
  return { limit, used, remaining: limit === Infinity ? Infinity : Math.max(0, limit - used) };
}
/* O servidor devolve o uso atualizado depois de cada leitura. */
export function setUsage(feature, used) { current.usage = { ...current.usage, [feature]: used }; listeners.forEach(fn => fn(current)); }
/* Limite de cartões: só para criar novos; nunca esconde cartões que já existem. */
export function canAddCard(count) { if (!BILLING_LIVE) return true; return count < getPlanLimits().cards; }
