/* Bivvo 10.7 — Espaço Família */
import { h, money } from '../util.js';
import * as store from '../store.js';
import * as family from '../family.js';
import { toast, openSheet, askSheet, confirmSheet, sectionTitle } from '../ui.js';
import { getPlanInfo } from '../plans.js';
import { openProScreen } from './pro.js';
import { ctx } from '../nav.js';

let cache = undefined, loading = false;
const roleName = r => ({owner:'Responsável',editor:'Pode editar',viewer:'Somente leitura'}[r]||r);
export function renderFamily(root){
  root.append(h('section.family-head', h('div', h('span.eyebrow','Bivvo Família'), h('h2','Dinheiro em conjunto, privacidade por padrão.'), h('p.muted','Compartilhe só o que fizer sentido. Seus lançamentos pessoais continuam privados até você escolher compartilhar.'))));
  if(ctx.demo){ root.append(h('section.card.empty',h('b','Espaço Família não funciona na demonstração.'),h('p','Entre em uma conta para criar ou aceitar um convite.'))); return; }
  if(cache===undefined){ root.append(h('section.card',h('p.muted','Carregando seu espaço…'))); load(root); return; }
  if(cache?.error){ root.append(h('section.card.empty',h('b','Não foi possível abrir o Espaço Família.'),h('p',cache.error),h('button.btn',{onclick:()=>{cache=undefined;renderFamily(root)}},'Tentar novamente'))); return; }
  if(!cache){ renderEmpty(root); return; }
  if(ctx.params?.family && !sessionStorage.getItem('bivvo_family_accept_'+ctx.params.family)){ sessionStorage.setItem('bivvo_family_accept_'+ctx.params.family,'1'); family.acceptInvite(ctx.params.family).then(r=>{cache=r.data;location.hash='#/familia'}).catch(e=>toast(e.message,{tone:'warn'})); }
  renderSpace(root,cache);
}
async function load(root){ if(loading)return; loading=true; try{ cache=(await family.getFamily()).data||null; }catch(e){cache={error:e.message}} finally{loading=false; root.replaceChildren(); renderFamily(root);} }
function renderEmpty(root){
 const plan=getPlanInfo();
 root.append(h('section.card.family-start', sectionTitle('Começar'), h('p.muted', plan.plan==='family'?'Crie seu espaço ou entre com um código de convite.':'Criar um espaço exige o plano Bivvo Família. Você ainda pode aceitar um convite de outra família.'),
  h('div.btn-row', plan.plan==='family'?h('button.btn.primary',{onclick:createSpace},'Criar meu espaço'):h('button.btn.primary',{onclick:()=>openProScreen({source:'family'})},'Conhecer plano Família'), h('button.btn',{onclick:acceptInvite},'Tenho um convite'))));
}
async function createSpace(){ const name=await askSheet({title:'Nome do espaço',label:'Ex.: Família Carmo',confirmLabel:'Criar'}); if(!name)return; try{cache=(await family.createFamily(name)).data; toast('Espaço Família criado'); reroute();}catch(e){toast(e.message,{tone:'warn'})} }
async function acceptInvite(){ const raw=await askSheet({title:'Entrar no Espaço Família',message:'Cole o código recebido do responsável.',label:'Código do convite',confirmLabel:'Entrar'}); if(!raw)return; const code=String(raw).trim().replace(/^.*[?&#]family=/,'').split(/[&#]/)[0]; try{cache=(await family.acceptInvite(code)).data;toast('Você entrou no Espaço Família');reroute();}catch(e){toast(e.message,{tone:'warn'})} }
function reroute(){ location.hash='#/familia'; }
function renderSpace(root,d){
 const me=d.membership, canManage=me.role==='owner', canEdit=(canManage||me.role==='editor')&&d.active;
 const income=d.shared.filter(x=>x.type==='income').reduce((a,x)=>a+Number(x.value||0),0), expense=d.shared.filter(x=>x.type==='expense').reduce((a,x)=>a+Number(x.value||0),0);
 if(!d.active) root.append(h('section.card.notice',h('b','Plano Família inativo'),h('p.muted.sm','O responsável precisa reativar o Bivvo Família para voltar a compartilhar ou administrar este espaço. Os dados existentes permanecem preservados.')));
 root.append(h('section.card.family-summary',h('div',h('small','Espaço'),h('h3',d.family.name),h('p.muted.sm',`${d.members.length} de 4 membros · você: ${roleName(me.role)}`)), h('div.stats',h('div.stat',h('small','Entradas compartilhadas'),h('b',money(income))),h('div.stat',h('small','Gastos compartilhados'),h('b',money(expense))),h('div.stat',h('small','Saldo compartilhado'),h('b',money(income-expense))))));
 const members=h('div.family-members',d.members.map(m=>memberRow(m,d,canManage)));
 root.append(h('section.card',sectionTitle('Membros'),members,canManage&&d.members.length<4?h('button.btn.primary.block',{onclick:invite},'Convidar membro'):null));
 if(canEdit) root.append(h('section.card',sectionTitle('Privado x compartilhado'),h('p.muted.sm','Nada do seu extrato pessoal entra aqui automaticamente. Escolha abaixo o que a família pode ver.'),h('button.btn.block',{onclick:()=>openSharePicker(d)},'Escolher lançamentos para compartilhar')));
 else root.append(h('section.card',sectionTitle('Seu acesso'),h('p.muted.sm','Você pode acompanhar o que foi compartilhado, mas não pode adicionar ou alterar informações familiares.')));
 root.append(h('section.card',sectionTitle('Movimentações compartilhadas'), d.shared.length?h('div.family-tx-list',d.shared.map(x=>sharedRow(x,d,canEdit))):h('div.empty',h('b','Nada compartilhado ainda.'),h('p','Os dados pessoais continuam privados.'))));
 if(me.role!=='owner') root.append(h('section.card',h('button.btn.ghost.danger-text',{onclick:leave},'Sair deste Espaço Família')));
}
function memberRow(m,d,canManage){ const mine=m.id===d.membership.id; const actions=[]; if(canManage&&m.role!=='owner'){ actions.push(h('button.link.sm',{onclick:()=>changeRole(m)},roleName(m.role))); actions.push(h('button.link.sm.danger-text',{onclick:()=>remove(m)},'Remover')); } return h('div.family-member',h('span.avatar',String(m.display_name||'?').charAt(0).toUpperCase()),h('span',h('b',m.display_name||'Membro'),h('small',mine?'Você · '+roleName(m.role):roleName(m.role))),h('span.family-member-actions',actions)); }
async function invite(){ try{const role=await chooseRole(); if(!role)return; const r=await family.createInvite(role); const link=`${location.origin}${location.pathname}#/familia?family=${r.code}`; const box=h('textarea.input',{readOnly:true,rows:3},link); openSheet({title:'Convite criado',subtitle:'Válido por 7 dias. Envie este link para a pessoa.',content:[box,h('button.btn.primary.block',{onclick:async()=>{try{await navigator.clipboard.writeText(link);toast('Link copiado')}catch{box.select();document.execCommand('copy');toast('Link copiado')}}},'Copiar convite')]}); }catch(e){toast(e.message,{tone:'warn'})} }
function chooseRole(){ return new Promise(resolve=>{ const sh=openSheet({title:'Permissão do novo membro',content:h('div.family-role-choices',h('button.menu-item',{onclick:()=>{sh.close();resolve('editor')}},h('span.mi-ico','✎'),h('span',h('b','Pode editar'),h('small','Pode compartilhar e remover os próprios lançamentos compartilhados.'))),h('button.menu-item',{onclick:()=>{sh.close();resolve('viewer')}},h('span.mi-ico','◉'),h('span',h('b','Somente leitura'),h('small','Acompanha o espaço sem alterar dados.'))))}); }); }
async function changeRole(m){ const role=await chooseRole(); if(!role)return; try{await family.setRole(m.id,role);cache=(await family.getFamily()).data;reroute();}catch(e){toast(e.message,{tone:'warn'})} }
async function remove(m){if(!await confirmSheet({title:`Remover ${m.display_name||'membro'}?`,message:'A pessoa perderá acesso ao espaço e os lançamentos que ela compartilhou serão removidos.',confirmLabel:'Remover',danger:true}))return;try{await family.removeMember(m.id);cache=(await family.getFamily()).data;reroute()}catch(e){toast(e.message,{tone:'warn'})}}
async function leave(){if(!await confirmSheet({title:'Sair do Espaço Família?',message:'Você perderá acesso aos dados compartilhados. Seus dados pessoais não serão apagados.',confirmLabel:'Sair',danger:true}))return;try{await family.leaveFamily();cache=null;reroute()}catch(e){toast(e.message,{tone:'warn'})}}
function openSharePicker(d){ const mine=new Set(d.shared.filter(x=>x.user_id===d.membership.user_id).map(x=>x.source_id)); const tx=store.getState().transactions.slice().sort((a,b)=>b.date.localeCompare(a.date)).slice(0,80); const list=h('div.family-picker',tx.map(t=>{const on=mine.has(t.id); return h('button.menu-item',{onclick:async e=>{const btn=e.currentTarget;btn.disabled=true;try{if(on)await family.unshareTransaction(t.id);else await family.shareTransaction(t);cache=(await family.getFamily()).data;toast(on?'Voltou a ser privado':'Compartilhado com a família');document.querySelector('.sheet-wrap')?.remove();reroute()}catch(err){toast(err.message,{tone:'warn'});btn.disabled=false}}},h('span.mi-ico',on?'✓':'○'),h('span',h('b',t.desc),h('small',`${t.date.split('-').reverse().join('/')} · ${t.cat}`)),h('b',money(t.value)))})); openSheet({title:'O que compartilhar',subtitle:'Toque para alternar. Só uma cópia resumida é compartilhada; o lançamento original continua no seu extrato pessoal.',content:list}); }
function sharedRow(x,d,canEdit){ const mine=x.user_id===d.membership.user_id; return h('div.family-shared-row',h('span',h('b',x.description),h('small',`${x.date.split('-').reverse().join('/')} · ${x.category}${mine?' · você':''}`)),h('b',`${x.type==='income'?'+':'−'} ${money(x.value)}`),mine&&canEdit?h('button.icon-btn',{title:'Tornar privado',onclick:async()=>{try{await family.unshareTransaction(x.source_id);cache=(await family.getFamily()).data;reroute()}catch(e){toast(e.message,{tone:'warn'})}}},'×'):null); }
