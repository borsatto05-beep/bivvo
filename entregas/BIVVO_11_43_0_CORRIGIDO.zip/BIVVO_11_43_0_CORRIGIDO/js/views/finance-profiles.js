import {h} from '../util.js';
import * as store from '../store.js';
import {canUseFeature} from '../plans.js';
import {openPaywall} from './pro.js';
import {closeAllSheets} from '../ui.js';
import {go,ctx} from '../nav.js';
export function financeProfileBar(){
 const active=ctx.route==='familia'&&ctx.params.couple==='1'?'couple':store.activeFinanceProfile();
 const pick=key=>{closeAllSheets();if(key==='company'&&!store.isDemo()&&!canUseFeature(key)){openPaywall({feature:key});return;}if(key==='couple'){store.switchFinanceProfile('personal');go('familia',{couple:'1'});}else{store.switchFinanceProfile(key);go('inicio');}};
 return h('div.finance-profile-bar',{'role':'group','aria-label':'Perfil financeiro'},[['personal','👤','Pessoal'],['couple','💑','Casal'],['company','🏢','Empresa']].map(([key,icon,label])=>h('button.finance-profile'+(active===key?'.on':''),{type:'button','aria-pressed':active===key,onclick:()=>pick(key)},h('span',{'aria-hidden':'true'},icon),label)),h('small',active==='company'?'Finanças da empresa':active==='couple'?'Espaço compartilhado do casal':'Finanças pessoais'));
}
