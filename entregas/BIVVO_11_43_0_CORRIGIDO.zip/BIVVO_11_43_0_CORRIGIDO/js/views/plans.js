/* Bivvo — Planos: orçamento, metas, desafios, contas fixas e investimentos. */
import { h, money, money0, today, ymOf, monthName, monthLabel, diffDays, addMonthsYM, parseMoney, round2, shortDate, num } from '../util.js';
import * as store from '../store.js';
import * as F from '../finance.js';
import { CHALLENGES, challengeDef, challengeProgress, startChallenge } from '../insights.js';
import { emptyState, sectionTitle, progress, segmented, openSheet, toast, catIcon, field, confirmSheet } from '../ui.js';
import { stat } from './components.js';
import { openBudgetForm, openGoalForm, openGoalMove, openFixedForm, openInvestmentForm, refreshQuotes, moneyInput } from './forms.js';
import { monthSwitcher } from './extrato.js';
import { ctx, rerender,go } from '../nav.js';
import { openStoryComposer } from './stories.js';
import { donut } from '../charts.js';
import {renderCalendar} from './calendar.js';

let tab = 'agenda';
const TABS=[{value:'agenda',label:'Agenda de contas'},{value:'fixas',label:'Contas recorrentes'},{value:'orcamento',label:'Orçamento'},{value:'metas',label:'Metas e investimentos'},{value:'desafios',label:'Desafios'}];
export function renderPlans(root){
  const requested=ctx.params.tab,alias={assinaturas:'fixas',investimentos:'metas'};
  if(requested){const selected=alias[requested]||requested;if(TABS.some(t=>t.value===selected))tab=selected;ctx.params.tab=null;}
  const body=h('div.plans-body');
  const paint=()=>{body.replaceChildren();({agenda:renderCalendar,orcamento:budget,metas:savings,desafios:challenges,fixas:recurring})[tab](body);};
  const bar=segmented(TABS,tab,value=>{tab=value;paint();bar.querySelector('[aria-selected="true"]')?.scrollIntoView({block:'nearest',inline:'nearest'});},'planning-tabs');
  bar.setAttribute('aria-label','Seções do planejamento');
  root.append(bar,h('p.planning-bar-hint','Deslize a barra para ver todas as opções.'),body);paint();
}

let recurringFilter='all';
function recurring(root){
  const s=store.getState(), isSub=f=>f.type!=='income'&&['Assinaturas','Streaming'].includes(f.cat);
  const expenses=s.fixed.filter(f=>f.type!=='income'), legacy=(s.subscriptions||[]).filter(x=>x&&x.active!==false);
  const monthly=x=>x.rec==='Anual'?num(x.value)/12:num(x.value);
  const total=round2(expenses.reduce((v,x)=>v+monthly(x),0)+legacy.reduce((v,x)=>v+monthly(x),0));
  root.append(h('div.page-head',h('div',h('h2.h2','Contas recorrentes'),h('p.muted','Todas as suas contas que se repetem.')),h('button.btn.sm.primary',{type:'button',onclick:()=>openFixedForm()},'Nova conta')),
    h('div.stats.card.flat',stat('Contas por mês',money0(total)),stat('Assinaturas por mês',money0(expenses.filter(isSub).reduce((v,x)=>v+monthly(x),0)+legacy.reduce((v,x)=>v+monthly(x),0)))));
  const list=h('div.recurring-list');
  const paint=()=>{list.replaceChildren();const records=s.fixed.filter(f=>recurringFilter==='all'||(recurringFilter==='subscriptions'?isSub(f):!isSub(f)));
    const row=f=>h('button.tx',{type:'button',onclick:()=>openFixedForm(f)},h('span.tx-ico',{'aria-hidden':'true'},catIcon(f.cat)),h('span.tx-main',h('b',f.name),h('small',`${f.due?'Dia '+f.due:'Sem dia definido'} · ${f.rec==='Anual'?'Anual':'Mensal'} · ${isSub(f)?'Assinatura':f.type==='income'?'Receita':'Conta fixa'}`)),h('span.tx-side',h('b.tx-val'+(f.type==='income'?'.in':''),(f.type==='income'?'+ ':'')+money(f.value))));
    const inc=records.filter(f=>f.type==='income'),exp=records.filter(f=>f.type!=='income').sort((a,b)=>num(a.due)-num(b.due));
    if(exp.length)list.append(h('section.card',sectionTitle('Contas'),h('div.list',exp.map(row))));
    if(recurringFilter!=='fixed'&&legacy.length)list.append(h('section.card',sectionTitle('Outras assinaturas'),h('div.list',legacy.map(x=>h('div.tx',h('span.tx-ico',{'aria-hidden':'true'},'↻'),h('span.tx-main',h('b',x.name||'Assinatura'),h('small',x.rec==='Anual'?'Cobrança anual':'Cobrança mensal')),h('span.tx-side',h('b.tx-val',money(x.value))))))));
    if(inc.length)list.append(h('section.card',sectionTitle('Receitas recorrentes'),h('div.list',inc.map(row))));
    if(!list.childElementCount)list.append(h('div.empty',h('b','Nenhuma conta neste filtro.'),h('p','Cadastre uma conta ou escolha outro filtro.')));
  };
  root.append(segmented([{value:'all',label:'Todas'},{value:'fixed',label:'Contas fixas'},{value:'subscriptions',label:'Assinaturas'}],recurringFilter,v=>{recurringFilter=v;paint();}),list);paint();
}
let savingsView='goals';
function savings(root){
  const s=store.getState(),w=F.wealth(s);
  root.append(h('div.page-head',h('div',h('h2.h2','Metas e investimentos'),h('p.muted','Veja seus objetivos e seu dinheiro acumulado.'))),h('div.stats.card.flat',stat('Total acumulado',money0(w.total)),stat('Guardado em metas',money0(w.goals)),stat('Investido',money0(w.investments))));
  const content=h('div.savings-detail');
  const paint=()=>{content.replaceChildren();const host=h('div.'+(savingsView==='goals'?'savings-goals':'savings-investments'));(savingsView==='goals'?goals:investments)(host);content.append(host);};
  const toggle=segmented([{value:'goals',label:'Metas'},{value:'investments',label:'Investimentos'}],savingsView,v=>{savingsView=v;paint();});toggle.setAttribute('aria-label','Visualização de metas e investimentos');
  root.append(toggle,content);paint();
}

/* ---------------- orçamento ---------------- */
function budget(root) {
  const s = store.getState(), ym = ctx.month, sm = F.monthSummary(ym, s);
  const rows = F.budgetRows(ym, s);
  const target = round2(sm.income * s.savingPlan.percent / 100);
  const pctInput = h('input.input.sm.pct-input', { type: 'number', inputmode: 'decimal', min: 0, max: 100, step: 1, value: s.savingPlan.percent, 'aria-label': 'Percentual da renda para guardar' });
  pctInput.addEventListener('change', () => { const v = Math.min(100, Math.max(0, num(pctInput.value))); store.commit(st => { st.savingPlan.percent = v; }); toast(`Meta de guardar: ${v}% da renda`); });
  root.append(h('div.page-head', monthSwitcher(rerender)));
  root.append(h('section.card.save-plan',
    h('div.card-head', h('h3', 'Meta de guardar'), h('label.inline', pctInput, h('span', '% da renda'))),
    h('div.stats', stat('Meta do mês', money0(target)), stat('Guardado', money0(sm.saved), null, sm.saved >= target && target > 0 ? 'in' : ''), stat('Falta', money0(Math.max(0, target - sm.saved)))),
    progress(sm.saved, target, 'good'),
    h('p.hint', 'Conta como guardado: dinheiro movido para metas, reserva e investimentos.')));

  if (!rows.length) {
    const sug = F.suggestBudgets(s);
    root.append(emptyState({ icon: '🎯', title: 'Defina limites para o que mais pesa', text: sug.length ? `Pela sua média, ${sug[0].cat} gira em torno de ${money0(sug[0].value)} por mês. O Bivvo pode sugerir limites para você ajustar.` : 'Escolha algumas categorias e um teto mensal para cada uma. O Bivvo avisa quando chegar perto.', action: { label: 'Definir limites', fn: openBudgetForm } }));
    return;
  }
  const totalLimit = rows.reduce((a, r) => a + r.limit, 0), totalSpent = rows.reduce((a, r) => a + Math.min(r.spent, r.limit * 10), 0);
  const [y, m] = ym.split('-').map(Number), dim = new Date(y, m, 0).getDate();
  const day = ym === ymOf(today()) ? Number(today().slice(8)) : ym < ymOf(today()) ? dim : 0;
  root.append(h('section.card',
    h('div.card-head', h('h3', 'Limites de ' + monthName(ym)), h('button.link.sm', { type: 'button', onclick: openBudgetForm }, 'Editar')),
    h('p.muted.sm', `${money0(totalSpent)} de ${money0(totalLimit)} usados · ${Math.round(day / dim * 100)}% do mês passou`),
    h('div.budget-list', rows.map(r => {
      const tone = r.ratio >= 1 ? 'bad' : r.ratio >= 0.8 ? 'warn' : 'good';
      const paceAhead = day > 0 && day < dim && r.ratio > day / dim + 0.15;
      return h('div.brow',
        h('div.brow-top', h('span', h('i', { 'aria-hidden': 'true' }, catIcon(r.cat)), r.cat), h('b', `${money0(r.spent)} / ${money0(r.limit)}`)),
        progress(r.spent, r.limit, tone),
        h('small.muted', r.left >= 0 ? `${money0(r.left)} disponível${paceAhead ? ' · ritmo acima do mês' : ''}` : `${money0(-r.left)} acima do limite`));
    }))));
}

/* ---------------- metas ---------------- */
function goals(root) {
  const s = store.getState();
  root.append(h('div.page-head', h('h2.h2', 'Seus objetivos'), h('button.btn.sm.primary', { type: 'button', onclick: () => openGoalForm() }, 'Nova meta')));
  if (!s.goals.length) {
    root.append(emptyState({ icon: '🛡️', title: 'Comece pela reserva de emergência', text: 'É o dinheiro que segura imprevistos. A referência comum é de 3 a 6 meses dos seus gastos.', action: { label: 'Criar reserva', fn: () => openGoalForm(null, { name: 'Reserva de emergência', emoji: '🛡️', isReserve: true, target: Math.round(F.avgMonthlySpend(3, s) * 3 / 100) * 100 || null }) } }));
    return;
  }
  const avg = F.avgMonthlySpend(3, s);
  const list = s.goals.slice().sort((a, b) => (b.isReserve ? 1 : 0) - (a.isReserve ? 1 : 0));
  root.append(h('div.goals', list.map(g => {
    const linked=s.investments.filter(x=>x.goalId===g.id),invested=linked.reduce((v,x)=>v+F.investmentValue(x,s),0), accumulated=round2(g.saved+invested);
    const ratio = g.target ? accumulated / g.target : 0, done = ratio >= 1;
    let plan = null;
    if (!done && g.date) { const months = Math.max(1, Math.ceil(diffDays(today(), g.date) / 30.4)); plan = `Guardando ${money0((g.target - accumulated) / months)} por mês você chega lá até ${shortDate(g.date)}.`; }
    if (g.isReserve && avg > 0) plan = `Cobre ${(g.saved / avg).toFixed(1).replace('.', ',')} ${g.saved / avg >= 1.95 ? 'meses' : 'mês'} dos seus gastos.` + (plan ? ' ' + plan : '');
    return h('section.card.goal' + (done ? '.done' : ''),
      h('div.goal-top', h('span.goal-ico', { 'aria-hidden': 'true' }, g.emoji || (g.isReserve ? '🛡️' : '🫙')), h('div', h('h3', g.name), h('small.muted', g.isReserve ? 'Reserva de emergência' : g.date ? `Prazo ${shortDate(g.date)}` : 'Sem prazo')), h('button.link.sm', { type: 'button', onclick: () => openGoalForm(g) }, 'Editar')),
      h('div.goal-num', h('strong', money0(accumulated)), h('span.muted', ` de ${money0(g.target)}`), h('b.goal-pct', Math.round(ratio * 100) + '%')),
      progress(accumulated, g.target, 'good'),
      h('p.muted.sm',`${money0(g.saved)} guardados + ${money0(invested)} investidos`),
      h('p.muted.sm',done?'Meta alcançada!':`Faltam ${money0(Math.max(0,g.target-accumulated))} para sua meta.`),
      plan ? h('p.muted.sm', plan) : null,
      !done && g.target > accumulated ? h('p.hint', 'Cenários: ' + [100, 250, 500].map(v => { const m = Math.ceil((g.target - accumulated) / v); return `${money0(v)}/mês ≈ ${m} ${m === 1 ? 'mês' : 'meses'}`; }).join(' · ')) : null,
      h('div.btn-row', h('button.btn.sm.primary', { type: 'button', onclick: () => openGoalMove(g.id, 'in') }, 'Guardar'), g.saved > 0 ? h('button.btn.sm', { type: 'button', onclick: () => openGoalMove(g.id, 'out') }, 'Retirar') : null,
        ratio >= 0.25 ? h('button.btn.sm.ghost', { type: 'button', onclick: () => openStoryComposer({ template: 'goal', goalId: g.id }) }, 'Compartilhar progresso') : null));
  })));
}

/* ---------------- desafios ---------------- */
function challenges(root) {
  const s = store.getState();
  const active = s.challenges.filter(c => c.status === 'active');
  const doneList = s.challenges.filter(c => c.status === 'done').slice(-6).reverse();
  root.append(h('p.lede', 'Desafios curtos, medidos com os seus próprios lançamentos. Sem pontos falsos: só o que aconteceu de verdade.'));
  if (active.length) root.append(h('section.card', sectionTitle('Em andamento'), h('div.ch-list', active.map(ch => {
    const p = challengeProgress(ch, s), def = challengeDef(ch.type);
    return h('div.ch',
      h('div.ch-top', h('span.ch-ico', { 'aria-hidden': 'true' }, def.icon), h('div', h('b', def.title + (ch.cat ? ` · ${ch.cat}` : '')), h('small.muted', `${p.label} · termina ${shortDate(ch.endsAt)}`)),
        h('button.link.sm', { type: 'button', onclick: async () => { if (await confirmSheet({ title: 'Desistir do desafio?', message: 'Você pode começar outro quando quiser.', confirmLabel: 'Desistir' })) store.commit(st => { const x = st.challenges.find(c => c.id === ch.id); if (x) x.status = 'quit'; }); } }, 'Desistir')),
      progress(p.ratio, 1, p.invert ? (p.failed ? 'bad' : 'good') : 'good'),
      p.failed && !p.ended ? h('small.warn-text', 'Esse desafio não vai fechar desta vez. Tudo bem: tente de novo quando quiser.') : null);
  }))));
  const busy = new Set(active.map(c => c.type));
  root.append(h('section.card', sectionTitle('Começar um desafio'), h('div.ch-catalog', CHALLENGES.map(def => h('button.ch-pick', { type: 'button', disabled: busy.has(def.type), onclick: () => pickChallenge(def) },
    h('span.ch-ico', { 'aria-hidden': 'true' }, def.icon), h('span', h('b', def.title), h('small', busy.has(def.type) ? 'Em andamento' : def.text)))))));
  if (doneList.length) root.append(h('section.card', sectionTitle('Concluídos'), h('div.list', doneList.map(ch => { const def = challengeDef(ch.type); return h('div.ch-done', h('span', { 'aria-hidden': 'true' }, '🏆'), h('span', h('b', def?.title + (ch.cat ? ` · ${ch.cat}` : '')), h('small.muted', `Concluído em ${shortDate(ch.completedAt || ch.endsAt)}`)), h('button.btn.sm', { type: 'button', onclick: () => openStoryComposer({ template: 'challenge', challengeId: ch.id }) }, 'Compartilhar')); }))));
}
function pickChallenge(def) {
  const s = store.getState();
  const content = [h('p.sheet-text', def.text)];
  let value = null, cat = null, days = def.days;
  if (def.needsValue) { value = moneyInput(def.defaultValue, { label: 'Valor' }); content.push(field('Quanto', value)); }
  if (def.needsCat) {
    const sm = F.monthSummary(addMonthsYM(ymOf(today()), -1), s);
    const opts = (sm.cats.length ? sm.cats.map(c => c.cat) : store.categories('expense')).filter(c => !['Moradia', 'Investimentos'].includes(c));
    cat = h('select.input', opts.map(c => h('option', { value: c }, c)));
    if (opts.includes('Delivery')) cat.value = 'Delivery';
    content.push(field('Categoria', cat));
  }
  if (def.choosableDays) { const sel = h('select.input', def.choosableDays.map(d => h('option', { value: d }, `${d} dias`))); sel.value = String(def.days); sel.addEventListener('change', () => { days = Number(sel.value); }); content.push(field('Duração', sel)); }
  const sheet = openSheet({ title: def.title, content, footer: [h('button.btn.primary', { type: 'button', onclick: () => {
    store.commit(st => startChallenge(st, { type: def.type, value: value?.getValue(), cat: cat?.value, days }));
    sheet.close(); toast('Desafio começou hoje. Boa!');
  } }, 'Começar hoje')] });
}

/* ---------------- investimentos ---------------- */
function investments(root) {
  const s = store.getState(), w = F.wealth(s);
  root.append(h('div.page-head', h('h2.h2', 'Seus investimentos'), h('button.btn.sm.primary', { type: 'button', onclick: () => openInvestmentForm() }, 'Nova aplicação')));
  root.append(h('p.muted.sm',`Resultado dos investimentos: ${(w.result>=0?'+':'')+money0(w.result)}`));
  if (!s.investments.length) { root.append(emptyState({ icon: '💎', title: 'Nenhuma aplicação registrada', text: 'Registre CDBs, Tesouro, ações e fundos para acompanhar o patrimônio junto com o resto das suas finanças.', action: { label: 'Registrar aplicação', fn: () => openInvestmentForm() } })); return; }
  // Carteira por ativo: cada ticker/aplicação recebe sua própria fatia. Ativos com o mesmo nome são somados.
  const byAsset = new Map();
  for (const x of s.investments) {
    const key = String(x.name || x.type || 'Investimento').trim().toUpperCase();
    const value = F.investmentValue(x, s);
    const row = byAsset.get(key) || { label: key, value: 0, items: [] };
    row.value += value; row.items.push(x); byAsset.set(key, row);
  }
  const assets = [...byAsset.values()].filter(x => x.value > 0).sort((a, b) => b.value - a.value);
  const assetTotal = assets.reduce((a, b) => a + b.value, 0) || 1;
  const showAsset = picked => {
    const group = picked.items || [];
    const cost = group.reduce((a, x) => a + num(x.costBasis ?? x.value), 0);
    const current = group.reduce((a, x) => a + F.investmentValue(x, s), 0);
    const result = current - cost;
    const qtyTotal = group.reduce((a, x) => a + num(x.quantity), 0);
    const first = group[0] || {};
    const share = current / assetTotal * 100;
    const details = h('div.asset-pop',
      h('div.asset-pop-hero', h('strong', picked.label), h('span', `${share.toFixed(1).replace('.', ',')}% da carteira`)),
      h('div.stats.card.flat', stat('Valor atual', money0(current)), stat('Aplicado', money0(cost)), stat('Resultado', (result >= 0 ? '+' : '') + money0(result), null, result >= 0 ? 'in' : 'neg')),
      h('div.asset-detail-list',
        h('div', h('span', 'Tipo'), h('b', first.type || 'Investimento')),
        qtyTotal > 0 ? h('div', h('span', 'Quantidade'), h('b', String(round2(qtyTotal)).replace('.', ','))) : null,
        first.marketPrice ? h('div', h('span', 'Última cotação'), h('b', money(first.marketPrice))) : null,
        first.purchasePrice ? h('div', h('span', 'Preço médio registrado'), h('b', money(first.purchasePrice))) : null,
        first.yieldRate ? h('div', h('span', 'Rendimento'), h('b', `${String(first.yieldRate).replace('.', ',')}%${first.yieldType === 'Pós-fixado' ? ' do ' + (first.yieldIndex || 'CDI') : ' a.a.'}`)) : null,
        first.purchaseDate ? h('div', h('span', 'Primeira aplicação'), h('b', shortDate(first.purchaseDate))) : null
      ),
      h('p.hint', group.length > 1 ? `${group.length} registros de ${picked.label} foram somados nesta fatia.` : 'Toque em editar para alterar os dados deste investimento.')
    );
    const footer = group.length === 1 ? [h('button.btn.primary', { type: 'button', onclick: () => { sheet.close(); openInvestmentForm(group[0]); } }, 'Editar investimento')] : null;
    const sheet = openSheet({ title: 'Detalhes do ativo', subtitle: picked.label, content: details, footer });
  };
  root.append(h('section.card.asset-allocation-card',
    h('div.card-head', h('div', h('h3', 'Carteira por ativo'), h('p.hint', 'Cada fatia representa um ativo. Toque no gráfico ou na legenda para ver os detalhes.'))),
    donut(assets, { center: 'Carteira', onPick: showAsset }),
    h('div.asset-pie-legend', assets.map((x, i) => h('button', { type: 'button', onclick: () => showAsset(x), 'aria-label': `Abrir detalhes de ${x.label}` }, h('i', { class: `v${i % 6}` }), h('span', x.label), h('b', `${(x.value / assetTotal * 100).toFixed(1).replace('.', ',')}%`), h('small', money0(x.value)))))
  ));
  const cdi = h('input.input.sm.pct-input', { type: 'text', inputmode: 'decimal', value: String(s.cdiReference).replace('.', ','), 'aria-label': 'CDI de referência ao ano' });
  cdi.addEventListener('change', () => { const v = parseMoney(cdi.value); if (v > 0 && v < 50) { store.commit(st => { st.cdiReference = v; }); toast('CDI de referência atualizado'); } });
  root.append(h('section.card', h('div.card-head', h('h3', 'Carteira'), h('button.link.sm', { type: 'button', onclick: refreshQuotes }, 'Atualizar cotações')),
    h('div.list', s.investments.map(x => {
      const v = F.investmentValue(x, s), cost = num(x.costBasis ?? x.value), r = v - cost;
      return h('button.tx', { type: 'button', onclick: () => openInvestmentForm(x) }, h('span.tx-ico', { 'aria-hidden': 'true' }, '💎'),
        h('span.tx-main', h('b', x.name), h('small', [x.type, x.goalId&&s.goals.find(g=>g.id===x.goalId)?'Meta: '+s.goals.find(g=>g.id===x.goalId).name:'Sem meta definida', x.quantity ? `${x.quantity} cotas` : null, x.yieldRate ? `${String(x.yieldRate).replace('.', ',')}%${x.yieldType === 'Pós-fixado' ? ' do ' + (x.yieldIndex || 'CDI') : ' a.a.'}` : null].filter(Boolean).join(' · '))),
        h('span.tx-side', h('b.tx-val', money(v)), h('small.' + (r >= 0 ? 'up' : 'down'), (r >= 0 ? '+' : '') + money(r))));
    })),
    h('label.inline.hint', 'CDI de referência para estimar CDBs pós-fixados:', cdi, h('span', '% a.a.')),
    h('p.hint', 'Valores de renda fixa são estimativas antes de impostos. Ações e fundos usam a última cotação obtida.')));
}
