/* Dados encontrados ficam preservados; só campos ausentes pedem preenchimento. */
import { h, money, today } from '../util.js';
import * as store from '../store.js';
import { openSheet, field } from '../ui.js';
import { moneyInput } from './forms.js';
import { saveParsed, openSmartCapture } from '../quickcapture.js';

export function openScanConfirm(d = {}, { previewUrl = null, onClose = null } = {}) {
  const state = store.getState();
  const merchant = typeof d.merchant === 'string' ? d.merchant.trim() : '';
  const validDate = typeof d.date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(d.date) && Number.isFinite(Date.parse(d.date)) && new Date(d.date).toISOString().slice(0,10)===d.date && d.date<=today();
  const amount = typeof d.value === 'number' && Number.isFinite(d.value) && d.value>0 ? d.value : null;
  const desc = h('input.input', {type:'text',maxLength:100,value:merchant,'aria-label':'Nome do local'});
  const date = h('input.input', {type:'date',value:validDate?d.date:'',max:today(),'aria-label':'Data'});
  const value = moneyInput(amount, {big:true,label:'Valor gasto'});
  const rows = [['Nome do local',desc,!!merchant,merchant],['Data',date,validDate,validDate?d.date.split('-').reverse().join('/'):''],['Valor gasto',value,amount!=null,amount!=null?money(amount):'']];
  const missing = rows.filter(x=>!x[2]);
  const msg = h('p.form-msg', {role:'alert'});
  const content = h('div.form.scan-confirm', previewUrl?h('img.scan-preview',{src:previewUrl,alt:'Comprovante'}):null);
  for (const [label,input,found,text] of rows) {
    const editor = field(label,input); editor.hidden=found;
    if (found) {
      const summary=h('div.scan-review.good',h('b',label),h('span',text),h('button.btn.ghost',{type:'button',onclick:()=>{summary.hidden=true;editor.hidden=false;input.focus();}},'Corrigir'));
      content.append(summary);
    } else input.classList.add('scan-field-review');
    content.append(editor);
  }
  content.append(msg);
  const sheet=openSheet({title:'Confirmar gasto',subtitle:missing.length?'Preencha somente o que faltou.':'Confira os dados e confirme.',onClose,content,footer:[h('button.btn.ghost',{type:'button',onclick:()=>sheet.close()},'Cancelar'),h('button.btn.primary',{type:'button',onclick:confirm},'Confirmar')]});
  if(missing.length)setTimeout(()=>missing[0][1].focus(),120);
  function confirm(){
    if(!desc.value.trim()){msg.textContent='Informe o nome do local.';desc.focus();return;}
    if(!date.value||date.value>today()){msg.textContent='Informe a data da compra.';date.focus();return;}
    const v=value.getValue();
    if(!(v>0)){msg.textContent='Informe o valor gasto.';value.focus();return;}
    const cat=store.autoCategory(desc.value.trim(),'expense',state)||'Outros';
    sheet.close();
    saveParsed({type:'expense',desc:desc.value.trim(),date:date.value,value:v,cat,method:'Outro',parts:1,future:false},{cat,source:'scan'});
  }
}

export function openScanUnavailable(reason) {
  const text = reason === 'demo' ? 'A leitura de comprovantes usa sua conta (são 5 leituras grátis por mês). Na demonstração, digite ou fale o gasto.'
    : 'A leitura de comprovantes ainda não foi ativada neste Bivvo. Enquanto isso, digite ou fale o gasto.';
  const sheet = openSheet({ title: 'Leitura de comprovante', content: h('p.sheet-text', text),
    footer: [h('button.btn.ghost', { type: 'button', onclick: () => sheet.close() }, 'Fechar'), h('button.btn.primary', { type: 'button', onclick: () => { sheet.close(); setTimeout(() => openSmartCapture(), 150); } }, 'Digitar o gasto')] });
}
