/* Bivvo — Você: progresso, compartilhar, dados, preferências e segurança. */
import { h, money, today, ymOf, monthLabel, num, VERSION, RELEASE_DATE, uid, parseMoney, round2, monthName } from '../util.js';
import * as store from '../store.js';
import * as F from '../finance.js';
import { ACHIEVEMENTS, unlockedAchievements } from '../insights.js';
import { openSheet, toast, confirmSheet, askSheet, sectionTitle, field } from '../ui.js';
import { stat } from './components.js';
import * as cloud from '../cloud.js';
import { ctx, go, leaveDemo } from '../nav.js';
import { openRetrospective, openStoryComposer, inviteFriend, openYearWrapped, wrappedDefaultYear } from './stories.js';
import { openInstallGuide, devicePlatform, isPwaInstalled } from '../platform.js';
import { pushSupport, pushActive, enablePush, disablePush, readPrefs, savePrefs, sendTest } from '../push.js';
import { openSplitForm } from './split.js';
import { getPlanInfo, BILLING_LIVE, getRemainingUsage } from '../plans.js';
import { openProScreen } from './pro.js';
import {openHomePreferences} from './homeprefs.js';
import { openCategoryManager } from './categories.js';
import { adminTrack } from '../admin-analytics.js';

const askMfa = () => askSheet({ title: 'Código do autenticador', label: 'Código de 6 dígitos', inputmode: 'numeric', autocomplete: 'one-time-code', pattern: /^\d{6}$/, confirmLabel: 'Verificar' });

export function renderYou(root) {
  const s = store.getState(), u = cloud.currentUser();
  const item = (icon, title, sub, fn, cls = '') => h('button.menu-item' + (cls ? '.' + cls : ''), { type: 'button', onclick: async event => { try { await fn?.(event); } catch(error) { toast(error.message || 'Não foi possível concluir agora.', {tone:'warn'}); } } }, h('span.mi-ico', { 'aria-hidden': 'true' }, icon), h('span', h('b', title), sub ? h('small', sub) : null), h('span.mi-chev', { 'aria-hidden': 'true' }, '›'));
  const name = s.profile.name || (u?.email ? u.email.split('@')[0] : 'Você');
  root.append(h('section.card.me', h('span.avatar.lg', { 'aria-hidden': 'true' }, name.charAt(0).toUpperCase()), h('div', h('h2', name), h('p.muted.sm', ctx.demo ? 'Demonstração · dados fictícios' : u?.email || '')),
    h('button.link.sm', { type: 'button', onclick: editProfile }, 'Editar')));

  /* plano */
  const plan = getPlanInfo(), scan = getRemainingUsage('scan');
  root.append(h('button.card.plan-card', { type: 'button', onclick: () => openProScreen({ source: 'voce' }) },
    h('span', h('small', 'Assinatura Bivvo'), h('b', plan.name), h('small', ctx.demo ? 'Demonstração' : `Leituras de comprovante: ${scan.used} de ${scan.limit === Infinity ? '∞' : scan.limit} neste mês`)),
    h('span.plan-cta', plan.plan === 'free' ? 'Conhecer Pro' : 'Ver assinatura')));

  /* progresso */
  const ps = F.positiveStreak(s), unlocked = new Set(unlockedAchievements(s).map(a => a.id));
  root.append(h('section.card', sectionTitle('Seu progresso'),
    h('div.stats', stat('Meses no positivo', String(ps.months), ps.liveThisMonth ? 'este mês também, até agora' : null, ps.months ? 'in' : ''), stat('Check-ins seguidos', String(F.checkinStreak(s))), stat('Dias anotando', String(F.loggingStreak(s)))),
    h('div.badges', ACHIEVEMENTS.map(a => h('div.badge-a' + (unlocked.has(a.id) ? '.on' : ''), { title: a.text }, h('span', { 'aria-hidden': 'true' }, a.icon), h('b', a.title), h('small', unlocked.has(a.id) ? a.text : 'Ainda não'))))));

  root.append(h('section.card.menu', sectionTitle('Família'),
    item('⌂', 'Espaço Família', 'Até 4 pessoas · compartilhado só quando você escolher', () => go('familia'))));

  root.append(h('section.card.menu', sectionTitle('Compartilhar'),
    item('✦', 'Meu número de hoje', 'Compartilhe quanto você pode gastar sem expor saldo ou dívidas', () => openStoryComposer({ template: 'spendable', source: 'you' })),
    item('▶', 'Meu mês em 15 segundos', `Retrospectiva de ${monthName(ymOf(today()))}`, () => openRetrospective(ymOf(today()))),
    item('◫', 'Bivvo Wrapped & Stories', 'Compartilhe sua evolução sem expor saldo ou dívidas', () => openStoryComposer({})),
    item('✦', `Retrospectiva de ${wrappedDefaultYear()}`, new Date().getMonth() >= 11 || new Date().getMonth() === 0 ? 'Seu ano em slides para compartilhar' : 'Seu ano até agora, em slides', () => openYearWrapped()),
    item('➗', 'Dividir conta', 'Manda a parte de cada um por link, com Pix', () => openSplitForm()),
    item('✉', 'Indique e ganhe Pro', 'A cada 3 amigos ativados: +30 dias de Pro. Quem chega pelo seu link ganha 7 dias.', () => inviteFriend())));

  root.append(h('section.card.menu', sectionTitle('Preferências'),
    item('◫','Personalizar início','Escolha as informações que aparecem primeiro',openHomePreferences),
    document.querySelector('#adminNav')?.hidden===false?item('▥','Administração','Indicadores e gestão do aplicativo',()=>go('admin')):null,
    item('👤', 'Nome, dia de receber e horas de trabalho', s.profile.incomeDay ? `Recebe todo dia ${s.profile.incomeDay}` : 'Melhora o cálculo de quanto você pode gastar', editProfile),
    item('🎯', 'Meta de guardar', `${s.savingPlan.percent}% da renda`, () => go('planos', { tab: 'orcamento' })),
    item('🔁', 'Contas fixas', `${s.fixed.length} cadastrada(s)`, () => go('planos', { tab: 'fixas' })),
    item('◉', 'Categorias e ícones', `${store.categories('expense').length} categorias · personalize os ícones`, openCategoryManager),
    h('div.install-platforms',
      h('div.install-platform-copy', h('b', 'Instalar Bivvo no celular'), h('small', isPwaInstalled() ? 'O Bivvo já está instalado neste aparelho.' : 'Um toque e o Bivvo usa o caminho mais curto permitido pelo seu aparelho.')),
      h('button.btn.primary.install-auto', { type: 'button', disabled: isPwaInstalled(), onclick: () => openInstallGuide('auto', 'settings') }, isPwaInstalled() ? 'Bivvo instalado ✓' : 'Instalar Bivvo'),
      h('small.install-device-hint', devicePlatform().iOS ? 'iPhone detectado — mostraremos somente os passos exigidos pelo iOS.' : devicePlatform().android ? 'Android detectado — se disponível, abriremos a instalação nativa direto.' : 'Se o navegador permitir, a instalação nativa abrirá direto.')),
    item('🔔', 'Avisos e lembretes', pushActive() ? 'Ativos neste aparelho' : 'Lembrete da noite, faturas e contas vencendo', openNotifySettings)));

  root.append(h('section.card.menu', sectionTitle('Módulos'),
    moduleToggle('↗', 'Empréstimos', 'Ao desligar, contratos, pagamentos e atalhos ficam ocultos. Seus dados são preservados.', store.loansEnabled(s), on => store.commit(st => { st.profile.modules = { ...(st.profile.modules || {}), loans: on }; }))));

  root.append(h('section.card.menu', sectionTitle('Seus dados'),
    item('⇣', 'Importar extrato', 'CSV, OFX ou Excel do seu banco', importFile),
    item('⇡', 'Exportar planilha (CSV)', 'Abre no Excel e no Google Planilhas', exportCSV),
    item('🖨', 'Relatório do mês', 'Imprimir ou salvar em PDF', printReport),
    item('💾', 'Backup completo', 'Arquivo JSON só no seu aparelho', exportJSON),
    item('♻', 'Restaurar backup', 'Substitui os dados atuais', restoreJSON)));

  root.append(h('section.card.menu', sectionTitle('Privacidade'), item('⚙', 'Revisar permissões', null, () => window.bivvoPrivacy?.open())));

  if (ctx.demo) root.append(h('section.card.demo-cta', h('h3', 'Gostou do que viu?'), h('p.muted', 'Crie sua conta para usar com seus dados. A demonstração não é salva.'), h('button.btn.primary', { type: 'button', onclick: () => leaveDemo(true) }, 'Criar minha conta'), h('button.btn.ghost', { type: 'button', onclick: () => leaveDemo(false) }, 'Sair da demonstração')));
  else {
    const mfaLabel = h('small', 'Verificando…');
    cloud.mfaStatus().then(on => { mfaLabel.textContent = on ? 'Ativada' : 'Recomendado: proteja sua conta com um código extra'; }).catch(() => { mfaLabel.textContent = ''; });
    root.append(h('section.card.menu', sectionTitle('Segurança'),
      item('🔑', 'Trocar senha', 'Pede um código enviado ao seu e-mail', changePassword),
      h('button.menu-item', { type: 'button', onclick: setupMfa }, h('span.mi-ico', { 'aria-hidden': 'true' }, '🛡'), h('span', h('b', 'Verificação em duas etapas'), mfaLabel), h('span.mi-chev', { 'aria-hidden': 'true' }, '›')),
      item('↪', 'Sair deste aparelho', null, async () => { await cloud.signOut('local'); }),
      item('⎋', 'Sair de todos os aparelhos', null, async () => { if (await confirmSheet({ title: 'Sair de todos os aparelhos?', message: 'Todas as sessões abertas serão encerradas.', confirmLabel: 'Sair de todos' })) await cloud.signOut('global'); })));
  }

  root.append(h('section.card.danger-zone', sectionTitle('Zona de cuidado'),
    h('p.muted.sm', 'Zerar apaga lançamentos, cartões, parcelas, contas fixas, orçamento, metas, investimentos, desafios e planejamento. Sua conta e seu login continuam ativos.'),
    h('button.btn.danger', { type: 'button', onclick: resetAll }, 'Zerar todos os dados'),
    ctx.demo ? null : h('button.btn.ghost.danger-text', { type: 'button', onclick: deleteAccount }, 'Excluir minha conta')));

  root.append(h('p.version', `Bivvo v${VERSION} · ${RELEASE_DATE}`), h('p.version', 'No iPhone: Safari → Compartilhar → Adicionar à Tela de Início.'));
}

/* ---------------- perfil ---------------- */
function editProfile() {
  const s = store.getState();
  const name = h('input.input', { value: s.profile.name || '', maxLength: 30, autocomplete: 'given-name' });
  const day = h('input.input', { type: 'number', inputmode: 'numeric', min: 1, max: 31, value: s.profile.incomeDay || '' });
  const hours = h('input.input', { type: 'number', inputmode: 'numeric', min: 20, max: 400, value: s.profile.hoursPerMonth || 176 });
  const sheet = openSheet({ title: 'Seu perfil', content: [field('Como te chamamos', name), field('Dia em que costuma receber', day, 'Define até quando vai o "livre para gastar hoje".'), field('Horas trabalhadas por mês', hours, 'Usado para mostrar quanto tempo de trabalho um gasto representa. 176 h = 8 h × 22 dias.')],
    footer: [h('button.btn.primary', { type: 'button', onclick: () => { store.commit(st => { st.profile.name = name.value.trim().slice(0, 30); const d = Math.floor(num(day.value)); st.profile.incomeDay = d >= 1 && d <= 31 ? d : null; const hr = Math.floor(num(hours.value)); st.profile.hoursPerMonth = hr >= 20 ? hr : 176; }); sheet.close(); toast('Perfil salvo'); } }, 'Salvar')] });
}

/* ---------------- importação ---------------- */
function importFile() {
  const input = h('input', { type: 'file', accept: '.csv,.ofx,.xlsx,.xls,.txt' });
  input.addEventListener('change', async () => {
    const file = input.files?.[0]; if (!file) return;
    adminTrack('import_started','voce').catch(()=>{});
    if (file.size > 5 * 1024 * 1024) return toast('Arquivo maior que 5 MB.');
    try {
      let rows = [];
      const n = file.name.toLowerCase();
      if (n.endsWith('.xlsx') || n.endsWith('.xls')) rows = await readXlsx(file);
      else { const text = await file.text(); rows = n.endsWith('.ofx') || /<OFX>|<STMTTRN>/i.test(text) ? parseOFX(text) : parseCSV(text); }
      const items = rows.map(normalizeImported).filter(Boolean);
      if (!items.length) return toast('Não encontramos lançamentos nesse arquivo.');
      const s = store.getState();
      const key = t => `${t.date}|${t.value.toFixed(2)}|${t.type}|${t.desc.toLowerCase()}`;
      const existing = new Set(s.transactions.map(key));
      const fresh = items.filter(t => !existing.has(key(t)));
      const sample = fresh.slice(0, 8).map(t => `${t.date.split('-').reverse().join('/')} · ${t.desc} · ${t.cat}`).join('\n');
      const ok = await confirmSheet({ title: `Prévia · ${fresh.length} novo(s)`, message: `${items.length} encontrados${items.length-fresh.length?` · ${items.length-fresh.length} duplicado(s) ignorado(s)`:''}.\n\n${sample}${fresh.length>8?'\n… e mais '+(fresh.length-8):''}\n\nConfira a prévia antes de importar.`, confirmLabel: 'Confirmar importação' });
      if (!ok || !fresh.length) return;
      store.commit(st => { st.transactions.push(...fresh); });
      toast(`${fresh.length} lançamento(s) importado(s)`); adminTrack('import_completed','voce').catch(()=>{});
    } catch (e) { adminTrack('import_failed','voce').catch(()=>{}); toast('Não foi possível ler o arquivo: ' + (e.message || e)); }
  });
  input.click();
}
function splitCSVLine(line, sep) { const out = []; let cur = '', q = false; for (let i = 0; i < line.length; i++) { const c = line[i]; if (c === '"') { if (q && line[i + 1] === '"') { cur += '"'; i++; } else q = !q; } else if (c === sep && !q) { out.push(cur); cur = ''; } else cur += c; } out.push(cur); return out.map(x => x.trim()); }
function parseCSV(text) {
  const lines = text.replace(/^\uFEFF/, '').split(/\r?\n/).filter(l => l.trim());
  if (lines.length < 2) return [];
  const sep = (lines[0].match(/;/g) || []).length >= (lines[0].match(/,/g) || []).length ? ';' : ',';
  const head = splitCSVLine(lines[0], sep).map(x => x.toLowerCase());
  return lines.slice(1).map(l => { const c = splitCSVLine(l, sep), o = {}; head.forEach((k, i) => { o[k] = c[i] ?? ''; }); return o; });
}
function parseOFX(text) {
  const out = []; const re = /<STMTTRN>([\s\S]*?)(<\/STMTTRN>|(?=<STMTTRN>)|<\/BANKTRANLIST>)/gi; let m;
  const tag = (b, t) => { const r = new RegExp('<' + t + '>([^<\\r\\n]*)', 'i').exec(b); return r ? r[1].trim() : ''; };
  while ((m = re.exec(text))) { const b = m[1], d = tag(b, 'DTPOSTED'); out.push({ data: d ? `${d.slice(0, 4)}-${d.slice(4, 6)}-${d.slice(6, 8)}` : '', descricao: tag(b, 'MEMO') || tag(b, 'NAME') || 'Lançamento importado', valor: tag(b, 'TRNAMT') }); }
  return out;
}
async function readXlsx(file) {
  if (!window.XLSX) await new Promise((res, rej) => { const sc = document.createElement('script'); sc.src = 'https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js'; sc.onload = res; sc.onerror = () => rej(new Error('leitor de Excel indisponível')); document.head.append(sc); });
  const wb = window.XLSX.read(await file.arrayBuffer(), { type: 'array', cellDates: true });
  return window.XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { defval: '', raw: false }).map(r => Object.fromEntries(Object.entries(r).map(([k, v]) => [k.toLowerCase(), v])));
}
function toISODate(v) {
  const s = String(v || '').trim();
  let m = s.match(/^(\d{4})-(\d{2})-(\d{2})/); if (m) return `${m[1]}-${m[2]}-${m[3]}`;
  m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})/); if (m) { const y = m[3].length === 2 ? '20' + m[3] : m[3]; return `${y}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`; }
  return null;
}
function normalizeImported(o) {
  const pick = (...keys) => { for (const k of keys) if (o[k] !== undefined && o[k] !== '') return o[k]; return ''; };
  const date = toISODate(pick('date', 'data', 'data lançamento', 'data de lançamento', 'dt'));
  if (!date) return null;
  const desc = String(pick('desc', 'descricao', 'descrição', 'description', 'histórico', 'historico', 'título', 'titulo', 'estabelecimento') || 'Lançamento importado').slice(0, 120);
  let value = parseMoney(pick('value', 'valor', 'amount', 'quantia', 'valor (r$)'));
  if (!value) return null;
  const typeRaw = String(pick('type', 'tipo')).toLowerCase();
  const type = /entrada|receita|income|cr[eé]dito$/.test(typeRaw) ? 'income' : /sa[ií]da|despesa|expense|d[eé]bito$/.test(typeRaw) ? 'expense' : value < 0 ? 'expense' : 'income';
  value = round2(Math.abs(value));
  return { id: uid(), date, desc, type, value, cat: store.autoCategory(desc, type) || 'Outros', status: 'Pago', method: 'Outro', note: 'Importado', createdAt: Date.now() };
}

/* ---------------- exportação ---------------- */
const csvCell = v => { let s = String(v ?? ''); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return /[;"\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
function exportCSV() {
  const s = store.getState();
  const rows = [['Data', 'Descrição', 'Categoria', 'Tipo', 'Valor', 'Situação', 'Forma', 'Cartão', 'Parcela', 'Fatura']];
  for (const t of s.transactions.slice().sort((a, b) => a.date.localeCompare(b.date))) rows.push([t.date.split('-').reverse().join('/'), t.desc, t.cat, t.type === 'income' ? 'Entrada' : 'Saída', t.value.toFixed(2).replace('.', ','), t.status, t.method, t.card || '', t.installment || '', t.method === 'Crédito' ? F.txInvoice(t) : '']);
  download('\uFEFF' + rows.map(r => r.map(csvCell).join(';')).join('\r\n'), `bivvo-lancamentos-${today()}.csv`, 'text/csv;charset=utf-8');
  toast('Planilha exportada');
}
async function exportJSON() {
  if (!(await confirmSheet({ title: 'Gerar backup?', message: 'O arquivo contém suas informações financeiras. Guarde-o em local seguro e não envie para outras pessoas.', confirmLabel: 'Gerar backup' }))) return;
  const data = { app: 'Bivvo', version: VERSION, exportedAt: new Date().toISOString(), payload: store.serialize() };
  download(JSON.stringify(data, null, 1), `bivvo-backup-${today()}.json`, 'application/json');
  if (!ctx.demo) cloud.securityLog('export_json');
}
function restoreJSON() {
  const input = h('input', { type: 'file', accept: '.json,application/json' });
  input.addEventListener('change', async () => {
    const file = input.files?.[0]; if (!file) return;
    try {
      const raw = JSON.parse(await file.text());
      const payload = raw && raw.payload && typeof raw.payload === 'object' ? raw.payload : raw;
      if (!payload || typeof payload !== 'object' || !Array.isArray(payload.transactions)) throw new Error('arquivo não parece um backup do Bivvo');
      const m = store.migrate(payload);
      if (!(await confirmSheet({ title: 'Restaurar backup?', message: `${m.transactions.length} lançamentos, ${m.cards.length} cartões e ${m.goals.length} metas vão substituir os dados atuais.`, confirmLabel: 'Restaurar', danger: true }))) return;
      store.commit(s => { const profile = s.profile; Object.keys(s).forEach(k => delete s[k]); Object.assign(s, m, { profile: { ...m.profile, onboarded: true }, resetAt: undefined }); if (!m.profile.name && profile.name) s.profile.name = profile.name; });
      toast('Backup restaurado');
    } catch (e) { toast('Não foi possível restaurar: ' + e.message); }
  });
  input.click();
}
function download(content, name, type) { const url = URL.createObjectURL(new Blob([content], { type })); const a = h('a', { href: url, download: name }); document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 4000); }

function printReport() {
  const s = store.getState(), ym = ctx.month || ymOf(today()), sm = F.monthSummary(ym, s);
  const host = document.getElementById('print'); host.replaceChildren();
  const rows = F.monthTx(ym, s).slice().sort((a, b) => a.date.localeCompare(b.date));
  host.append(h('h1', `Bivvo · Relatório de ${monthLabel(ym)}`),
    h('p', `Entradas ${money(sm.income)} · Gastos ${money(sm.spend)} · Guardado ${money(sm.saved)} · Resultado ${money(sm.result)}`),
    h('h2', 'Gastos por categoria'), h('table', h('tbody', sm.cats.map(c => h('tr', h('td', c.cat), h('td', money(c.value)), h('td', Math.round(c.share * 100) + '%'))))),
    h('h2', 'Lançamentos'), h('table', h('thead', h('tr', ['Data', 'Descrição', 'Categoria', 'Valor', 'Situação'].map(x => h('th', x)))),
      h('tbody', rows.map(t => h('tr', h('td', t.date.split('-').reverse().join('/')), h('td', t.desc), h('td', t.cat), h('td', (t.type === 'income' ? '+' : '−') + money(t.value)), h('td', t.status))))),
    h('p.small', `Gerado em ${new Date().toLocaleString('pt-BR')} · Bivvo v${VERSION}`));
  window.print();
}

/* ---------------- segurança ---------------- */
async function changePassword() {
  const p = await askSheet({ title: 'Nova senha', label: 'Nova senha (mínimo 10 caracteres)', type: 'password', autocomplete: 'new-password', pattern: /^.{10,}$/ });
  if (!p) return;
  try { await cloud.changePassword(p, () => askSheet({ title: 'Confirme pelo e-mail', message: 'Enviamos um código de 6 dígitos para o seu e-mail.', label: 'Código', inputmode: 'numeric', autocomplete: 'one-time-code', pattern: /^\d{6}$/ })); toast('Senha atualizada'); }
  catch (e) { toast(cloud.friendlyAuthError(e), { tone: 'warn' }); }
}
async function setupMfa() {
  try {
    if (await cloud.mfaStatus()) return toast('A verificação em duas etapas já está ativa nesta conta.');
    const { factorId, qr } = await cloud.enrollMfa();
    const code = h('input.input', { inputmode: 'numeric', autocomplete: 'one-time-code', placeholder: '000000', maxLength: 6 });
    const msg = h('p.form-msg');
    const sheet = openSheet({ title: 'Ativar verificação em duas etapas', subtitle: 'Escaneie o código com Google Authenticator, Authy ou 1Password e digite o código gerado.',
      content: [qr ? h('img.qr', { src: qr, alt: 'QR Code para o aplicativo autenticador', width: 200, height: 200 }) : null, field('Código de 6 dígitos', code), msg],
      footer: [h('button.btn.primary', { type: 'button', onclick: async () => { if (!/^\d{6}$/.test(code.value.trim())) { msg.textContent = 'Digite os 6 números.'; return; } try { await cloud.verifyMfaEnroll(factorId, code.value.trim()); sheet.close(); toast('Verificação em duas etapas ativada'); go('voce'); } catch (e) { msg.textContent = cloud.friendlyAuthError(e); } } }, 'Ativar')] });
  } catch (e) { toast(cloud.friendlyAuthError(e), { tone: 'warn' }); }
}
async function deleteAccount() {
  // Feedback imediato: se o clique chegou aqui, o usuário sempre vê uma resposta.
  toast('Abrindo confirmação para excluir a conta…');
  let confirmed = false;
  try {
    confirmed = await confirmSheet({ title: 'Excluir conta definitivamente?', message: 'Sua conta e todos os dados financeiros serão apagados para sempre. Esta ação não pode ser desfeita. Digite EXCLUIR no campo abaixo para liberar o botão.', confirmLabel: 'Continuar', danger: true, requireText: 'EXCLUIR' });
  } catch (e) {
    console.error('Falha ao abrir confirmação de exclusão:', e);
    toast('Não foi possível abrir a confirmação. Atualize o Bivvo e tente novamente.', { tone: 'warn' });
    return;
  }
  if (!confirmed) return;
  const pass = await askSheet({ title: 'Confirme sua senha', label: 'Senha', type: 'password', autocomplete: 'current-password' });
  if (!pass) return;
  try {
    await cloud.deleteAccount(pass, askMfa);
    toast('Conta excluída definitivamente.');
    // Não deixe a tela da conta antiga visível enquanto o evento SIGNED_OUT
    // termina de propagar pelo app.
    setTimeout(() => { location.href = location.origin + location.pathname; }, 350);
  } catch (e) {
    const message = cloud.friendlyAuthError(e);
    toast(message, { tone: 'warn' });
    console.warn('Falha ao excluir conta:', e);
  }
}
async function resetAll() {
  if (!(await confirmSheet({ title: 'Zerar todos os dados?', message: 'Lançamentos, cartões, parcelas, contas fixas, orçamento, metas, investimentos e desafios serão apagados aqui e na nuvem. Sua conta continua ativa. Se quiser guardar uma cópia, faça um backup antes.', confirmLabel: 'Zerar tudo', danger: true, requireText: 'ZERAR' }))) return;
  try {
    if (ctx.demo) store.load(store.emptyState({ ...store.getState().profile }), { demo: true });
    else await cloud.resetAllData();
    toast('Todos os dados foram apagados.');
    go('inicio');
  } catch (e) { toast('A limpeza não foi concluída: ' + (e.message || e), { tone: 'warn' }); }
}

/* ---------------- módulos opcionais ---------------- */
function moduleToggle(icon, title, sub, on, onChange) {
  const input = h('input', { type: 'checkbox', role: 'switch', checked: !!on, 'aria-label': title });
  input.addEventListener('change', () => { onChange(input.checked); toast(input.checked ? `${title} ligado` : `${title} desligado. Seus dados continuam guardados.`); });
  return h('label.menu-item.toggle-row', h('span.mi-ico', { 'aria-hidden': 'true' }, icon), h('span', h('b', title), h('small', sub)), h('span.toggle.inline', input, h('i', { 'aria-hidden': 'true' })));
}

/* ---------------- avisos e lembretes ---------------- */
function openNotifySettings() {
  const s = store.getState();
  const sup = pushSupport();
  const sw = (label, hint, checked) => { const input = h('input', { type: 'checkbox', role: 'switch', checked: !!checked }); const el = h('label.toggle', h('span', h('b', label), hint ? h('small', hint) : null), input, h('i', { 'aria-hidden': 'true' })); el.input = input; return el; };
  const evening = sw('Perguntar ao abrir à noite', 'Se nada foi anotado no dia, a partir das 18h o Bivvo pergunta uma vez.', s.profile.eveningCapture !== false);
  evening.input.addEventListener('change', () => store.commit(st => { st.profile.eveningCapture = evening.input.checked; }));
  const hours = h('select.input', { 'aria-label': 'Horário do lembrete' }, Array.from({ length: 24 }, (_, i) => h('option', { value: i }, `${String(i).padStart(2, '0')}:00`)));
  hours.value = '20';
  const values = sw('Mostrar valores nos avisos', 'Privacidade: desligado, a tela bloqueada mostra apenas alertas discretos. Ligado, pode mostrar limite diário e valores.', false);
  const status = h('p.form-msg', { role: 'status' });
  const pushBox = h('div.notify-push');
  const paintPush = () => {
    pushBox.replaceChildren();
    if (ctx.demo) { pushBox.append(h('p.muted.sm', 'Na demonstração os avisos ficam desligados. Crie sua conta para receber.')); return; }
    if (!sup.ok && !sup.needsInstall) { pushBox.append(h('p.muted.sm', 'Este navegador não recebe avisos. No celular, use o Bivvo instalado na tela inicial.')); return; }
    if (sup.needsInstall) { pushBox.append(h('p.muted.sm', 'No iPhone, os avisos só funcionam com o Bivvo instalado na Tela de Início (iOS 16.4 ou mais novo).'), h('button.btn.primary.block', { type: 'button', onclick: () => openInstallGuide('ios') }, 'Ver como instalar')); return; }
    const active = pushActive();
    pushBox.append(
      h('div.row2', h('label.field', h('span', 'Horário do lembrete'), hours)), values,
      active
        ? h('div.btn-row', h('button.btn', { type: 'button', onclick: test }, 'Enviar teste'), h('button.btn.ghost.danger-text', { type: 'button', onclick: off }, 'Desligar avisos'))
        : h('button.btn.primary.block', { type: 'button', onclick: on }, 'Ativar avisos neste aparelho'));
  };
  async function on() { status.textContent = 'Ativando…'; try { await enablePush({ hour: Number(hours.value), showValues: values.input.checked }); status.textContent = ''; toast('Avisos ativados'); paintPush(); } catch (e) { status.textContent = e.message; } }
  async function off() { try { await disablePush(); toast('Avisos desligados neste aparelho'); paintPush(); } catch (e) { status.textContent = e.message; } }
  async function test() { status.textContent = 'Enviando…'; try { await sendTest(); status.textContent = 'Teste enviado. Deve chegar em alguns segundos.'; } catch (e) { status.textContent = e.message; } }
  const persist = () => { if (pushActive()) savePrefs({ hour: Number(hours.value), showValues: values.input.checked }).then(() => toast('Preferência salva')).catch(e => { status.textContent = e.message; }); };
  hours.addEventListener('change', persist); values.input.addEventListener('change', persist);
  if (!ctx.demo && cloud.currentUser()) readPrefs().then(p => { if (p) { hours.value = String(p.hour ?? 20); values.input.checked = !!p.show_values; } }).catch(() => {});
  paintPush();
  openSheet({
    title: 'Bivvo em segundo plano', subtitle: 'Avisos inteligentes no iPhone e Android: risco de faltar dinheiro, contas e faturas, cartão, limite do dia e progresso — com prioridade para o que realmente importa.',
    content: h('div.form', h('p.sub-title', 'No celular, mesmo com o app fechado'), h('p.muted.sm', sup.android ? 'No Android, o Bivvo pode mostrar avisos mesmo fechado, usar vibração do sistema, aparecer na tela bloqueada e atualizar o selo do ícone quando o aparelho permitir.' : 'No iPhone, o Bivvo instalado na Tela de Início pode mostrar avisos na Tela Bloqueada, Central de Notificações e atualizar o selo do ícone.'), pushBox, status, h('p.sub-title', 'Dentro do app'), evening)
  });
}
