const crypto = require('crypto');
const { rest, userFromJwt, rateLimit, adminKey } = require('../lib/supabase-admin.js');
const { planOf } = require('../lib/plans.js');
const headers={'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
const out=(statusCode,body)=>({statusCode,headers,body:JSON.stringify(body)});
const clean=(s,n=80)=>String(s||'').trim().replace(/[<>]/g,'').slice(0,n);
const code=()=>crypto.randomBytes(12).toString('base64url');
const coupleFamily=f=>String(f?.name||'').startsWith('Casal · ');
const paid=p=>['plus','pro','family'].includes(p);
async function membership(userId){ const r=await rest(`family_members?user_id=eq.${encodeURIComponent(userId)}&select=id,family_id,user_id,role,display_name,joined_at&limit=1`); return r?.[0]||null; }
async function familyFor(userId){ const m=await membership(userId); if(!m)return null; const f=(await rest(`families?id=eq.${m.family_id}&select=id,name,owner_id,created_at&limit=1`))?.[0]; if(!f)return null; const members=await rest(`family_members?family_id=eq.${f.id}&select=id,user_id,role,display_name,joined_at&order=joined_at.asc`); const shared=await rest(`family_transactions?family_id=eq.${f.id}&select=id,user_id,source_id,date,description,category,type,value,created_at&order=date.desc&limit=100`); const plan=await planOf(rest,f.owner_id),kind=coupleFamily(f)?'couple':'family',active=kind==='couple'?paid(plan):plan==='family'; return {family:f,membership:m,members:members||[],shared:shared||[],active,kind,maxMembers:kind==='couple'?2:4}; }
exports.handler=async event=>{
 if(event.httpMethod!=='POST')return out(405,{error:'Método não permitido.'}); if(!adminKey())return out(503,{error:'Servidor ainda não configurado.'});
 const jwt=String(event.headers.authorization||'').replace(/^Bearer\s+/i,'').trim(); const user=await userFromJwt(jwt); if(!user?.id)return out(401,{error:'Entre na sua conta.'});
 if(!(await rateLimit('family:'+user.id,60,3600)))return out(429,{error:'Muitas alterações. Aguarde um pouco.'});
 let b={}; try{b=JSON.parse(event.body||'{}')}catch{return out(400,{error:'Pedido inválido.'})} const action=clean(b.action,30);
 try{
  if(action==='get') return out(200,{ok:true,data:await familyFor(user.id)});
  if(action==='create'){
   if(await membership(user.id))return out(409,{error:'Você já participa de um Espaço Família.'});
   const creatingCouple=b.kind==='couple',plan=await planOf(rest,user.id);if(creatingCouple?!paid(plan):plan!=='family')return out(403,{error:'O Espaço Família é exclusivo do plano Bivvo Família.'});
   const label=clean(b.name,40).replace(/^Casal · /,'')||'Meu espaço',name=creatingCouple?'Casal · '+label:label; const f=(await rest('families',{method:'POST',body:{name,owner_id:user.id},prefer:'return=representation'}))?.[0];
   await rest('family_members',{method:'POST',body:{family_id:f.id,user_id:user.id,role:'owner',display_name:clean(user.user_metadata?.full_name||user.email?.split('@')[0],50)},prefer:'return=minimal'});
   return out(200,{ok:true,data:await familyFor(user.id)});
  }
  if(action==='accept'){
   if(await membership(user.id))return out(409,{error:'Você já participa de um Espaço Família.'}); const inviteCode=clean(b.code,100);
   const inv=(await rest(`family_invites?code=eq.${encodeURIComponent(inviteCode)}&accepted_at=is.null&expires_at=gt.${encodeURIComponent(new Date().toISOString())}&select=*&limit=1`))?.[0]; if(!inv)return out(404,{error:'Convite inválido ou expirado.'});
   const invitedFamily=(await rest(`families?id=eq.${inv.family_id}&select=owner_id,name&limit=1`))?.[0]; if(!invitedFamily || !(coupleFamily(invitedFamily)?paid(await planOf(rest,invitedFamily.owner_id)):(await planOf(rest,invitedFamily.owner_id))==='family'))return out(403,{error:'Este Espaço Família não está com o plano Família ativo.'});
   const count=(await rest(`family_members?family_id=eq.${inv.family_id}&select=id`))?.length||0; const max=coupleFamily(invitedFamily)?2:4;if(count>=max)return out(409,{error:`Este espaço já tem ${max} membros.`});
   if(coupleFamily(invitedFamily)){await rest('rpc/bivvo_accept_couple_invite',{method:'POST',body:{p_user:user.id,p_code:inviteCode,p_name:clean(user.user_metadata?.full_name||user.email?.split('@')[0],50)}});return out(200,{ok:true,data:await familyFor(user.id)});}
   await rest('family_members',{method:'POST',body:{family_id:inv.family_id,user_id:user.id,role:inv.role==='editor'?'editor':'viewer',display_name:clean(user.user_metadata?.full_name||user.email?.split('@')[0],50)},prefer:'return=minimal'});
   await rest(`family_invites?id=eq.${inv.id}`,{method:'PATCH',body:{accepted_at:new Date().toISOString(),accepted_by:user.id},prefer:'return=minimal'}); return out(200,{ok:true,data:await familyFor(user.id)});
  }
  const data=await familyFor(user.id); if(!data)return out(404,{error:'Você ainda não participa de um Espaço Família.'}); const me=data.membership; const manage=me.role==='owner'; const edit=manage||me.role==='editor'; if(!data.active && !['leave'].includes(action))return out(403,{error:'O plano Família do responsável precisa estar ativo para alterar este espaço.'});
  if(action==='invite'){
   if(!manage)return out(403,{error:'Só o responsável pode convidar membros.'}); if(data.members.length>=data.maxMembers)return out(409,{error:`Este espaço permite até ${data.maxMembers} pessoas.`});
   const c=code(), expires=new Date(Date.now()+7*86400000).toISOString(), role=b.role==='editor'?'editor':'viewer'; await rest('family_invites',{method:'POST',body:{family_id:data.family.id,created_by:user.id,code:c,role,expires_at:expires},prefer:'return=minimal'}); return out(200,{ok:true,code:c,expiresAt:expires});
  }
  if(action==='role'){
   if(!manage)return out(403,{error:'Só o responsável pode alterar permissões.'}); const target=data.members.find(x=>x.id===b.memberId); if(!target||target.role==='owner')return out(400,{error:'Membro inválido.'}); const role=b.role==='editor'?'editor':'viewer'; await rest(`family_members?id=eq.${encodeURIComponent(target.id)}`,{method:'PATCH',body:{role},prefer:'return=minimal'}); return out(200,{ok:true});
  }
  if(action==='remove'){
   if(!manage)return out(403,{error:'Só o responsável pode remover membros.'}); const target=data.members.find(x=>x.id===b.memberId); if(!target||target.role==='owner')return out(400,{error:'Membro inválido.'}); await rest(`family_members?id=eq.${encodeURIComponent(target.id)}`,{method:'DELETE'}); await rest(`family_transactions?family_id=eq.${data.family.id}&user_id=eq.${target.user_id}`,{method:'DELETE'}).catch(()=>{}); return out(200,{ok:true});
  }
  if(action==='leave'){
   if(me.role==='owner')return out(409,{error:'O responsável não pode sair enquanto o espaço existir.'}); await rest(`family_members?id=eq.${encodeURIComponent(me.id)}`,{method:'DELETE'}); return out(200,{ok:true});
  }
  if(action==='share_transaction'){
   if(!edit)return out(403,{error:'Seu acesso é somente leitura.'}); const t=b.transaction||{}; if(!Number.isFinite(Number(t.value))||!/^\d{4}-\d{2}-\d{2}$/.test(t.date)||!['income','expense'].includes(t.type)||!(Number(t.value)>=0))return out(400,{error:'Lançamento inválido.'});
   const row={family_id:data.family.id,user_id:user.id,source_id:clean(t.sourceId,80),date:t.date,description:clean(t.desc,120)||'Lançamento',category:clean(t.cat,60)||'Outros',type:t.type,value:Math.round(Number(t.value)*100)/100};
   await rest('family_transactions?on_conflict=family_id,user_id,source_id',{method:'POST',body:row,prefer:'resolution=merge-duplicates,return=minimal'}); return out(200,{ok:true});
  }
  if(action==='unshare_transaction'){
   if(!edit)return out(403,{error:'Seu acesso é somente leitura.'}); await rest(`family_transactions?family_id=eq.${data.family.id}&user_id=eq.${user.id}&source_id=eq.${encodeURIComponent(clean(b.sourceId,80))}`,{method:'DELETE'}); return out(200,{ok:true});
  }
  return out(400,{error:'Ação desconhecida.'});
 }catch(e){console.error('family',action,e.message); return out(502,{error:'Não foi possível concluir esta ação agora.'});}
};
