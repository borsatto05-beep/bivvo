const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const fs=require('node:fs');
(async()=>{
 const browser=await chromium.launch({headless:true,args:['--no-sandbox'],...(fs.existsSync('/usr/bin/chromium')?{executablePath:'/usr/bin/chromium'}:{})});
 const context=await browser.newContext({viewport:{width:390,height:844}});
 const page=await context.newPage(),errors=[];
 let external=0;
 page.on('pageerror',e=>errors.push(e.message));
 await page.route('**/api/**',r=>r.fulfill({status:204}));
 await page.route(/https:\/\//,r=>{external++;return r.fulfill({status:200,contentType:'application/javascript',body:''});});
 const url=process.env.BIVVO_TEST_URL || 'http://127.0.0.1:8765';
 try {
  await page.goto(url);await page.waitForSelector('.privacy-panel');
  await page.waitForFunction(()=>document.querySelector('#landingDemo') && !document.body.classList.contains('booting'));
  assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),'no mobile overflow');
  assert.equal(external,0,'no external requests before consent (SDK is local)');
  await page.getByRole('button',{name:'Continuar sem rastreamento',exact:true}).click();
  await page.locator('#landingDemo').click();await page.waitForSelector('#view [data-qa],#view .card,#view section');
  assert.equal(await page.locator('.privacy-toggle').count(),0,'no floating privacy button');
  assert.equal(await page.evaluate(()=>window.bivvoPrivacy.marketingAllowed()),false);
  await page.evaluate(()=>{location.hash='#/voce';});
  await page.getByRole('button',{name:'Revisar permissões',exact:true}).click();
  await page.getByRole('button',{name:'Permitir medição de campanhas',exact:true}).click();
  await page.waitForFunction(()=>window.__bivvoPixelLoaded===true);await page.waitForTimeout(150);
  assert(external>=1,'pixel loads only after consent');
  await page.evaluate(()=>{location.hash='#/voce';});
  await page.getByRole('button',{name:'Revisar permissões',exact:true}).click();
  await page.getByRole('button',{name:'Continuar sem rastreamento',exact:true}).click();
  assert.equal(await page.locator('.privacy-toggle').count(),0,'no floating privacy button');
  assert.equal(await page.evaluate(()=>window.bivvoPrivacy.marketingAllowed()),false);
  const previousExternal=external;
  await page.reload();await page.waitForFunction(()=>!document.body.classList.contains('booting'));
  assert.equal(external,previousExternal,'revocation survives reload');
  await page.evaluate(async()=>{await navigator.serviceWorker.register('/sw.js');await navigator.serviceWorker.ready;});
  await page.reload();await page.waitForFunction(()=>!!navigator.serviceWorker.controller);
  await page.route('**/js/util.js?release-probe=1',r=>r.fulfill({status:200,contentType:'application/javascript',body:"throw new Error('mixed release');"}));
  assert.equal(await page.evaluate(async()=> (await import('/js/util.js?release-probe=1')).VERSION),'11.43.0','active worker keeps its installed module version');
  await context.setOffline(true);await page.reload();await page.waitForFunction(()=>!document.body.classList.contains('booting'));
  await page.locator('#landingDemo').click();await page.waitForSelector('#view .card,#view section');
  await page.evaluate(async()=>{
    const {openScanConfirm}=await import('/js/views/scanconfirm.js');
    window.__closed=false;
    openScanConfirm({value:null,valueText:null,merchant:'Synthetic Store',date:'2026-10-06',confidence:.3,reviewFields:['value'],valueOptions:[20,30],scanMeta:{oneShot:true}}, {onClose:()=>window.__closed=true});
  });
  await page.waitForSelector('.scan-confirm');
  assert.equal(await page.locator('.scan-field-review').count(),1);
  assert.equal(await page.locator('.scan-confirm select').count(),0,'only local, date and amount');
  assert.equal(await page.locator('.scan-confirm input:visible').count(),1,'only missing amount is editable initially');
  if(process.env.BIVVO_SCREENSHOT) await page.screenshot({path:process.env.BIVVO_SCREENSHOT,fullPage:false});
  await page.getByRole('button',{name:'Confirmar',exact:true}).click();
  assert((await page.locator('.scan-confirm [role=alert]').innerText()).includes('Informe o valor'));
  await page.keyboard.press('Escape');await page.waitForFunction(()=>window.__closed);await page.waitForFunction(()=>!document.querySelector('.scan-confirm'));
  for (let mask=0;mask<8;mask++) {
    await page.evaluate(async(mask)=>{
      const {openScanConfirm}=await import('/js/views/scanconfirm.js');
      openScanConfirm({merchant:mask&1?'Loja teste':null,date:mask&2?'2026-10-06':null,value:mask&4?83.7:null});
    },mask);
    const found=[1,2,4].filter(bit=>mask&bit).length;
    assert.equal(await page.locator('.scan-confirm input:visible').count(),3-found,'only missing fields '+mask);
    assert.equal(await page.locator('.scan-confirm .scan-review.good').count(),found,'preserved fields '+mask);
    await page.getByRole('button',{name:'Cancelar',exact:true}).click();
    await page.waitForFunction(()=>!document.querySelector('.scan-confirm'));
  }
  await context.setOffline(false);
  await page.goto(url+'/privacidade/');assert.equal(await page.locator('h1').innerText(),'Privacidade no Bivvo');
  // A deploy that changes mid-install must fail as a whole, leaving no partial shell.
  const asset='dist/js/util.js',original=fs.readFileSync(asset);
  const fresh=await browser.newContext();
  try {
    fs.appendFileSync(asset,'\n/* release mismatch fixture */');
    const check=await fresh.newPage();await check.goto(url+'/privacidade/');
    const state=await check.evaluate(async()=>{
      const reg=await navigator.serviceWorker.register('/sw.js');
      const worker=reg.installing;
      if(!worker)return reg.active?.state || 'missing';
      return new Promise(resolve=>{worker.addEventListener('statechange',()=>{if(['redundant','activated'].includes(worker.state))resolve(worker.state);});});
    });
    assert.equal(state,'redundant','mixed release cannot activate');
    assert.equal(await check.evaluate(async()=> (await caches.keys()).filter(x=>x.startsWith('bivvo-v11-43-0')).length),0,'partial cache removed');
  }finally{fs.writeFileSync(asset,original);await fresh.close();}
  assert.equal(errors.length,0,errors.join('\n'));
  console.log('Browser: consent/revocation, local SDK, mobile demo, complete offline shell, scanner review, keyboard close and privacy page passed.');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exit(1);});
