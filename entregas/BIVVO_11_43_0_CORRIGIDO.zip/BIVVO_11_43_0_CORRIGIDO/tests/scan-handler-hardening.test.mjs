import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url), fn=require('../netlify/functions/scan-receipt.js');
process.env.SUPABASE_SECRET_KEY='test';process.env.GEMINI_API_KEY='test';
let raw={},reader=0,refunded=0,mode='ok';const saved=global.fetch;
const image=Buffer.concat([Buffer.from([255,216,255]),Buffer.alloc(900)]).toString('base64');
const event={httpMethod:'POST',headers:{authorization:'Bearer test'},body:JSON.stringify({images:[{mediaType:'image/jpeg',image}]})};
global.fetch=async(url,opts={})=>{
 if(url.endsWith('/auth/v1/user'))return Response.json({id:'user'});
 if(url.includes('/rpc/bivvo_rate_limit'))return Response.json(true);
 if(url.includes('/entitlements?'))return Response.json([]);
 if(url.includes('/rpc/bivvo_consume_usage'))return Response.json(1);
 if(url.includes('/rpc/bivvo_refund_usage')){refunded++;return new Response(null,{status:204});}
 if(url.includes('generativelanguage.googleapis.com')){
  reader++;const config=JSON.parse(opts.body).generationConfig;
  assert.deepEqual(Object.keys(config.responseSchema.properties).sort(),['date','merchant','value']);
  if(url.includes('gemini-2.5'))assert.equal(config.thinkingConfig.thinkingBudget,0);
  if(mode==='failure')return new Response('',{status:503});
  if(mode==='old-model'&&url.includes('gemini-3.6'))return new Response('',{status:404});
  return Response.json({candidates:[{content:{parts:[{thought:true,text:'internal reasoning'}, {text:JSON.stringify(raw)}]}}]});
 }
 throw new Error('Unexpected '+url);
};
try{
 const fields={merchant:'Loja teste',date:'2026-10-06',value:83.7};
 for(let mask=1;mask<8;mask++){
  raw=Object.fromEntries(Object.entries(fields).map(([k,v],i)=>[k,mask&(1<<i)?v:null]));reader=0;
  const response=await fn.handler(event);assert.equal(response.statusCode,200);assert.deepEqual(JSON.parse(response.body).data,raw);assert.equal(reader,1);
 }
 raw={merchant:null,date:'2026-02-30',value:null};let response=await fn.handler(event);assert.equal(JSON.parse(response.body).data.date,null);assert.equal(refunded,1);
 mode='failure';response=await fn.handler(event);assert.equal(response.statusCode,504);assert.equal(refunded,2);
 mode='old-model';process.env.GEMINI_MODEL='gemini-3.6-flash';raw=fields;reader=0;response=await fn.handler(event);assert.equal(response.statusCode,200);assert.equal(reader,2);assert.deepEqual(JSON.parse(response.body).data,fields);
}finally{global.fetch=saved;delete process.env.GEMINI_MODEL;}
console.log('Scanner: all seven partial combinations, invalid date, refund, thought filtering, legacy model fallback passed.');
