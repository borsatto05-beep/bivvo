/* Bivvo 10.4 — captura rápida: barra fixa na Início, folha rápida e lembrete noturno.
   O interpretador fica em quickparse.js (puro e testado). Todo salvamento oferece Desfazer. */
import { h, money, today, uid, dayLabel, shortDate } from './util.js';
import * as store from './store.js';
import { openSheet, toast, catIcon, confirmSheet } from './ui.js';
import { parseQuick } from './quickparse.js';
import { voiceSupported, listen } from './voice.js';
import { track, trackOnce } from './analytics.js';
import { adminTrack } from './admin-analytics.js';
import * as F from './finance.js';

const S = () => store.getState();
export const parse = (text, opts = {}) => { const s = S(); return parseQuick(text, { cards: s.cards, autoCategory: (d, t) => store.autoCategory(d, t, s), spoken: !!opts.spoken }); };

/* ---------------- gravação + desfazer ---------------- */
export function saveParsed(p, { cat, cardName, source = 'text' } = {}) {
  const hadRealTx = S().transactions.some(t => t.kind !== 'opening' && !t.demoSeed);
  let created = [], insts = [];
  const category = cat || p.cat;
  const card = p.card ? (S().cards.find(c => c.name === (cardName || p.card.name)) || p.card) : null;
  store.commit(s => {
    const before = new Set(s.transactions.map(t => t.id)), instBefore = new Set(s.installments.map(i => i.id));
    store.learnCategory(s, p.desc, category);
    if (card && p.type === 'expense') {
      const added = store.addCardPurchase(s, { desc: p.desc, cat: category, total: p.value, parts: p.parts || 1, card: card.name, date: p.date });
      added.forEach(t => { t.captureSource = source; });
    } else s.transactions.push({ id: uid(), date: p.date, desc: p.desc, cat: category, type: p.type, value: p.value, status: p.future ? 'Pendente' : 'Pago', method: p.method && p.method !== 'Crédito' ? p.method : (p.type === 'income' ? 'Transferência' : 'PIX'), createdAt: Date.now(), source: 'quick', captureSource: source });
    created = s.transactions.filter(t => !before.has(t.id)).map(t => t.id);
    insts = s.installments.filter(i => !instBefore.has(i.id)).map(i => i.id);
  });
  const when = p.date === today() ? '' : `, ${dayLabel(p.date) === 'Ontem' ? 'ontem' : 'em ' + shortDate(p.date)}`;
  const parts = card && p.parts > 1 ? ` em ${p.parts}x` : '';
  track(source === 'voice' ? 'voice_used' : source === 'scan' ? 'scan_used' : 'quick_capture_used', { channel: card ? 'card' : 'cash', parts: p.parts || 1 });
  trackOnce('first_tx');
  if (!hadRealTx) {
    adminTrack('first_transaction','activation').catch(()=>{});
    const sNow = S();
    const hasIncome = sNow.fixed.some(x => x.type === 'income') || sNow.transactions.some(t => F.isRealIncome(t));
    const hasOpening = sNow.transactions.some(t => F.isOpening(t));
    if (sNow.profile.onboarded && !sNow.profile.activationValueSeen && hasIncome && hasOpening) {
      try {
        if (!localStorage.getItem('bivvo_first_value_shown_v1')) {
          localStorage.setItem('bivvo_first_value_shown_v1','1');
          setTimeout(() => showFirstValue(), 220);
        }
      } catch { setTimeout(() => showFirstValue(), 220); }
    }
  }
  toast(`Anotado: ${p.desc}, ${money(p.value)}${parts}${when}`, { action: { label: 'Desfazer', fn: () => undoSave(created, insts) } });
  return created;
}
function showFirstValue() {
  const sp = F.spendable(S());
  const result = sp.tone === 'neg'
    ? h('div.onb-result', h('p.muted','Com o que você informou, seus compromissos passam do saldo em'), h('strong', money(-sp.free)), h('p.muted','O Bivvo vai ajudar você a enxergar o que precisa ser ajustado primeiro.'))
    : h('div.onb-result', h('p.muted','Com o que você informou, você tem aproximadamente'), h('strong', money(sp.free)), h('p.muted',`livres até ${sp.next.source === 'mes' ? 'o fim do mês' : 'o próximo dinheiro'} — cerca de ${money(sp.perDay)} por dia.`));
  store.commit(s => { s.profile.activationValueSeen = true; s.profile.activationAt = s.profile.activationAt || new Date().toISOString(); }, { reason:'activation-value', silent:true });
  const sheet = openSheet({
    title: '🎉 Seu Bivvo está pronto',
    subtitle: 'Agora você já tem uma primeira visão do seu dinheiro.',
    content: result,
    footer: [h('button.btn.primary',{type:'button',onclick:()=>sheet.close()},'Ver meu painel')],
    label: 'Bivvo configurado'
  });
  adminTrack('first_value_shown','activation').catch(()=>{});
  adminTrack('activation_completed','activation').catch(()=>{});
}

function undoSave(ids, insts) {
  if (!ids.length) return;
  store.markDeleted(ids, insts);
  store.commit(s => {
    const drop = new Set(ids), dropInst = new Set(insts);
    s.transactions = s.transactions.filter(t => !drop.has(t.id));
    s.installments = s.installments.filter(i => !dropInst.has(i.id));
  });
  toast('Desfeito. Nada foi salvo.');
}

/* ---------------- prévia compartilhada ---------------- */
function previewBox() {
  const box = h('div.qc-preview', { 'aria-live': 'polite' });
  const st = { cat: null, card: null };
  box.paint = p => {
    box.replaceChildren();
    if (!p || p.error) { box.classList.add('empty'); box.append(h('small', p?.error && box.dataset.touched ? p.error : 'Exemplos: mercado 45 · ifood 32 nubank · tv 3x 900 · farmácia 20 ontem')); return; }
    box.classList.remove('empty');
    const s = S();
    const cats = store.categories(p.type, s);
    if (st.cat && !cats.includes(st.cat)) st.cat = null;
    const catSel = h('select.qc-chip', { 'aria-label': 'Categoria' }, cats.map(c => h('option', { value: c }, `${catIcon(c)} ${c}`)));
    catSel.value = st.cat || p.cat; if (!catSel.value) catSel.value = cats[0];
    catSel.addEventListener('change', () => { st.cat = catSel.value; });
    const meta = [catSel, h('span.qc-chip.static', p.date === today() ? 'Hoje' : dayLabel(p.date))];
    if (p.card) {
      const cardSel = h('select.qc-chip', { 'aria-label': 'Cartão' }, s.cards.map(c => h('option', { value: c.name }, `💳 ${c.name}`)));
      cardSel.value = st.card || p.card.name;
      cardSel.addEventListener('change', () => { st.card = cardSel.value; });
      meta.push(cardSel);
      if (p.parts > 1) meta.push(h('span.qc-chip.static', `${p.parts}x de ${money(p.value / p.parts)}`));
    } else if (p.type === 'expense') meta.push(h('span.qc-chip.static', p.future ? 'Agendado' : `${p.method === 'Débito' ? 'Débito' : p.method === 'Dinheiro' ? 'Dinheiro' : 'Pix'} · pago`));
    else meta.push(h('span.qc-chip.static.in', 'Entrada'));
    box.append(h('div.qc-main', h('b', p.desc), h('strong' + (p.type === 'income' ? '.in' : ''), (p.type === 'income' ? '+ ' : '− ') + money(p.value))), h('div.qc-meta', meta));
    if (p.needsCard) box.append(h('small.qc-note', 'Para parcelar, cadastre um cartão. Por enquanto vai como gasto à vista.'));
    if (p.card && p.cardGuessed) box.append(h('small.qc-note', 'Confira o cartão antes de salvar.'));
  };
  box.choices = () => ({ cat: st.cat, cardName: st.card });
  box.reset = () => { st.cat = null; st.card = null; };
  return box;
}

/* ---------------- barra fixa da Início ---------------- */
let draft = '', hadFocus = false;
export function captureBar() {
  const input = h('input.qc-input', { type: 'text', inputmode: 'text', enterKeyHint: 'done', autocomplete: 'off', autocapitalize: 'none', spellcheck: false, placeholder: 'Ex.: mercado 45 ou iFood 32 no Nubank', 'aria-label': 'Anotar gasto ou entrada' });
  const btn = h('button.qc-save', { type: 'submit', 'aria-label': 'Salvar' }, 'Salvar');
  const preview = previewBox();
  const mic = h('button.qc-mic', { type: 'button', 'aria-label': voiceSupported() ? 'Falar o gasto' : 'Entrada por voz indisponível neste navegador', disabled: !voiceSupported(), onclick: () => openSmartCapture({ voice: true }) }, '🎙');
  const camera = h('button.qc-mic.qc-camera', { type: 'button', 'aria-label': 'Escanear comprovante com a câmera', onclick: () => startScan() }, '📷');
  const wrap = h('form.card.qc-bar', { onsubmit: e => { e.preventDefault(); save(); } },
    h('div.qc-row', h('span.qc-bolt', { 'aria-hidden': 'true' }, '⚡'), input, mic, camera, btn), preview);
  const paint = () => {
    draft = input.value;
    const has = !!input.value.trim();
    wrap.classList.toggle('open', has);
    btn.disabled = !has;
    preview.dataset.touched = has ? '1' : '';
    preview.paint(has ? parse(input.value) : null);
  };
  input.addEventListener('input', () => { preview.reset(); paint(); });
  input.addEventListener('focus', () => { hadFocus = true; setTimeout(() => wrap.scrollIntoView({ block: 'center', behavior: 'smooth' }), 250); });
  input.addEventListener('blur', () => { setTimeout(() => { if (document.activeElement !== input) hadFocus = false; }, 0); });
  function save() {
    const p = parse(input.value);
    if (p.error) { preview.dataset.touched = '1'; preview.paint(p); input.focus(); return; }
    const choice = preview.choices();
    draft = ''; hadFocus = false;
    input.blur();
    saveParsed(p, choice);
  }
  input.value = draft; paint();
  if (hadFocus) requestAnimationFrame(() => { input.focus(); const n = input.value.length; try { input.setSelectionRange(n, n); } catch { /* ignore */ } });
  return wrap;
}

/* ---------------- folha rápida (botão +, atalho e lembrete) ---------------- */
export function openSmartCapture({ startup = false, onDisable, voice = false } = {}) {
  const input = h('input.input.qc-input-lg', { type: 'text', inputmode: 'text', enterKeyHint: 'done', autocomplete: 'off', autocapitalize: 'none', spellcheck: false, placeholder: 'Ex.: mercado 45 ou iFood 32 no Nubank', autofocus: true, 'aria-label': 'Digite o gasto ou entrada' });
  const preview = previewBox();
  let parsed = null, spoken = false, source = 'text', listening = null;
  const paint = () => { parsed = parse(input.value, { spoken }); preview.dataset.touched = input.value.trim() ? '1' : ''; preview.paint(input.value.trim() ? parsed : null); };
  input.addEventListener('input', () => { spoken = false; source = 'text'; preview.reset(); paint(); });
  const voiceMsg = h('p.qc-voice-msg', { role: 'status' });
  const micBtn = h('button.qc-tool', { type: 'button', onclick: () => toggleVoice() }, h('span', { 'aria-hidden': 'true' }, '🎙'), 'Falar');
  const scanBtn = h('button.qc-tool', { type: 'button', 'aria-label': 'Abrir câmera para escanear comprovante', onclick: () => { sheet.close(); setTimeout(() => startScan(), 150); } }, h('span', { 'aria-hidden': 'true' }, '📷'), 'Câmera');
  function toggleVoice() {
    if (listening) { listening.stop(); return; }
    micBtn.classList.add('on'); voiceMsg.textContent = 'Ouvindo… ex.: "gastei 87 no mercado no pix"';
    listening = listen({
      onText: t => { input.value = t; spoken = true; source = 'voice'; preview.reset(); paint(); },
      onEnd: () => { listening = null; micBtn.classList.remove('on'); voiceMsg.textContent = input.value ? 'Confira e toque em Salvar.' : ''; },
      onError: m => { listening = null; micBtn.classList.remove('on'); voiceMsg.textContent = m; }
    });
  }
  const tools = h('div.qc-tools', voiceSupported() ? micBtn : null, scanBtn);
  const details = h('button.link.sm', { type: 'button', onclick: () => {
    const p = parsed && !parsed.error ? parsed : {};
    const c = preview.choices();
    sheet.close();
    setTimeout(async () => { const { openTxForm } = await import('./views/forms.js'); openTxForm({ mode: p.card ? 'card' : p.type || 'expense', preset: { value: p.value, desc: p.desc, cat: c.cat || p.cat, card: c.cardName || p.card?.name, date: p.date, parts: p.parts } }); }, 120);
  } }, 'Adicionar detalhes');
  const links = h('div.qc-links', details, startup ? h('button.link.sm.muted-link', { type: 'button', onclick: () => { sheet.close(); onDisable?.(); } }, 'Não lembrar à noite') : null);
  const form = h('form.form.qc-sheet', { onsubmit: e => { e.preventDefault(); save(); } }, input, tools, voiceMsg, preview, links, h('button.hidden-submit', { type: 'submit', tabindex: '-1', 'aria-hidden': 'true' }));
  const footer = [h('button.btn.ghost', { type: 'button', onclick: () => sheet.close() }, startup ? 'Agora não' : 'Cancelar'), h('button.btn.primary', { type: 'button', onclick: () => form.requestSubmit() }, 'Salvar')];
  const sheet = openSheet({ title: startup ? 'Vamos registrar seu primeiro gasto?' : 'Anotar em 2 segundos', subtitle: startup ? 'Digite do seu jeito. O Bivvo organiza para você.' : 'Descrição e valor. Data, cartão e parcelas são opcionais.', content: form, footer, label: 'Anotação rápida' });
  paint();
  function save() {
    paint();
    if (!parsed || parsed.error) { preview.dataset.touched = '1'; preview.paint(parsed); input.focus(); return; }
    const c = preview.choices();
    listening?.stop();
    sheet.close();
    saveParsed(parsed, { ...c, source });
  }
  if (voice) setTimeout(() => toggleVoice(), 300);
  return sheet;
}

/* ---------------- lembrete ao abrir: só à noite e só se nada foi anotado hoje ---------------- */
const localISO = ms => { const d = new Date(ms); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
export function loggedToday(s = S()) {
  const t0 = today();
  return s.transactions.some(t => !t.demoSeed && !t.fixedId && !t.recurringKey && t.kind !== 'opening' && !t.loanId && t.createdAt && localISO(t.createdAt) === t0);
}
export function shouldOfferEveningCapture({ demo }) {
  const s = S();
  if (demo || !s.profile.onboarded || s.profile.eveningCapture === false) return false;
  if (new Date().getHours() < 18) return false;
  if (loggedToday(s)) return false;
  try { if (localStorage.getItem('bivvo_evening_capture') === today()) return false; } catch { /* modo privado */ }
  return true;
}
export function markEveningCaptureShown() { try { localStorage.setItem('bivvo_evening_capture', today()); } catch { /* ignore */ } }

/* ---------------- comprovante: escolher → ler → CONFIRMAR ---------------- */
export async function startScan(file) {
  const [{ pickImage, captureSmartReceipt, readReceipt }, { openScanConfirm, openScanUnavailable }, cloud, { openPaywall }] = await Promise.all([import('./scan.js?v=11.43.0'), import('./views/scanconfirm.js?v=11.43.0'), import('./cloud.js'), import('./views/pro.js')]);
  if (store.isDemo() || !cloud.currentUser()) { openScanUnavailable('demo'); return; }
  const accepted = await confirmSheet({title:'Ler comprovante com IA', message:'A foto será enviada ao Google Gemini para extrair os campos. Ela pode conter nomes, CPF e outras informações pessoais. O Bivvo não salva a imagem no servidor. Você poderá conferir a foto e os campos antes de salvar.', confirmLabel:'Enviar foto para análise',cancelLabel:'Cancelar'});
  if (!accepted) return;
  adminTrack('receipt_scanner_opened', 'scan').catch(()=>{});
  if (!file) { try { if (!localStorage.getItem('bivvo_scan_tip_v4')) { toast('Dica: enquadre o comprovante inteiro. O Bivvo usa uma única foto e faz várias conferências internas automaticamente.'); localStorage.setItem('bivvo_scan_tip_v4', '1'); } } catch { /* ignore */ } }
  const f = file || await captureSmartReceipt().catch(() => pickImage());
  if (!f) return;
  const busy = toastBusy('Analisando uma foto e conferindo os dados…');
  const r = await readReceipt(f).catch(e => ({ ok: false, error: e.message }));
  busy();
  if (r.ok) { adminTrack('receipt_scanner_completed', 'scan').catch(()=>{}); const previewUrl=URL.createObjectURL(f); openScanConfirm(r.data,{previewUrl,onClose:()=>URL.revokeObjectURL(previewUrl)}); return; }
  track('scan_failed', { result: r.code || 'error' });
  adminTrack('receipt_scanner_failed', 'scan', { error_type: r.code || 'error', error_message: r.error || '' }).catch(()=>{});
  if (r.code === 'quota') { openPaywall({ feature: 'scan', usage: r.usage }); return; }
  if (r.code === 'not_configured') { openScanUnavailable('server'); return; }
  toast(r.error || 'Não foi possível ler agora. Digite o valor.', { tone: 'warn', action: { label: 'Digitar', fn: () => openSmartCapture() } });
}
function toastBusy(text) { toast(text); const t = setInterval(() => toast(text), 2400); return () => clearInterval(t); }
