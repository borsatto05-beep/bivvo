/* Bivvo Scan — confirmação. Uma leitura NUNCA vira lançamento sem o toque em "Confirmar". */
import { h, money, today } from '../util.js';
import * as store from '../store.js';
import { openSheet, catIcon, field } from '../ui.js';
import { moneyInput } from './forms.js';
import { saveParsed, openSmartCapture } from '../quickcapture.js';
import { toNumber } from '../quickparse.js';

const METHODS = ['PIX', 'Débito', 'Crédito', 'Dinheiro', 'Boleto', 'Transferência'];
const norm = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9 ]/g,' ').replace(/\s+/g,' ').trim();
const LABELS = { value:'valor', merchant:'estabelecimento', date:'data', method:'forma de pagamento', category:'categoria' };

function similarText(a,b){
  const A=norm(a), B=norm(b); if(!A||!B)return false; if(A===B||A.includes(B)||B.includes(A))return true;
  const aa=new Set(A.split(' ').filter(x=>x.length>2)), bb=B.split(' ').filter(x=>x.length>2);
  return bb.some(x=>aa.has(x));
}
function potentialDuplicate(s,{value,date,desc}){
  if(!(Number(value)>0)||!date)return null;
  const tx=(s.transactions||[]).filter(t=>t.type==='expense'&&t.date===date&&Math.abs(Number(t.value||0)-Number(value))<0.009);
  return tx.find(t=>similarText(t.desc,desc)) || (tx.length===1 && tx[0].captureSource==='scan' ? tx[0] : null);
}
function confidenceWord(n){ return n>=.88?'alta':n>=.68?'média':'baixa'; }

export function openScanConfirm(d, { previewUrl = null, onClose = null } = {}) {
  const s = store.getState();
  const value = moneyInput(d.value, { big: true, label: 'Valor' });
  const descText = d.merchant || d.description || 'Compra';
  const desc = h('input.input', { type: 'text', maxLength: 60, value: descText, 'aria-label': 'Descrição' });
  const cats = store.categories('expense', s);
  const guess = store.autoCategory(descText, 'expense', s) || cats.find(c => norm(c) === norm(d.categoryHint)) || cats.find(c => d.categoryHint && norm(c).startsWith(norm(d.categoryHint).slice(0, 5))) || 'Outros';
  const cat = h('select.input', { 'aria-label': 'Categoria' }, cats.map(c => h('option', { value: c }, `${catIcon(c)} ${c}`))); cat.value = cats.includes(guess) ? guess : cats[0];
  const date = h('input.input', { type: 'date', value: d.date && d.date <= today() ? d.date : today(), max: today(), 'aria-label': 'Data' });
  const method = h('select.input', { 'aria-label': 'Forma de pagamento' }, METHODS.filter(m => m !== 'Crédito' || s.cards.length).map(m => h('option', { value: m }, m)));
  method.value = d.method && (d.method !== 'Crédito' || s.cards.length) ? d.method : 'PIX';
  const card = h('select.input', { 'aria-label': 'Cartão' }, s.cards.map(c => h('option', { value: c.name }, c.name)));
  const parts = h('select.input', { 'aria-label': 'Parcelas' }, Array.from({ length: 48 }, (_, i) => h('option', { value: i + 1 }, i ? `${i + 1}x` : 'À vista')));
  parts.value = String(d.installments || 1);
  const creditRow = h('div.row2', field('Cartão', card), field('Parcelas', parts, 'O valor é o total da compra.'));
  const paintCredit = () => { creditRow.hidden = method.value !== 'Crédito'; };
  method.addEventListener('change', paintCredit); paintCredit();

  const options = Array.isArray(d.valueOptions) ? [...new Set(d.valueOptions.filter(v => Number(v) > 0).map(v => Math.round(Number(v) * 100) / 100))].slice(0, 3) : [];
  const issues = Array.isArray(d.qualityIssues) ? d.qualityIssues : [];
  const issueText = issues.includes('possibly_blurry') ? 'A foto parece um pouco desfocada.'
    : issues.includes('glare') ? 'Havia reflexo forte no papel.'
    : issues.includes('too_dark') ? 'A foto ficou escura.'
    : issues.includes('too_bright') ? 'A foto ficou clara demais.'
    : issues.includes('low_contrast') ? 'O texto está com pouco contraste.'
    : issues.includes('low_resolution') ? 'A foto ficou pequena ou distante.' : '';
  const review = Array.isArray(d.reviewFields) ? d.reviewFields.filter(x=>LABELS[x]) : [];
  const careful = d.mismatch || d.confidence < 0.72 || d.value == null || options.length > 1 || review.includes('value');
  const msg = h('p.form-msg', { role: 'alert' });
  const choices = options.length > 1 ? h('div.scan-choices',
    h('small', 'Encontrei mais de um valor possível. Toque no total correto:'),
    h('div.chips', options.map(v => h('button.chip', { type: 'button', onclick: () => { value.value = Number(v).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); msg.textContent = `Valor selecionado: ${money(v)}`; } }, money(v))))) : null;
  const readHint = d.value == null ? 'Não consegui ler o total com segurança. Digite abaixo — não precisa tirar outra foto.'
    : options.length > 1 ? 'Compare as opções abaixo e escolha o total correto.'
    : careful ? 'Confira o valor com atenção antes de salvar.' : 'Leitura concluída. Confira e salve.';

  const meta = h('div.scan-meta',
    d.receiptType ? h('span.scan-meta-chip', d.receiptType) : null,
    h('span.scan-meta-chip', `Consistência da leitura: ${confidenceWord(Number(d.confidence)||0)}`),
    d.scanMeta?.oneShot ? h('span.scan-meta-chip.good','1 foto') : null,
    Number(d.scanMeta?.consensusCount||0) >= 2 ? h('span.scan-meta-chip.good','Comparado em 2 leituras') : null,
    d.scanMeta?.judgeUsed && !d.reviewFields?.includes('value') ? h('span.scan-meta-chip.good','Conflito conferido') : null,
    d.scanMeta?.qrAmountMatches ? h('span.scan-meta-chip','Valor visual coincide com QR de cobrança') : null,
    d.scanMeta?.perspectiveCorrected ? h('span.scan-meta-chip.good','Enquadramento corrigido') : null,
    d.scanMeta?.qrDetected ? h('span.scan-meta-chip.good','QR detectado') : null);
  const reviewBox = review.length ? h('div.scan-review', h('b','Confira estes campos:'), h('span', review.map(x=>LABELS[x]).join(', '))) : h('div.scan-review.good', h('b','Leitura consistente'), h('span','Mesmo assim, confirme antes de salvar.'));
  const initialDup = potentialDuplicate(s,{value:d.value,date:d.date||today(),desc:descText});
  const dupBox = initialDup ? h('div.scan-duplicate', h('b','Possível compra duplicada'), h('span',`${initialDup.desc} · ${money(initialDup.value)} · ${initialDup.date}`), h('small','Confira antes de registrar novamente.')) : null;

  const sheet = openSheet({
    title: 'Confirmar lançamento', onClose, subtitle: d.autoRetried ? 'O Bivvo comparou análises da mesma foto. Confira os campos destacados.' : 'Lido de uma única foto. Confira antes de salvar.',
    content: h('div.form.scan-confirm',
      previewUrl ? h('img.scan-preview', {src:previewUrl,alt:'Foto do comprovante para conferir os campos'}) : null,
      meta,
      h('div.scan-read' + (careful ? '.warn' : ''),
        h('small', d.valueLabel ? `Valor identificado em “${d.valueLabel}”` : 'Valor lido no comprovante'),
        h('b', d.valueText || (d.value != null ? money(d.value) : 'não identificado')),
        h('small', readHint),
        issueText ? h('small.scan-quality', `${issueText} O Bivvo tentou corrigir a imagem automaticamente.`) : null),
      choices, reviewBox, dupBox,
      field('Valor da compra', value), field('Descrição', desc), h('div.row2', field('Categoria', cat), field('Data', date)), field('Forma de pagamento', method), creditRow, msg,
      h('p.hint', 'A foto fica apenas nesta revisão e será descartada ao fechar. Se algum campo estiver errado, corrija aqui — não precisa fotografar novamente.')),
    footer: [h('button.btn.ghost', { type: 'button', onclick: () => edit() }, 'Editar mais'), h('button.btn.primary', { type: 'button', onclick: () => confirm() }, initialDup ? 'Registrar mesmo assim' : 'Confirmar')]
  });
  for (const [key, input] of [['value',value],['merchant',desc],['date',date],['method',method],['category',cat]]) {
    if (review.includes(key)) { input.classList.add('scan-field-review'); input.setAttribute('aria-describedby','scan-review-help'); }
  }
  reviewBox.id = 'scan-review-help';
  if (careful) setTimeout(() => value.focus(), 120);
  const build = () => {
    const v = value.getValue();
    if (!(v > 0)) { msg.textContent = 'Informe o valor da compra.'; value.focus(); return null; }
    if (!date.value || date.value > today() || !Number.isFinite(Date.parse(date.value))) { msg.textContent='Informe uma data válida até hoje.'; date.focus(); return null; }
    const isCredit = method.value === 'Crédito' && s.cards.length;
    const c = isCredit ? s.cards.find(x => x.name === card.value) || s.cards[0] : null;
    return { value: v, desc: desc.value.trim() || 'Compra', type: 'expense', cat: cat.value, date: date.value || today(), parts: isCredit ? Number(parts.value) : 1, card: c, future: false, method: isCredit ? 'Crédito' : method.value };
  };
  function confirm() { const p = build(); if (!p) return; sheet.close(); saveParsed(p, { cat: p.cat, cardName: p.card?.name, source: 'scan' }); }
  async function edit() {
    const p = build(); sheet.close();
    const { openTxForm } = await import('./forms.js');
    setTimeout(() => openTxForm({ mode: p?.card ? 'card' : 'expense', preset: p ? { value: p.value, desc: p.desc, cat: p.cat, date: p.date, card: p.card?.name, parts: p.parts } : {} }), 150);
  }
}

export function openScanUnavailable(reason) {
  const text = reason === 'demo' ? 'A leitura de comprovantes usa sua conta (são 5 leituras grátis por mês). Na demonstração, digite ou fale o gasto.'
    : 'A leitura de comprovantes ainda não foi ativada neste Bivvo. Enquanto isso, digite ou fale o gasto.';
  const sheet = openSheet({ title: 'Leitura de comprovante', content: h('p.sheet-text', text),
    footer: [h('button.btn.ghost', { type: 'button', onclick: () => sheet.close() }, 'Fechar'), h('button.btn.primary', { type: 'button', onclick: () => { sheet.close(); setTimeout(() => openSmartCapture(), 150); } }, 'Digitar o gasto')] });
}
