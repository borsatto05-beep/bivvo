import {readdirSync,readFileSync,writeFileSync,mkdirSync,rmSync,copyFileSync} from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const root=path.resolve('.'),out=path.join(root,'dist');
const excluded=new Set(['dist','netlify','tests','scripts','node_modules','.git','_seo','work','output']);
const allowed=/\.(html|css|js|png|jpe?g|svg|ico|woff2?|webmanifest|xlsx|xml)$/i;
const paths=[];
function visit(dir,rel='') {
 for (const e of readdirSync(dir,{withFileTypes:true})) {
  const sub=path.posix.join(rel,e.name);
  if(e.isSymbolicLink()) throw new Error('Symlink not allowed: '+sub);
  if(e.isDirectory()) {if(!excluded.has(e.name)&&!e.name.startsWith('.'))visit(path.join(dir,e.name),sub);}
  else if((allowed.test(e.name)&&e.name!=='sw.js') || sub==='js/vendor/LICENSE-supabase.txt' || (!rel&&['_headers','_redirects','robots.txt','llms.txt'].includes(e.name)) || (!rel&&/^[a-f0-9]{32}\.txt$/.test(e.name))) paths.push(sub);
 }
}
visit(root);rmSync(out,{recursive:true,force:true});mkdirSync(out,{recursive:true});
for(const p of paths) {mkdirSync(path.dirname(path.join(out,p)),{recursive:true});copyFileSync(path.join(root,p),path.join(out,p));}
// Content-derived cache identity: even an accidental same-version deploy gets its own complete shell.
const shell=paths.filter(p=>/\.(html|css|js|woff2?|png|svg|ico|webmanifest)$/.test(p)).sort();
const hash=crypto.createHash('sha256');for(const p of shell)hash.update(p).update(readFileSync(path.join(root,p)));
const release=hash.digest('hex').slice(0,16);
const sw=readFileSync('sw.js','utf8').replace("const VERSION = 'bivvo-v11-43-0';",`const VERSION = 'bivvo-v11-43-0-${release}';`).replace("/* BUILD_PRECACHE */ ['./', './index.html', './app.css?v=11.43.0', './js/main.js?v=11.43.0']",JSON.stringify(shell.map(p=>({url:'/'+p,sha256:crypto.createHash('sha256').update(readFileSync(path.join(root,p))).digest('hex')}))));
writeFileSync(path.join(out,'sw.js'),sw);
writeFileSync('build-manifest.json',JSON.stringify({version:'11.43.0',release,files:paths.length,precache:shell.length},null,2)+'\n');
console.log(`Built ${paths.length+1} public files; ${shell.length} precached assets; release ${release}`);
