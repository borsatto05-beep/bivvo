import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url),fn=require('../netlify/functions/scan-receipt.js');
process.env.SUPABASE_SECRET_KEY='test';process.env.GEMINI_API_KEY='test';
let mode='conflict',reader=0,consumed=0,refunded=0;
const saved=global.fetch;
const image=Buffer.concat([Buffer.from([255,216,255]),Buffer.alloc(900)]).toString('base64');
const event={httpMethod:'POST',headers:{authorization:'Bearer test'},body:JSON.stringify({images:[{mediaType:'image/jpeg',image}],diagnostics:{issues:[]}})};
global.fetch=async(url,opts={})=>{
 if(url.endsWith('/auth/v1/user'))return Response.json({id:'user'});
 if(url.includes('/rpc/bivvo_rate_limit'))return Response.json(true);
 if(url.includes('/entitlements?'))return Response.json([]);
 if(url.includes('/rpc/bivvo_consume_usage')){consumed++;return Response.json(1);}
 if(url.includes('/rpc/bivvo_refund_usage')){refunded++;return new Response(null,{status:204});}
 if(url.includes('generativelanguage.googleapis.com')){
  reader++;
  assert(JSON.parse(opts.body).generationConfig.responseSchema.properties.is_receipt);
  if(mode==='failure')return new Response('',{status:503});
  if(mode==='one-reader-fails' && reader===2)return new Response('',{status:503});
  const value=mode==='conflict' ? (reader===1?20:reader===2?30:null) : 20;
  const raw={is_receipt:true,value,value_text:value!=null?`R$ ${value},00`:null,merchant:'Synthetic Store',confidence:.96,confidence_value:.96,evidence_value:value!=null?'TOTAL '+value:null};
  return Response.json({candidates:[{content:{parts:[{text:JSON.stringify(raw)}]}}],usageMetadata:{promptTokenCount:100,candidatesTokenCount:30}});
 }
 throw new Error('Unexpected '+url);
};
try{
 const invalid=await fn.handler({...event,body:JSON.stringify({images:[{mediaType:'image/jpeg',image:'A'.repeat(1200)}]})});
 assert.equal(invalid.statusCode,400);assert.equal(consumed,0);
 let response=await fn.handler(event);assert.equal(response.statusCode,200);assert.equal(JSON.parse(response.body).data.value,null);assert.equal(consumed,1);assert.equal(refunded,0);
 mode='failure';reader=0;response=await fn.handler(event);assert.equal(response.statusCode,504);assert.equal(refunded,1);
 mode='one-reader-fails';reader=0;response=await fn.handler(event);assert.equal(response.statusCode,200);assert.equal(JSON.parse(response.body).data.value,20);
 process.env.GEMINI_SCAN_READER_MODE='adaptive';mode='valid';reader=0;response=await fn.handler(event);assert.equal(response.statusCode,200);assert.equal(reader,1);
 assert.equal(JSON.parse(response.body).data.scanMeta.readers,1);
}finally{global.fetch=saved;delete process.env.GEMINI_SCAN_READER_MODE;}
console.log('Scan handler: image signatures, one quota, conflicts, refunds, partial provider failure and adaptive mode passed.');
