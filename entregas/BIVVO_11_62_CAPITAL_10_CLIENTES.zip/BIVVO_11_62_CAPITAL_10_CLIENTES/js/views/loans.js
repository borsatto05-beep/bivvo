import { h, money, today, uid, round2, parseMoney, addMonthsDate, addMonthsYM, diffDays, ymOf, monthShort, monthLabel, shortDate } from '../util.js';
import * as store from '../store.js';
import { openSheet, field, toast, confirmSheet } from '../ui.js';
import { donut, bars, progressBar } from '../charts.js';
import { ctx, rerender } from '../nav.js';
import {loanShareText,loanShareSummary} from '../loan-share.js';
import { ensureLoanLedger, loanCapacity, recalculateLoan, relatedPaymentTransactions, findAutoRenewCycle } from '../loan-ledger.js';

const S=()=>store.getState();
const baseInterest=l=>l.interestMode==='fixed'?Number(l.interestFixed||0):round2(Number(l.principal||0)*Number(l.interestRate||0)/100);
const interestDue=l=>Math.max(0,round2((l.interestDue != null ? l.interestDue : baseInterest(l))));
const totalDue=l=>round2(Number(l.principal||0)+interestDue(l));
const isPaid=l=>l.status==='paid'||totalDue(l)<=0.004;
const overdueDays=l=>!isPaid(l)&&l.due&&l.due<today()?Math.max(1,diffDays(l.due,today())):0;
const loanStatus=l=>isPaid(l)?{key:'paid',label:'Quitado'}:overdueDays(l)?{key:'overdue',label:`Vencido há ${overdueDays(l)} dia${overdueDays(l)>1?'s':''}`}:(l.due===today()?{key:'today',label:'Vence hoje'}:{key:'open',label:'Em dia'});
const paidFor=(s,id)=>(s.loanPayments||[]).filter(p=>p.loanId===id);
const principalRecovered=(s,l)=>paidFor(s,l.id).reduce((a,p)=>a+Number(p.principal||0),0);
const interestReceived=(s,l)=>paidFor(s,l.id).reduce((a,p)=>a+Number(p.interest||0),0);
const paymentLabel=p=>Number(p.principal||0)<=0.004&&Number(p.interest||0)>0.004?'Pagamento só de juros':'Pagamento recebido';

function shareLoan(id){
  const loan=S().loans.find(x=>x.id===id);
  if(!loan){toast('Empréstimo não encontrado.');return;}
  const text=loanShareText(loan),summary=loanShareSummary(loan),box=h('textarea.input',{readOnly:true,rows:12,'aria-label':'Mensagem para o cliente'},text);
  const row=(label,value)=>h('div.loan-share-row',h('span',label),h('strong',value));
  const preview=h('section.loan-share-card',{'aria-label':'Resumo para o cliente'},
    h('div.loan-share-heading',h('span',{'aria-hidden':'true'},'📋'),h('div',h('small','RESUMO DO EMPRÉSTIMO'),h('h3',loan.person))),
    h('div.loan-share-total',h('span',summary.paid?'Empréstimo quitado':'Total a pagar'),h('strong',money(summary.total)),h('span.loan-share-due','📅 Vencimento: '+summary.due)),
    h('div.loan-share-breakdown',row('💵 Valor emprestado',money(summary.original)),row('📈 Juros combinados',summary.terms),summary.principal!==summary.original?row('✅ Valor já devolvido',money(Math.max(0,round2(summary.original-summary.principal)))):null),
    h('div.loan-share-breakdown',h('h4','O que falta pagar'),row('Valor emprestado restante',money(summary.principal)),row('Juros a pagar',money(summary.interest))),
    h('p.muted.sm',summary.paid?'Tudo certo: não há saldo pendente.':'O total já considera os pagamentos registrados.'));
  const message=h('details.loan-share-message',h('summary','Ver mensagem que será enviada'),box);
  const content=h('div.loan-share-content',preview,message);
  const copy=async()=>{try{await navigator.clipboard.writeText(text);toast('Mensagem copiada.');}catch{message.open=true;box.focus();box.select();toast('Selecione e copie a mensagem para enviar.');}};
  const actions=[h('a.btn.primary',{href:'https://wa.me/?text='+encodeURIComponent(text),target:'_blank',rel:'noopener noreferrer'},'Enviar pelo WhatsApp'),h('button.btn',{type:'button',onclick:copy},'Copiar mensagem')];
  if(navigator.share)actions.unshift(h('button.btn',{type:'button',onclick:async()=>{try{await navigator.share({title:'Resumo do empréstimo',text});}catch(e){if(e.name!=='AbortError')toast('Não foi possível compartilhar. Use WhatsApp ou copie a mensagem.');}}},'Compartilhar'));
  openSheet({title:'Compartilhar empréstimo',subtitle:'Confira os valores e escolha como enviar ao cliente.',content,footer:actions});
}

function newLoan(){
  const person=h('input.input',{placeholder:'Nome da pessoa',maxlength:60}), principal=h('input.input',{inputmode:'decimal',placeholder:'0,00'}), mode=h('select.input',h('option',{value:'percent'},'Percentual (%)'),h('option',{value:'fixed'},'Valor fixo (R$)')), interest=h('input.input',{inputmode:'decimal',placeholder:'10'}), periodicity=h('select.input',h('option',{value:'monthly'},'Mensal'),h('option',{value:'single'},'Único')), due=h('input.input',{type:'date',value:today()}), note=h('textarea.input',{rows:2,placeholder:'Observação (opcional)',maxlength:180}), preview=h('div.loan-preview'), msg=h('p.form-msg');
  const update=()=>{const p=parseMoney(principal.value),v=parseMoney(interest.value),i=mode.value==='fixed'?v:round2(p*v/100);preview.replaceChildren(h('small','PRÉVIA'),h('div.loan-preview-grid',h('span','Principal',h('b',money(p))),h('span','Juros',h('b',money(i))),h('span','Total a receber',h('b',money(p+i)))));};
  [principal,interest,mode].forEach(x=>x.addEventListener('input',update)); update();
  const sh=openSheet({title:'Novo empréstimo',subtitle:'Principal e juros ficam separados para não inflar sua renda.',content:h('div.form',field('Pessoa',person),field('Valor principal',principal),field('Tipo de juros',mode),field('Juros',interest),field('Periodicidade',periodicity),field('Vencimento',due),field('Observação',note),preview,msg),footer:[h('button.btn.primary',{type:'button',onclick:()=>{const p=parseMoney(principal.value),v=parseMoney(interest.value);if(!person.value.trim()||p<=0||v<0||!due.value){msg.textContent='Informe pessoa, valor e vencimento.';return;}store.commit(s=>{const id=uid(), l={id,person:person.value.trim(),principalOriginal:p,principal:p,interestMode:mode.value,interestRate:mode.value==='percent'?v:0,interestFixed:mode.value==='fixed'?v:0,periodicity:periodicity.value,due:due.value,initialDue:due.value,status:'open',note:note.value.trim(),createdAt:Date.now()};l.interestDue=baseInterest(l);s.loans.push(l);s.loanCycles.push({id:uid(),loanId:id,date:today(),due:l.due,principal:p,interest:l.interestDue,type:'created',createdAt:Date.now()});});sh.close();toast('Empréstimo registrado.');}},'Salvar')]});
}

function editLoan(l, parentSheet){
  const s=S(), payments=paidFor(s,l.id), hasPayments=payments.length>0;
  const person=h('input.input',{value:l.person||'',maxlength:60,placeholder:'Nome da pessoa'}),
    principal=h('input.input',{inputmode:'decimal',value:String((l.principalOriginal != null ? l.principalOriginal : (l.principal != null ? l.principal : 0))).replace('.',','),disabled:hasPayments}),
    mode=h('select.input',h('option',{value:'percent'},'Percentual (%)'),h('option',{value:'fixed'},'Valor fixo (R$)')),
    interest=h('input.input',{inputmode:'decimal'}),
    periodicity=h('select.input',h('option',{value:'monthly'},'Mensal'),h('option',{value:'single'},'Único')),
    due=h('input.input',{type:'date',value:l.due||today()}),
    note=h('textarea.input',{rows:3,maxlength:180,placeholder:'Observação (opcional)'},l.note||''),
    preview=h('div.loan-preview'), msg=h('p.form-msg');
  mode.value=l.interestMode||'percent'; periodicity.value=l.periodicity||'monthly';
  interest.value=String(mode.value==='fixed'?(l.interestFixed||0):(l.interestRate||0)).replace('.',',');
  if(hasPayments){ mode.disabled=true; interest.disabled=true; periodicity.disabled=true; }
  const update=()=>{const p=hasPayments?Number(l.principal||0):parseMoney(principal.value),v=parseMoney(interest.value),i=mode.value==='fixed'?v:round2(p*v/100);preview.replaceChildren(h('small','PRÉVIA DO CONTRATO'),h('div.loan-preview-grid',h('span',hasPayments?'Principal atual':'Principal',h('b',money(p))),h('span','Juros do ciclo',h('b',money(i))),h('span','Total estimado',h('b',money(p+i)))));};
  [principal,interest,mode].forEach(x=>x.addEventListener('input',update)); update();
  const sh=openSheet({title:`Editar · ${l.person}`,subtitle:hasPayments?'Os pagamentos podem ser corrigidos ou excluídos pelo histórico. Para não reescrever contratos já movimentados, principal, taxa e periodicidade continuam fixos aqui.':'Você pode corrigir os dados financeiros enquanto ainda não houver pagamentos.',content:h('div.form',field('Pessoa',person),field('Valor principal',principal,hasPayments?'Edite pagamentos pelo histórico do empréstimo.':''),field('Tipo de juros',mode,hasPayments?'Fixo após o primeiro pagamento.':''),field('Juros',interest,hasPayments?'Fixo após o primeiro pagamento.':''),field('Periodicidade',periodicity,hasPayments?'Fixa após o primeiro pagamento.':''),field('Vencimento',due),field('Observação',note),preview,msg),footer:[h('button.btn.primary',{type:'button',onclick:()=>{const name=person.value.trim(),p=parseMoney(principal.value),v=parseMoney(interest.value);if(!name||(!hasPayments&&p<=0)||(!hasPayments&&v<0)||!due.value){msg.textContent='Revise pessoa, valor, juros e vencimento.';return;}store.commit(st=>{const loan=st.loans.find(x=>x.id===l.id);if(!loan)return;loan.person=name;loan.due=due.value;loan.note=note.value.trim();if(!hasPayments){loan.interestMode=mode.value;loan.interestRate=mode.value==='percent'?v:0;loan.interestFixed=mode.value==='fixed'?v:0;loan.periodicity=periodicity.value;loan.principalOriginal=p;loan.principal=p;loan.interestDue=baseInterest(loan);loan.initialDue=due.value;}for(const tx of st.transactions.filter(x=>x.loanId===loan.id)){if(tx.transactionRole==='loan_principal_out'){if(!hasPayments)tx.value=p;tx.desc=`Empréstimo para ${name}`;}else if(tx.transactionRole==='loan_principal_return')tx.desc=`Principal recebido · ${name}`;else if(tx.transactionRole==='loan_interest_income')tx.desc=`Juros recebidos · ${name}`;}if(!hasPayments){const created=st.loanCycles.find(c=>c.loanId===loan.id&&c.type==='created');if(created){created.principal=p;created.interest=loan.interestDue;created.due=loan.due;}}});sh.close();if(parentSheet && typeof parentSheet.close === 'function') parentSheet.close();toast('Empréstimo atualizado.');rerender();}},'Salvar alterações')]});
}

async function deleteLoan(l, parentSheet){
  const s=S(), payments=paidFor(s,l.id), txs=(s.transactions||[]).filter(x=>x.loanId===l.id), cycles=(s.loanCycles||[]).filter(x=>x.loanId===l.id);
  const hasPayments=payments.length>0;
  const ok=await confirmSheet({title:`Excluir contrato de ${l.person}?`,message:hasPayments?`Este contrato possui ${payments.length} pagamento${payments.length>1?'s':''}. Ao excluir, o contrato, pagamentos, lançamentos de principal/juros e ciclos associados serão removidos.`:'Ao excluir, o cadastro e os ciclos associados serão removidos.',confirmLabel:'Excluir contrato',danger:true,requireText:hasPayments?'EXCLUIR':''});
  if(!ok)return;
  store.markDeleted(l.id,payments.map(x=>x.id),txs.map(x=>x.id),cycles.map(x=>x.id));
  store.commit(st=>{st.loans=st.loans.filter(x=>x.id!==l.id);st.loanPayments=st.loanPayments.filter(x=>x.loanId!==l.id);st.loanCycles=st.loanCycles.filter(x=>x.loanId!==l.id);st.transactions=st.transactions.filter(x=>x.loanId!==l.id);});
  if(parentSheet && typeof parentSheet.close === 'function') parentSheet.close(); toast('Contrato e histórico removidos.');rerender();
}

function payLoan(l,{interestOnly=false}={}){
  const amount=h('input.input',{inputmode:'decimal',placeholder:'0,00'}), method=h('select.input',h('option',{value:'Transferência'},'Transferência'),h('option',{value:'PIX'},'PIX'),h('option',{value:'Dinheiro'},'Dinheiro'),h('option',{value:'Outro'},'Outro')), preview=h('div.loan-preview'), msg=h('p.form-msg');
  if(interestOnly&&interestDue(l)>0) amount.value=String(interestDue(l)).replace('.',',');
  const update=()=>{const a=Math.max(0,parseMoney(amount.value)), i=Math.min(a,interestDue(l)), p=interestOnly?0:Math.min(Number(l.principal||0),Math.max(0,a-i)), rest=round2(totalDue(l)-i-p);preview.replaceChildren(h('small',interestOnly?'RECEBIMENTO DE JUROS':'COMO O BIVVO VAI DISTRIBUIR'),h('div.loan-preview-grid',h('span','Juros',h('b',money(i))),h('span','Principal',h('b',money(p))),h('span','Restará',h('b',money(rest)))));};amount.addEventListener('input',update);update();
  let busy=false;
  const confirmBtn=h('button.btn.primary',{type:'button',onclick:async()=>{if(busy)return;const requested=parseMoney(amount.value), current=S().loans.find(x=>x.id===l.id);if(!current||isPaid(current)){msg.textContent='Este contrato já foi quitado ou não está mais disponível.';return;}const max=interestOnly?interestDue(current):totalDue(current);if(requested<=0){msg.textContent='Informe o valor recebido.';return;}if(requested>max+0.004){msg.textContent=`O máximo permitido aqui é ${money(max)}.`;return;}const a=Math.min(requested,max), i=Math.min(a,interestDue(current)), p=interestOnly?0:Math.min(current.principal,Math.max(0,a-i));busy=true;confirmBtn.disabled=true;const ok=await confirmSheet({title:interestOnly?'Confirmar recebimento de juros?':'Confirmar pagamento?',message:`Você está registrando ${money(round2(i+p))}: ${money(i)} em juros e ${money(p)} em principal. Depois você poderá corrigir ou excluir este lançamento pelo histórico do empréstimo.`,confirmLabel:'Confirmar',danger:false});if(!ok){busy=false;confirmBtn.disabled=false;return;}try{store.commit(s=>{const loan=s.loans.find(x=>x.id===l.id);if(!loan||isPaid(loan))return;ensureLoanLedger(s,loan.id);const amountNow=Math.min(requested,interestOnly?interestDue(loan):totalDue(loan)), interestNow=Math.min(amountNow,interestDue(loan)), principalNow=interestOnly?0:Math.min(loan.principal,Math.max(0,amountNow-interestNow));loan.interestDue=round2(interestDue(loan)-interestNow);loan.principal=round2(loan.principal-principalNow);const currentInterestCleared=loan.interestDue<=0.004;const shouldAutoRenew=loan.periodicity==='monthly'&&loan.principal>0.004&&currentInterestCleared;const pid=uid(), createdAt=Date.now();if(loan.principal<=0.004&&currentInterestCleared){loan.status='paid';loan.interestDue=0;}else if(shouldAutoRenew){const previousDue=loan.due||today();loan.due=addMonthsDate(previousDue,1);loan.status='open';const newInterest=baseInterest(loan);loan.interestDue=round2(newInterest);s.loanCycles.push({id:uid(),loanId:loan.id,paymentId:pid,date:today(),due:loan.due,principal:loan.principal,interest:newInterest,capitalized:0,type:'renewal',automatic:true,createdAt});}else loan.status='open';s.loanPayments.push({id:pid,loanId:loan.id,date:today(),amount:round2(interestNow+principalNow),interest:interestNow,principal:principalNow,method:method.value,autoRenewed:shouldAutoRenew,createdAt,editable:true});if(principalNow>0)s.transactions.push({id:uid(),loanId:loan.id,loanPaymentId:pid,transactionRole:'loan_principal_return',type:'income',value:principalNow,cat:'Juros / Empréstimo',date:today(),desc:`Principal recebido · ${loan.person}`,method:method.value,status:'Pago',createdAt});if(interestNow>0)s.transactions.push({id:uid(),loanId:loan.id,loanPaymentId:pid,transactionRole:'loan_interest_income',type:'income',value:interestNow,cat:'Juros / Empréstimo',date:today(),desc:`Juros recebidos · ${loan.person}`,method:method.value,status:'Pago',createdAt});});sh.close();toast(interestOnly?'Juros registrados e adicionados ao saldo.':'Pagamento registrado e adicionado ao saldo.');rerender();}finally{busy=false;confirmBtn.disabled=false;}}},interestOnly?'Registrar juros':'Registrar pagamento');
  const sh=openSheet({title:interestOnly?`Receber só juros · ${l.person}`:`Receber de ${l.person}`,subtitle:`Saldo a receber ${money(totalDue(l))} · o valor recebido entra no seu saldo`,content:h('div.form',h('p.notice',interestOnly?`Este lançamento afeta somente os juros. O principal de ${money(l.principal)} não será amortizado.`:`Principal ${money(l.principal)} · juros pendentes ${money(interestDue(l))}. O pagamento quita juros primeiro e depois amortiza o principal.`),field(interestOnly?'Juros recebidos':'Valor recebido',amount),field('Forma de recebimento',method),preview,msg),footer:[confirmBtn]});
}

function renewLoan(l){
  const capitalize=h('input',{type:'checkbox'}), rate=h('input.input',{inputmode:'decimal',value:String(l.interestMode==='fixed'?(l.interestFixed||0):(l.interestRate||0)).replace('.',',')}), due=h('input.input',{type:'date',value:addMonthsDate(l.due||today(),1)}), msg=h('p.form-msg');
  const sh=openSheet({title:`Renovar · ${l.person}`,subtitle:'Nada é capitalizado automaticamente.',content:h('div.form',h('label.check',capitalize,h('span','Capitalizar juros pendentes no principal')),field(l.interestMode==='fixed'?'Juros do novo ciclo (R$)':'Taxa do novo ciclo (%)',rate),field('Novo vencimento',due),h('p.notice','Se capitalizar, os juros pendentes viram principal. Se não capitalizar, continuam separados do principal.'),msg),footer:[h('button.btn.primary',{type:'button',onclick:()=>{const v=parseMoney(rate.value);if(v<0||!due.value){msg.textContent='Revise taxa e vencimento.';return;}store.commit(s=>{const loan=s.loans.find(x=>x.id===l.id), oldInterest=interestDue(loan);ensureLoanLedger(s,loan.id);if(capitalize.checked&&oldInterest>0){loan.principal=round2(loan.principal+oldInterest);loan.interestDue=0;}if(loan.interestMode==='fixed')loan.interestFixed=v;else loan.interestRate=v;loan.due=due.value;loan.status='open';loan.interestDue=round2(interestDue(loan)+baseInterest(loan));s.loanCycles.push({id:uid(),loanId:loan.id,date:today(),due:loan.due,principal:loan.principal,interest:baseInterest(loan),capitalized:capitalize.checked?oldInterest:0,type:'renewal',createdAt:Date.now()});});sh.close();toast('Empréstimo renovado.');rerender();}},'Confirmar renovação')]});
}

function syncPaymentTransactions(st,loan,payment,removedIds){
  const rows=relatedPaymentTransactions(st,payment.id);
  const syncRole=(role,value,desc)=>{
    let tx=rows.find(x=>x.transactionRole===role);
    if(value<=0.004){if(tx){removedIds.push(tx.id);st.transactions=st.transactions.filter(x=>x.id!==tx.id);}return;}
    if(!tx){tx={id:uid(),loanId:loan.id,loanPaymentId:payment.id,transactionRole:role,type:'income',cat:'Juros / Empréstimo',status:'Pago',createdAt:Date.now()};st.transactions.push(tx);}
    Object.assign(tx,{value:round2(value),date:payment.date,desc,method:payment.method||'Transferência',status:'Pago'});delete tx.locked;delete tx.immutable;
  };
  syncRole('loan_principal_return',payment.principal,`Principal recebido · ${loan.person}`);
  syncRole('loan_interest_income',payment.interest,`Juros recebidos · ${loan.person}`);
}

function editLoanPayment(l,p,parentSheet){
  const interest=h('input.input',{inputmode:'decimal',value:String(Number(p.interest||0)).replace('.',',')}), principal=h('input.input',{inputmode:'decimal',value:String(Number(p.principal||0)).replace('.',',')}), date=h('input.input',{type:'date',value:p.date||today()}), method=h('select.input',h('option',{value:'Transferência'},'Transferência'),h('option',{value:'PIX'},'PIX'),h('option',{value:'Dinheiro'},'Dinheiro'),h('option',{value:'Outro'},'Outro')), preview=h('div.loan-preview'), msg=h('p.form-msg');
  method.value=p.method||((relatedPaymentTransactions(S(),p.id)[0] && relatedPaymentTransactions(S(),p.id)[0].method) || 'Transferência');
  const update=()=>{const i=Math.max(0,parseMoney(interest.value)),pr=Math.max(0,parseMoney(principal.value));preview.replaceChildren(h('small','NOVO LANÇAMENTO'),h('div.loan-preview-grid',h('span','Juros',h('b',money(i))),h('span','Principal',h('b',money(pr))),h('span','Total',h('b',money(i+pr)))));};
  [interest,principal].forEach(x=>x.addEventListener('input',update));update();
  const sh=openSheet({title:`Editar pagamento · ${l.person}`,subtitle:p.principal<=0.004?'Este lançamento foi registrado somente como juros.':'Corrija juros e principal separadamente para manter o empréstimo consistente.',content:h('div.form',field('Juros recebidos',interest),field('Principal recebido',principal),h('p.notice','Se quiser manter este lançamento somente como juros, deixe Principal recebido em R$ 0,00.'),field('Data',date),field('Forma de recebimento',method),preview,msg),footer:[h('button.btn.primary',{type:'button',onclick:()=>{const st=S();const current=st.loanPayments.find(x=>x.id===p.id),loan=st.loans.find(x=>x.id===l.id);if(!current||!loan){msg.textContent='Pagamento não encontrado.';return;}const i=Math.max(0,parseMoney(interest.value)),pr=Math.max(0,parseMoney(principal.value));if(i+pr<=0.004){msg.textContent='Informe algum valor em juros ou principal.';return;}store.commit(state=>{ensureLoanLedger(state,loan.id);});const cap=loanCapacity(S(),loan.id,p.id);if(i>cap.interest+0.004){msg.textContent=`Juros acima do disponível para este contrato. Máximo: ${money(cap.interest)}.`;return;}if(pr>cap.principal+0.004){msg.textContent=`Principal acima do disponível para este contrato. Máximo: ${money(cap.principal)}.`;return;}const removed=[];store.commit(state=>{const pay=state.loanPayments.find(x=>x.id===p.id),ln=state.loans.find(x=>x.id===l.id);if(!pay||!ln)return;const oldInterest=Number(pay.interest||0),oldPrincipal=Number(pay.principal||0),auto=findAutoRenewCycle(state,pay);pay.interest=round2(i);pay.principal=round2(pr);pay.amount=round2(i+pr);pay.date=date.value||today();pay.method=method.value;pay.editable=true;delete pay.immutable;if(auto){if(i+0.004<oldInterest){removed.push(auto.id);state.loanCycles=state.loanCycles.filter(c=>c.id!==auto.id);pay.autoRenewed=false;}else{const oldCyclePrincipal=Math.max(0,Number(auto.principal||0));const nextPrincipal=Math.max(0,round2(oldCyclePrincipal+oldPrincipal-pr));if(ln.interestMode==='percent'&&oldCyclePrincipal>0){const effective=Number(auto.interest||0)/oldCyclePrincipal;auto.interest=round2(nextPrincipal*effective);}auto.principal=nextPrincipal;auto.date=pay.date;auto.paymentId=pay.id;}}
        syncPaymentTransactions(state,ln,pay,removed);recalculateLoan(state,ln.id);});if(removed.length)store.markDeleted(removed);sh.close();if(parentSheet && typeof parentSheet.close === 'function') parentSheet.close();toast('Pagamento atualizado. Saldos de principal e juros foram recalculados.');rerender();}},'Salvar correção')]});
}

async function deleteLoanPayment(l,p,parentSheet){
  const ok=await confirmSheet({title:'Excluir pagamento?',message:`Será removido ${money(p.amount)} do histórico (${money(p.interest)} em juros e ${money(p.principal)} em principal). Os saldos do empréstimo serão recalculados.`,confirmLabel:'Excluir pagamento',danger:true});
  if(!ok)return;
  const s=S(), related=relatedPaymentTransactions(s,p.id), auto=findAutoRenewCycle(s,p);const removed=[p.id,...related.map(x=>x.id),...(auto?[auto.id]:[])];
  store.markDeleted(removed);
  store.commit(st=>{ensureLoanLedger(st,l.id);st.loanPayments=st.loanPayments.filter(x=>x.id!==p.id);st.transactions=st.transactions.filter(x=>x.loanPaymentId!==p.id);if(auto)st.loanCycles=st.loanCycles.filter(x=>x.id!==auto.id);recalculateLoan(st,l.id);});
  if(parentSheet && typeof parentSheet.close === 'function') parentSheet.close();toast('Pagamento excluído e empréstimo recalculado.');rerender();
}

export function openLoanPaymentEditor(paymentId){
 if(!store.loansEnabled())return;
  const s=S(),p=(s.loanPayments||[]).find(x=>x.id===paymentId);if(!p){toast('Pagamento de empréstimo não encontrado.');return;}const l=(s.loans||[]).find(x=>x.id===p.loanId);if(!l){toast('Empréstimo não encontrado.');return;}editLoanPayment(l,p);
}

export async function deleteLoanPaymentById(paymentId){
  const s=S(),p=(s.loanPayments||[]).find(x=>x.id===paymentId);if(!p){toast('Pagamento de empréstimo não encontrado.');return;}const l=(s.loans||[]).find(x=>x.id===p.loanId);if(!l){toast('Empréstimo não encontrado.');return;}await deleteLoanPayment(l,p);
}

function timeline(s,l,onEdit,onDelete){
  const events=[];
  events.push({date:(l.createdAt?new Date(l.createdAt):null),iso:null,label:'Dinheiro emprestado',value:l.principalOriginal,kind:'out'});
  (s.loanCycles||[]).filter(c=>c.loanId===l.id).forEach(c=>{if(c.type==='renewal')events.push({date:null,iso:c.date,label:c.capitalized?`Renovado · ${money(c.capitalized)} capitalizados`:'Empréstimo renovado',value:c.interest,kind:'cycle'});});
  paidFor(s,l.id).forEach(p=>events.push({date:p.createdAt?new Date(p.createdAt):null,iso:p.date,label:`${paymentLabel(p)} · juros ${money(p.interest)} · principal ${money(p.principal)}`,value:p.amount,kind:'in',payment:p}));
  events.sort((a,b)=>String(b.iso||(b.date && b.date.toISOString ? b.date.toISOString() : '')||'').localeCompare(String(a.iso||(a.date && a.date.toISOString ? a.date.toISOString() : '')||'')));
  return h('div.loan-timeline',events.map(e=>{const d=e.iso||(e.date?`${e.date.getFullYear()}-${String(e.date.getMonth()+1).padStart(2,'0')}-${String(e.date.getDate()).padStart(2,'0')}`:today());return h('div.loan-event',h('span.loan-dot',{class:e.kind}),h('div',h('b',e.label),h('small',shortDate(d))),h('div.loan-event-side',h('strong',money(e.value)),e.payment?h('div.loan-event-actions',h('button.btn.sm',{type:'button',onclick:()=>onEdit(e.payment)},'Editar'),h('button.btn.sm.ghost.danger-text',{type:'button',onclick:()=>onDelete(e.payment)},'Excluir')):null));}));
}

function loanDetail(l){
  const s=S();
  const st=loanStatus(l);
  const rec=principalRecovered(s,l);
  const ints=interestReceived(s,l);
  let sh;
  const hasPayments=paidFor(s,l.id).length>0;
  const footer=[
    h('button.btn.ghost.danger-text',{type:'button',onclick:()=>deleteLoan(l,sh)},'Excluir contrato'),
    h('button.btn',{type:'button',onclick:()=>editLoan(l,sh)},'Editar empréstimo'),
    h('button.btn',{type:'button',onclick:()=>shareLoan(l.id)},'Compartilhar empréstimo')
  ];

  if(!isPaid(l)){
    footer.push(h('button.btn',{type:'button',onclick:()=>renewLoan(l)},'Renovar'));
    if(interestDue(l)>0.004){
      footer.push(h('button.btn',{type:'button',onclick:()=>payLoan(l,{interestOnly:true})},'Receber só juros'));
    }
    footer.push(h('button.btn.primary',{type:'button',onclick:()=>payLoan(l)},'Registrar pagamento'));
  }else{
    footer.push(h('button.btn',{type:'button',disabled:true},'Quitado'));
  }

  const kpis=h('div.loan-detail-kpis',
    h('div.stat',h('span','Principal original'),h('b',money(l.principalOriginal))),
    h('div.stat',h('span','Principal atual'),h('b',money(l.principal))),
    h('div.stat',h('span','Juros pendentes'),h('b',money(interestDue(l)))),
    h('div.stat',h('span','Total a receber'),h('b',money(totalDue(l))))
  );

  const meta=h('div.loan-meta',
    h('span',`Juros recebidos: ${money(ints)}`),
    h('span',`Vencimento: ${l.due?shortDate(l.due):'—'}`),
    h('span',l.interestMode==='fixed'?`Juros fixos: ${money(l.interestFixed)}`:`Taxa: ${l.interestRate||0}%`)
  );

  const historyNotice=hasPayments
    ? h('p.notice','Pagamentos do histórico podem ser editados ou excluídos. O Bivvo recalcula principal e juros automaticamente.')
    : null;

  const history=timeline(
    s,
    l,
    p=>{
      sh.close();
      setTimeout(()=>editLoanPayment(l,p),120);
    },
    p=>deleteLoanPayment(l,p,sh)
  );

  const content=h('div.loan-detail',
    kpis,
    progressBar(rec,l.principalOriginal,'Principal recuperado'),
    meta,
    h('div.section-head',h('h3','Histórico')),
    historyNotice,
    history,
    l.note?h('p.notice',l.note):null
  );

  sh=openSheet({
    title:l.person,
    subtitle:st.label,
    wide:true,
    content,
    footer:footer.filter(Boolean)
  });
}

export function openLoanCalendarDetail(id){
 if(!store.loansEnabled())return;
  const s=S(), l=(s.loans||[]).find(x=>x.id===id);
  if(!l) return;
  const st=loanStatus(l), total=totalDue(l), interest=interestDue(l);
  const rows=[];
  const row=(k,v)=>rows.push(h('div.kv',h('span',k),h('b',v)));
  row('Vencimento',l.due?shortDate(l.due):'—');
  row('Principal restante',money(l.principal));
  row('Juros do ciclo',money(interest));
  row(l.interestMode==='fixed'?'Juros':'Taxa',l.interestMode==='fixed'?money(l.interestFixed||0):`${Number(l.interestRate||0)}%`);
  row('Situação',st.label);
  if(l.note) row('Observação',l.note);
  let sheet;
  const actions=[];
  if(!isPaid(l)) actions.push(interest>0.004?h('button.btn',{type:'button',onclick:()=>{sheet.close();setTimeout(()=>payLoan(l,{interestOnly:true}),120);}},'Receber só juros'):null,h('button.btn.primary',{type:'button',onclick:()=>{sheet.close();setTimeout(()=>payLoan(l),120);}},'Registrar pagamento'));
  actions.push(h('button.btn',{type:'button',onclick:()=>{sheet.close();setTimeout(()=>editLoan(l),120);}},'Editar empréstimo'));
  actions.push(h('button.btn',{type:'button',onclick:()=>{sheet.close();setTimeout(()=>loanDetail(l),120);}},'Ver histórico'));
  sheet=openSheet({label:`Vencimento de ${l.person}`,content:[
    h('div.detail-head',h('span.tx-ico.lg.loan-due-icon',{'aria-hidden':'true'},'💰'),h('h2',l.person),h('p.detail-amount.in',money(total)),h('span.loan-status',{class:st.key},st.label)),
    h('div.kvs',rows),
    h('div.stack-actions',actions.filter(Boolean))
  ]});
}

function personDetail(person){const s=S(), list=(s.loans||[]).filter(l=>l.person===person), active=list.filter(l=>!isPaid(l)), principal=active.reduce((a,l)=>a+Number(l.principal||0),0), due=active.reduce((a,l)=>a+totalDue(l),0), ints=list.reduce((a,l)=>a+interestReceived(s,l),0), overdue=active.filter(l=>overdueDays(l)).length;openSheet({title:person,subtitle:`${list.length} empréstimo${list.length===1?'':'s'} · ${overdue?`${overdue} vencido${overdue>1?'s':''}`:'sem atrasos'}`,wide:true,content:h('div',h('div.loan-detail-kpis',h('div.stat',h('span','Principal pendente'),h('b',money(principal))),h('div.stat',h('span','Total a receber'),h('b',money(due))),h('div.stat',h('span','Juros recebidos'),h('b',money(ints)))),h('div.loan-list',list.map(l=>loanCard(s,l,true))))});}

function loanCard(s,l,compact=false){const st=loanStatus(l), rec=principalRecovered(s,l), ints=interestReceived(s,l);return h('section.card.loan-row',{class:`loan-${st.key}`},h('div.loan-row-head',h('div',h('b',l.person),h('small',l.due?`Vence ${shortDate(l.due)}`:'Sem vencimento')),h('span.loan-status',{class:st.key},st.label)),h('div.loan-amounts',h('span',h('small','Principal'),h('strong',money(l.principal))),h('span',h('small','Juros'),h('strong',money(interestDue(l)))),h('span',h('small','A receber'),h('strong',money(totalDue(l))))),progressBar(rec,l.principalOriginal,'Principal recuperado'),h('small.loan-earned',`Juros já recebidos: ${money(ints)}`),h('div.btn-row',h('button.btn',{type:'button',onclick:()=>loanDetail(l)},'Detalhes'),h('button.btn',{type:'button',onclick:()=>shareLoan(l.id)},'Compartilhar'),!isPaid(l)&&!compact&&interestDue(l)>0.004?h('button.btn',{type:'button',onclick:()=>payLoan(l,{interestOnly:true})},'Só juros'):null,!isPaid(l)&&!compact?h('button.btn.primary',{type:'button',onclick:()=>payLoan(l)},'Registrar pagamento'):null));}

export function renderLoans(root){
  if(!store.loansEnabled())return;
  if(store.isDemo())root.append(h('p.capital-demo-note',{role:'note'},'Demonstração: dez clientes, seis meses e pagamentos somente de juros. Explore contratos, pagamentos e resumos; nada é salvo na sua conta.'));
  const s=S(), loans=s.loans||[], selectedYM=ctx.month||ymOf(today());
  const loanCreatedYM=l=>{if(!l.createdAt)return '';const d=new Date(l.createdAt);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;};
  const hasActivityInMonth=l=>loanCreatedYM(l)===selectedYM||String(l.due||'').startsWith(selectedYM)||paidFor(s,l.id).some(p=>String(p.date||'').startsWith(selectedYM));
  const monthLoans=loans.filter(hasActivityInMonth);
  const active=loans.filter(l=>!isPaid(l)), principal=active.reduce((a,l)=>a+Number(l.principal||0),0), ints=active.reduce((a,l)=>a+interestDue(l),0);
  const monthPayments=(s.loanPayments||[]).filter(p=>String(p.date||'').startsWith(selectedYM));
  const received=monthPayments.reduce((a,p)=>a+Number(p.interest||0),0), overdue=active.filter(l=>overdueDays(l)).reduce((a,l)=>a+totalDue(l),0), total=principal+ints;
  const shift=n=>{ctx.month=addMonthsYM(selectedYM,n);rerender();};
  const monthSwitch=h('div.month-switch',{role:'group','aria-label':'Mês dos empréstimos'},
    h('button.icon-btn',{type:'button','aria-label':'Mês anterior',onclick:()=>shift(-1)},'‹'),
    h('button.month-label',{type:'button',onclick:()=>{if(ctx.month!==ymOf(today())){ctx.month=ymOf(today());rerender();}}},monthLabel(selectedYM)),
    h('button.icon-btn',{type:'button','aria-label':'Próximo mês',onclick:()=>shift(1)},'›'));
  const filter=h('select.input.loan-filter',h('option',{value:'active'},'Em aberto'),h('option',{value:'overdue'},'Vencidos'),h('option',{value:'paid'},'Quitados'),h('option',{value:'all'},'Todos'));
  const listHost=h('div.loan-list');
  const draw=()=>{let list=monthLoans;if(filter.value==='active')list=monthLoans.filter(l=>!isPaid(l));if(filter.value==='overdue')list=monthLoans.filter(l=>overdueDays(l));if(filter.value==='paid')list=monthLoans.filter(isPaid);listHost.replaceChildren(...(list.length?list.map(l=>loanCard(s,l)): [h('div.empty',h('b',`Nenhum empréstimo com atividade em ${monthLabel(selectedYM).toLowerCase()}.`),h('p','O filtro considera criação, vencimento ou pagamento no mês selecionado.'))]));};
  filter.addEventListener('change',draw);
  root.append(h('div.page-head',h('div',h('span.eyebrow','Carteira a receber'),h('h2','Bivvo Capital'),h('p',active.length?`${money(total)} a receber · ${overdue?`${money(overdue)} vencidos`:'nenhum valor vencido'}`:'Acompanhe principal, juros, pagamentos e atrasos.')),h('button.btn.primary',{type:'button',onclick:newLoan},'Novo empréstimo')),
    h('div.page-head',monthSwitch,h('span.muted.sm',`Filtro: ${monthLabel(selectedYM)}`)),
    h('div.loan-kpis',h('div.stat',h('span','Principal pendente'),h('b',money(principal))),h('div.stat',h('span','Total a receber'),h('b',money(total))),h('div.stat',h('span','Juros a receber'),h('b',money(ints))),h('div.stat',h('span',`Juros recebidos · ${monthShort(selectedYM)}`),h('b',money(received))),h('div.stat.danger',h('span','Vencido'),h('b',money(overdue)))));
  if(loans.length){
    const people=[...new Set(active.map(l=>l.person))].map(person=>({label:person,value:active.filter(l=>l.person===person).reduce((a,l)=>a+totalDue(l),0),person})).sort((a,b)=>b.value-a.value);
    const months={};(s.loanPayments||[]).forEach(p=>{const ym=ymOf(p.date);months[ym]=(months[ym]||0)+Number(p.interest||0);});const interestMonths=Object.entries(months).sort(([a],[b])=>a.localeCompare(b)).slice(-6).map(([ym,value])=>({label:monthShort(ym).toUpperCase(),value}));
    root.append(h('div.loans-grid',h('section.card',h('div.section-head',h('div',h('h3','Carteira Bivvo Capital'),h('p','Toque em uma pessoa para ver os contratos.'))),donut(people,{center:'A receber',onPick:x=>personDetail(x.person)})),h('section.card',h('div.section-head',h('div',h('h3','Por pessoa'),h('p','Principal + juros pendentes.'))),bars(people,{onPick:x=>personDetail(x.person)}))),interestMonths.length?h('section.card.loan-interest-chart',h('div.section-head',h('div',h('h3','Juros recebidos'),h('p','Últimos meses com recebimento.'))),bars(interestMonths)):null);
    root.append(h('div.loan-list-head',h('div',h('h3','Contratos do mês'),h('p.muted.sm','Criação, vencimento ou pagamento no período selecionado.')),filter),listHost);draw();
  } else root.append(h('div.empty',h('b','Nenhum empréstimo cadastrado.'),h('p','Cadastre um empréstimo e acompanhe principal, juros, pagamentos e vencimentos.')));
}
export function openLoanForm(){if(store.loansEnabled())newLoan();}
