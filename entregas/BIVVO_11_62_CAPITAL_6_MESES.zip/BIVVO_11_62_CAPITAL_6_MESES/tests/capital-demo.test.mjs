import assert from 'node:assert/strict';
import {buildDemo,addCapitalDemoRecords} from '../js/demo.js';
import {recalculateLoan} from '../js/loan-ledger.js';
import {today} from '../js/util.js';
const s=buildDemo();assert.equal(s.loans.length,0);addCapitalDemoRecords(s);
assert.equal(s.loans.length,19);assert.equal(s.loanPayments.length,12);
assert(s.loans.some(l=>l.due<today()&&l.status!=='paid'));
assert(s.loans.some(l=>l.status==='paid'));
assert(s.loans.some(l=>l.principal>0&&l.principal<l.principalOriginal));
const copy=structuredClone(s);for(const l of copy.loans){const principal=l.principal,interest=l.interestDue;recalculateLoan(copy,l.id);assert.equal(l.principal,principal);assert.equal(l.interestDue,interest);}
addCapitalDemoRecords(s);assert.equal(s.loans.length,19);
assert.equal(s.transactions.filter(t=>t.transactionRole==='loan_interest_income').reduce((n,t)=>n+t.value,0),1385);
assert.equal(new Set(s.loanPayments.map(p=>p.date.slice(0,7))).size,6);
assert.equal(new Set(s.loans.map(l=>new Date(l.createdAt).toISOString().slice(0,7))).size,6);
assert(s.loanPayments.every(p=>p.date<=today()));
console.log('Capital fictício: seis meses, 19 contratos e 12 pagamentos, livro-razão consistente, juros separados e sem duplicação.');
