# Demonstração do Bivvo Capital

Na apresentação do Capital, clique em Testar Capital ou Testar demonstração do Capital. Também existe a opção Capital na barra superior do modo de demonstração.

Quatro contratos fictícios: em dia, vencido, parcialmente pago e quitado. Principal, juros, pagamentos e livro-razão são consistentes. É possível explorar os filtros e as ações existentes. Os dados não são salvos na conta; sair da demonstração descarta os exemplos. As permissões dos planos reais não foram alteradas.

Este projeto completo inclui o layout e as correções de confiabilidade entregues antes. 59 conjuntos de testes passaram, além da verificação de navegador do botão Capital, filtros, três tamanhos de tela e retorno sem duplicação.

Publicação Netlify: utilize o projeto inteiro com npm run build, dist e funções netlify/functions. Não exige migração de banco. O download não atualiza o site publicado.
