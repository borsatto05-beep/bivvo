# Google Ads — tag base preparada

Conta: AW-18502157854. A tag só é carregada após autorização para medição de campanhas. A preferência pode ser revogada no menu Você. Atualizadas a descrição de privacidade e as permissões de rede para o Google.

PENDENTE: rótulo de conversão real da ação Inscrições. O campo SIGNUP_CONVERSION_LABEL em js/google-ads.js está vazio e nenhum evento de conversão será enviado até ele ser preenchido. Não inventar um rótulo. O gancho está ligado ao sucesso real de criação de conta, incluindo a checagem de identities do Supabase, e não ao clique no botão ou à visita inicial. A medição não envia nome, e-mail, telefone, identificador da conta ou dados financeiros ao Google.

Após incluir o rótulo, reconstruir e publicar no Netlify antes de testar a instalação. A entrega não altera o site publicado automaticamente.

60 conjuntos de testes passaram; testes adicionais de navegador verificam consentimento e revogação. Mantidas as correções de Capital, cartões e fechamento do guia.
