# Bivvo Capital — parcelamento

Base: ZIP BIVVO_11_64_CARTAO_BAIXA_SALDO enviado nesta conversa.

Use Novo empréstimo → Parcelado. Informe cliente, valor emprestado, total combinado incluindo juros, número de parcelas (2 a 120) e primeiro vencimento. Os vencimentos são mensais, ajustados ao último dia nos meses mais curtos. Não altera contratos existentes automaticamente.

Exemplo: R$ 4.000 emprestados e total de R$ 8.000 em 10 parcelas de R$ 800. Cada parcela separa R$ 400 de principal e R$ 400 de juros. Pequenas diferenças de centavos são distribuídas preservando os totais exatos.

Em Ver parcelas / Detalhes, acompanhe pagas, pendentes e vencidas. Marcar como paga abre confirmação de valor, data e forma de recebimento. Principal devolvido e juros são registrados separadamente no saldo. Desfazer pagamento pede confirmação, remove os lançamentos relacionados e reabre a parcela. Datas de recebimento futuras são rejeitadas. Pagamento duplicado local ou simultâneo em dois dispositivos usa a mesma identidade de pagamento, evitando duas baixas para a mesma parcela.

Compartilhar com cliente abre o cartão visual e a mensagem organizada, com principal, juros do acordo, total, parcelas pagas, saldo pendente, vencimentos e data dos pagamentos. WhatsApp, copiar e compartilhamento nativo são acionados somente pelo usuário.

57 conjuntos de testes passaram nesta base. Teste de navegador validou criação 4000→8000 em 10 parcelas, pagar, compartilhar, desfazer e telas de 320, 390 e 1280 pixels. As verificações locais não substituem a conferência de duas contas reais depois da publicação.

Publicação: use o projeto completo no Netlify, npm run build, pasta dist e funções netlify/functions. Não exige migração do banco. O pacote não atualiza automaticamente o site.
