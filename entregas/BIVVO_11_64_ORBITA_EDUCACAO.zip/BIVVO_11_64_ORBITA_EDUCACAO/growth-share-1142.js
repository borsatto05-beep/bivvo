import { buildShareUrl, safeSlug, budgetStatusFromPercent } from './js/growth-utils.mjs';

(function(){
  'use strict';
  if (document.querySelector('[data-bv42-share]')) return;
  const path = location.pathname;
  if (path === '/' || path.startsWith('/ferramentas/embed/')) return;
  const main = document.querySelector('main') || document.body;
  const h1 = document.querySelector('h1');
  const title = (h1?.textContent || document.title || 'Bivvo').trim().replace(/\s+/g,' ');
  const slug = safeSlug(path.replace(/^\/+|\/+$/g,'').split('/').pop() || 'pagina');
  const hasTool = !!document.querySelector('.tool, .calc, [data-seo-tool], #expenseCalc, #salaryCalc, #feriasCalc, form#calcForm');

  const section = document.createElement('section');
  section.className = 'bv42-share';
  section.dataset.bv42Share = '1';
  section.setAttribute('aria-labelledby','bv42-share-title');

  const copy = document.createElement('div'); copy.className='bv42-share-copy';
  const kicker = document.createElement('span'); kicker.className='bv42-kicker'; kicker.textContent = hasTool ? 'Compartilhe uma ferramenta útil' : 'Passe adiante';
  const heading = document.createElement('h2'); heading.id='bv42-share-title'; heading.textContent = hasTool ? 'Isso pode ajudar alguém a tomar uma decisão melhor' : 'Conhece alguém que precisa deste conteúdo?';
  const desc = document.createElement('p'); desc.textContent = 'Compartilhe a página sem expor seus valores financeiros. O link leva apenas para a ferramenta ou conteúdo.';
  const status = document.createElement('p'); status.className='bv42-share-status'; status.setAttribute('aria-live','polite');
  copy.append(kicker,heading,desc,status);

  const actions = document.createElement('div'); actions.className='bv42-share-actions';
  const button = (cls, text) => { const b=document.createElement('button'); b.type='button'; b.className='bv42-share-btn '+cls; b.textContent=text; return b; };
  const wa = button('is-primary','Enviar no WhatsApp');
  const native = button('','Compartilhar');
  const link = button('','Copiar link');
  const card = button('','Baixar cartão');
  actions.append(wa,native,link,card);
  section.append(copy,actions);

  const hostSection = document.querySelector('.bv40-lab');
  if (hostSection?.parentNode) hostSection.parentNode.insertBefore(section, hostSection.nextSibling);
  else main.append(section);

  const track = (event, content='') => document.dispatchEvent(new CustomEvent('bivvo:track',{detail:{event,content:String(content).slice(0,80)}}));
  let opened=false;
  const markOpen=()=>{ if(!opened){opened=true;track('organic_share_open', slug);} };
  const toolTrack=()=>{ if(hasTool) track('tool_shared',slug); };

  const shareMessage = () => {
    let prefix = hasTool ? 'Encontrei esta ferramenta grátis no Bivvo:' : 'Achei este conteúdo útil no Bivvo:';
    if (path.includes('planilha-de-gastos-mensais')) {
      const pctText = (document.querySelector('#rPct')?.textContent || '').replace(/[^0-9.,-]/g,'').replace(',','.');
      const pct = Number(pctText);
      if (Number.isFinite(pct)) prefix = `Meu diagnóstico mostrou ${budgetStatusFromPercent(pct)}. Esta é a ferramenta que usei:`;
    }
    return `${prefix}\n${title}`;
  };
  const urlFor = source => buildShareUrl(location.origin + path, source, slug);

  wa.addEventListener('click',()=>{
    markOpen(); toolTrack(); track('organic_share_whatsapp',slug);
    const text = `${shareMessage()}\n${urlFor('whatsapp')}`;
    window.open('https://wa.me/?text='+encodeURIComponent(text),'_blank','noopener,noreferrer');
  });

  native.addEventListener('click', async()=>{
    markOpen(); toolTrack();
    if (navigator.share) {
      try { await navigator.share({title, text: shareMessage(), url: urlFor('native_share')}); track('organic_share_native',slug); status.textContent='Compartilhamento aberto.'; return; }
      catch (e) { if (e?.name === 'AbortError') return; }
    }
    wa.click();
  });

  link.addEventListener('click', async()=>{
    markOpen(); toolTrack(); const u=urlFor('copy_link');
    let ok=false;
    try { await navigator.clipboard.writeText(u); ok=true; } catch {}
    if(!ok){ const t=document.createElement('textarea'); t.value=u; t.setAttribute('readonly',''); t.className='bv42-offscreen'; document.body.append(t); t.select(); try{ok=document.execCommand('copy');}catch{} t.remove(); }
    track('organic_share_copy',slug); status.textContent = ok ? 'Link copiado.' : 'Copie o endereço desta página no navegador.';
  });

  function makeCard(){
    const c=document.createElement('canvas'); c.width=1080; c.height=1080; const x=c.getContext('2d');
    const g=x.createLinearGradient(0,0,1080,1080); g.addColorStop(0,'#faf8ff'); g.addColorStop(1,'#efe7ff'); x.fillStyle=g; x.fillRect(0,0,1080,1080);
    x.fillStyle='#17131d'; x.fillRect(70,70,940,940); x.fillStyle='#ffffff'; x.font='700 42px Arial'; x.fillText('Bivvo',120,150);
    x.fillStyle='#b893ff'; x.font='700 28px Arial'; x.fillText(hasTool?'FERRAMENTA GRATUITA':'GUIA PRÁTICO',120,225);
    const words=title.split(/\s+/); const lines=[]; let line=''; x.font='700 64px Arial';
    words.forEach(w=>{ const t=line?line+' '+w:w; if(x.measureText(t).width>810 && line){lines.push(line);line=w;} else line=t; }); if(line)lines.push(line);
    x.fillStyle='#fff'; lines.slice(0,5).forEach((l,i)=>x.fillText(l,120,335+i*78));
    x.fillStyle='#d8c7ff'; x.font='400 30px Arial'; x.fillText('Informação clara. Próximo passo possível.',120,790);
    x.fillStyle='#fff'; x.font='700 30px Arial'; x.fillText('maisbivvo.netlify.app',120,900);
    return c;
  }
  card.addEventListener('click',()=>{
    markOpen(); toolTrack(); track('result_card_generated',slug);
    const c=makeCard(); const a=document.createElement('a'); a.download=`bivvo-${slug || 'resultado'}.png`; a.href=c.toDataURL('image/png'); a.click(); track('result_card_downloaded',slug); status.textContent='Cartão baixado sem incluir seus valores.';
  });

  // Só muda o estado visual após uso real de uma ferramenta; não abre pop-up.
  if(hasTool){
    const root=document.querySelector('.tool, .calc, [data-seo-tool], #expenseCalc, #salaryCalc, #feriasCalc, form#calcForm');
    const ready=()=>{section.classList.add('is-ready'); kicker.textContent='Resultado pronto';};
    root?.addEventListener('submit',()=>setTimeout(ready,50),true);
    root?.addEventListener('change',()=>setTimeout(ready,50),{once:true});
  }
})();
