import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const size=f=>fs.statSync(f).size;
const walk=d=>fs.readdirSync(d,{withFileTypes:true}).reduce((n,e)=>n+(e.isDirectory()?walk(path.join(d,e.name)):size(path.join(d,e.name))),0);
const budgets={
  'index.html':40*1024,
  'app.css':220*1024,
  'js/main.js':45*1024,
  'js/plans.js':24*1024,
  'netlify/functions/assistant.js':24*1024
};
for(const [file,max] of Object.entries(budgets)){
  const actual=size(file);
  assert(actual<=max,`${file} excedeu orçamento estático: ${actual} > ${max}`);
}
if(fs.existsSync('dist')) assert(walk('dist')<=5*1024*1024,'dist público excedeu 5 MB');
console.log('Orçamentos estáticos de fluidez/desempenho 11.48 dentro dos limites.');
